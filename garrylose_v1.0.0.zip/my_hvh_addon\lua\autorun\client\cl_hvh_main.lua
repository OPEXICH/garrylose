-- GARRYLOSE FRAMEWORK (v1.0.0)
Garrylose = Garrylose or {}

-- PANIC UNLOAD ENGINE (Clean Hook Unhooking & Memory Release)

function Garrylose.PanicUnload()

    hook.Remove("CreateMove", "Garrylose_Core_CreateMove")

    hook.Remove("HUDPaint", "Garrylose_ESP_Paint")

    hook.Remove("Think", "Garrylose_Universal_HitTracker")

    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_World_PostTranslucent")

    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_TracersAndImpacts_Render")

    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_DesyncGhost_Render")

    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_AutoPeek_RenderVisualizer")

    hook.Remove("Think", "Garrylose_PropTransparency_Engine")
    hook.Remove("CalcMainActivity", "Garrylose_Slidewalk_Anim")
    hook.Remove("UpdateAnimation", "Garrylose_Slidewalk_UpdateAnim")

    hook.Remove("EntityFireBullets", "Garrylose_NoSpread_Engine")

    hook.Remove("Think", "Garrylose_NoSpread_WeaponCone")

    if Garrylose.ResetAllTransparentProps then pcall(Garrylose.ResetAllTransparentProps) end

    hook.Remove("PostDraw2DSkyBox", "Garrylose_CustomSkybox_Render")

    hook.Remove("PreDrawHalos", "Garrylose_Glow_ESP")

    hook.Remove("CalcView", "Garrylose_Thirdperson_CalcView")

    hook.Remove("RenderScene", "Garrylose_AspectRatio_Render")

    hook.Remove("RenderScreenspaceEffects", "Garrylose_Nightmode_Visuals")

    hook.Remove("EntityFireBullets", "Garrylose_Client_BulletImpact")

    if IsValid(Garrylose.MenuFrame) then

        Garrylose.MenuFrame:Remove()

        Garrylose.MenuFrame = nil

    end

    if IsValid(Garrylose.GhostEntity) then

        Garrylose.GhostEntity:Remove()

        Garrylose.GhostEntity = nil

    end

    chat.AddText(Color(255, 60, 60), "[GARRYLOSE] ", Color(255, 255, 255), "Cheat cleanly unloaded! All hooks destroyed.")

end

-- BULLET TRACERS & 3D IMPACTS EVENT RECORDER

local function Garrylose_RecordShot(startPos, hitPos)

    if not startPos or not hitPos then return end

    local lp = LocalPlayer()

    if IsValid(lp) and IsValid(lp:GetActiveWeapon()) and Garrylose.IsGrenadeWeapon and Garrylose.IsGrenadeWeapon(lp:GetActiveWeapon()) then

        return

    end

    local curT = CurTime()

    -- Deduplicate multi-hook triggers for the exact same bullet within 0.03s

    if Garrylose.BulletTracers and #Garrylose.BulletTracers > 0 then

        local last = Garrylose.BulletTracers[#Garrylose.BulletTracers]

        if (curT - last.time < 0.03) and (last.startPos:DistToSqr(startPos) < 400) and (last.hitPos:DistToSqr(hitPos) < 400) then

            return

        end

    end

    if Garrylose.Config.bullet_tracers_enabled then

        Garrylose.BulletTracers = Garrylose.BulletTracers or {}

        table.insert(Garrylose.BulletTracers, {

            startPos = Vector(startPos.x, startPos.y, startPos.z),

            hitPos = Vector(hitPos.x, hitPos.y, hitPos.z),

            time = curT,

            duration = 1.8

        })

    end

    if Garrylose.Config.bullet_impacts_enabled then

        Garrylose.BulletImpacts = Garrylose.BulletImpacts or {}

        table.insert(Garrylose.BulletImpacts, {

            pos = Vector(hitPos.x, hitPos.y, hitPos.z),

            time = curT,

            duration = 3.5

        })

    end

end

Garrylose.Config = Garrylose.Config or {}

Garrylose.Plugins = Garrylose.Plugins or {}

Garrylose.RealViewAngles = Garrylose.RealViewAngles or Angle(0, 0, 0)

Garrylose.CurrentTarget = nil

Garrylose.ShotState = false

Garrylose.ManualShotState = false

Garrylose.DoubleTapCharged = true

Garrylose.LastDTShootTime = 0

Garrylose.DTRechargeDelay = 0.35

-- Ensure Config Directory Exists

if not file.Exists("garrylose_configs", "DATA") then

    file.CreateDir("garrylose_configs")

end

-- 1. CONFIGURATION SYSTEM & DEFAULT VALUES

Garrylose.Config = {

    -- Aimbot & Targeting

    aimbot_enabled = true,

    aimbot_fov = 90,

    aimbot_silent = true,         -- Silent Aim

    aimbot_rcs = true,            -- Recoil Control System

    aimbot_vischeck = true,       -- Wall Check (Line of Sight)

    -- Multi-Hitbox Selection System

    aimbot_hitbox_head = true,    -- Scan Head

    aimbot_hitbox_chest = true,   -- Scan Chest

    aimbot_hitbox_stomach = true, -- Scan Stomach / Pelvis

    aimbot_hitbox_arms = true,    -- Scan Arms / Shoulders

    aimbot_hitbox_legs = true,    -- Scan Legs / Feet

    aimbot_head_priority = true,  -- Prioritize Head if visible

    aimbot_lock_ticks = 2,        -- Min Ticks to track/lock head before firing (eliminates 1-tick snap misses on bhoppers)

    aimbot_multipoint = true,     -- Hitbox Multipoint Scan

    aimbot_multipoint_scale = 0.8,-- Multipoint Radius Scale (0.1 - 1.0)

    aimbot_target_players = true,

    aimbot_team_check = false,    -- Team Check (Ignore Teammates)

    aimbot_target_npcs = true,

    aimbot_auto_shoot = true,

    aimbot_shoot_mode = 2,        -- 1 = Continuous Hold, 2 = Rapid Pulse / Click

    hitchance_enabled = false,    -- Master Toggle for Hitchance Filter (Off by default = Instant Fire)

    aimbot_hitchance = 0,         -- Hitchance Threshold % (0 = Off / Instant Fire, 1-100)

    aimbot_hitchance_override = 0, -- Hitchance Override Value %

    bind_hitchance_override = KEY_NONE,

    hitchance_override_active = false,

    airstop_enabled = false,      -- Air-Stop (Halt horizontal air velocity)

    bind_airstop = KEY_NONE,

    -- Triggerbot Engine

    triggerbot_enabled = false,

    bind_triggerbot = KEY_NONE,

    triggerbot_delay = 0,         -- Trigger Delay in ms (0 - 250)

    triggerbot_head_only = false, -- Only fire when targeting Head

    doubletap_enabled = true,     -- Double Tap (Rapid Double-Shot Burst)

    bind_doubletap = KEY_NONE,

    bind_aimbot = KEY_NONE,

    -- Anti-Aim & Manuals

    antiaim_enabled = false,

    antiaim_pitch = 1,            -- 0 = None, 1 = Down, 2 = Up, 3 = Jitter Pitch, 4 = Random Jitter

    antiaim_yaw = 1,              -- 1 = Backward, 2 = Spinbot, 3 = Jitter, 4 = Random Jitter

    antiaim_jitter_angle = 90,    -- Jitter Yaw Angle (1 - 360 deg)

    antiaim_pitch_jitter_angle = 45, -- Jitter Pitch Angle (1 - 89 deg)

    antiaim_jitter_side = 1,      -- 1 = Backward (+180), 2 = Forward (0)

    antiaim_spin_speed = 450,     -- Spinbot Rotation Speed in deg/s (50 - 2500)

    manual_aa_state = 0,          -- 0 = None, 1 = Left (-90), 2 = Right (+90), 3 = Back (180)

    manual_aa_arrows = true,      -- Screen Directional Indicator Arrows

    bind_manual_left = KEY_NONE,

    bind_manual_right = KEY_NONE,

    bind_manual_back = KEY_NONE,

    bind_antiaim = KEY_NONE,

    -- Visuals, World Modulation & Night Mode

    ui_style = 1,                 -- 1 = Dark Theme, 2 = Light Theme (White)

    -- Glow ESP & Desync Ghost

    glow_esp_enabled = false,

    col_glow_esp = Color(0, 210, 255, 255),

    desync_ghost_enabled = false,

    desync_ghost_mat = 1,         -- 1 = Flat Glow, 2 = Wireframe

    col_desync_ghost = Color(0, 230, 255, 140),

    -- Bullet Tracers & 3D Impacts

    bullet_tracers_enabled = true,

    col_bullet_tracers = Color(0, 220, 255, 255),

    bullet_impacts_enabled = true,

    col_bullet_impacts = Color(0, 180, 255, 255),

    -- Additional ESP Features

    esp_skeleton = true,

    col_esp_skeleton = Color(255, 255, 255, 220),

    offscreen_esp_enabled = true,

    col_offscreen_esp = Color(255, 60, 90, 255),

    esp_weapon_info = true,

    col_esp_weapon = Color(240, 245, 255, 255),

    esp_ammo = true,              -- Ammo Bar & Count ESP

    col_esp_ammo = Color(255, 180, 40, 255),

    -- Prop & World Transparency

    prop_transparency_enabled = false,

    prop_transparency_mode = 1,   -- 1 = Translucent Alpha, 2 = Wireframe Mesh

    prop_alpha = 110,             -- Alpha level (10 - 255)

    col_prop_transparency = Color(255, 255, 255, 110),

    -- Custom Skybox Changer

    custom_skybox_enabled = false,

    custom_skybox_type = 1,       -- 1 = Deep Space, 2 = Midnight Starry, 3 = Sunset Crimson, 4 = Cyberpunk Violet, 5 = Void Black

    -- Grenade Warning & Blast Radius

    grenade_warning_enabled = true,

    col_grenade_warning = Color(255, 50, 50, 220),

    -- Spectator List (Creepypasta Scare Easter Egg)

    spectator_list_enabled = false,

    -- Clantag & Killsay

    killsay_enabled = false,

    nightmode_enabled = false,    -- Tactical Night Mode

    nightmode_darkness = 0.50,    -- Darkness Factor (0.1 - 0.9)

    col_nightmode = Color(20, 30, 55, 255),

    bind_nightmode = KEY_NONE,

    skybox_mod_enabled = false,   -- Custom Skybox Color

    col_skybox = Color(12, 16, 28, 255),

    fullbright_enabled = false,   -- Fullbright World Visual

    fog_enabled = false,          -- Custom Atmospheric Fog

    fog_density = 2200,           -- Fog Distance in units

    col_fog = Color(20, 25, 40, 255),

    thirdperson_enabled = false,

    thirdperson_dist = 100,

    bind_thirdperson = KEY_NONE,

    aspect_ratio_enabled = false, -- Custom Aspect Ratio

    aspect_ratio_val = 1.33,      -- 1.33 = 4:3 Stretched, 1.77 = 16:9, 1.6 = 16:10, 2.33 = 21:9

    esp_enabled = true,

    esp_boxes = true,

    col_esp_boxes = Color(0, 210, 255, 255),

    esp_names = true,

    col_esp_names = Color(240, 245, 255, 255),

    esp_health = true,

    col_esp_health = Color(0, 230, 180, 255),

    esp_snaplines = true,

    col_esp_snaplines = Color(0, 210, 255, 200),

    col_fov_ring = Color(0, 190, 255, 120),

    col_hitmarker = Color(255, 255, 255, 255),

    col_dmg_numbers = Color(255, 255, 255, 255),

    bind_esp = KEY_NONE,

    -- Color Customization (RGB Tables for Every Feature)

    col_esp_trail = Color(0, 255, 255, 255),
    col_jump_circles = Color(0, 255, 255, 255),
    col_esp_box_fill = Color(0, 255, 255, 30),
    col_worldmod = Color(255, 255, 255, 255),
    col_fog = Color(20, 25, 40, 255),
    col_chams_player = Color(0, 255, 0, 255),
    col_chams_npc = Color(255, 255, 0, 255),
    col_chams_self = Color(255, 0, 0, 255),
    col_chams_hands = Color(0, 0, 255, 255),
    freecam_speed = 10,
    viewmodel_pitch = 0,
    viewmodel_yaw = 0,
    viewmodel_roll = 0,
    chams_npc = false,
    nothing_enabled = false,
    bind_nothing = KEY_NONE,


    col_esp_box = Color(0, 210, 255, 255),

    col_esp_names = Color(240, 245, 255, 255),

    col_esp_health = Color(0, 230, 180, 255),

    col_esp_snaplines = Color(0, 210, 255, 255),

    col_manual_arrows = Color(0, 215, 255, 255),

    col_fov_ring = Color(0, 190, 255, 140),

    -- Min Damage & Rage Accuracy

    aimbot_min_damage = 1,        -- Minimum Damage threshold (1 - 100)

    aimbot_min_damage_override = 1, -- Min Damage Override value

    bind_min_damage_override = KEY_NONE,

    min_damage_override_active = false,

    -- Hitsounds & Hitmarkers

    hitsound_enabled = true,      -- Hitsound audio feedback

    hitsound_type = 1,            -- 1 = Garrylose Bell, 2 = Metallic Ping, 3 = Tactical Click, 4 = Bubble

    hitmarker_enabled = true,     -- Crosshair Hitmarker (X)

    col_hitmarker = Color(255, 255, 255, 255),    -- Hitmarker Color Cell

    hitmarker_damage_numbers = true, -- Floating -HP numbers

    col_dmg_numbers = Color(255, 255, 255, 255),  -- Damage Numbers Color Cell

    -- Misc, Movement & HUD

    bhop_enabled = true,

    bind_bhop = KEY_NONE,

    autostrafe_enabled = true,    -- Auto Strafer

    autostrafe_mode = 1,          -- 1 = Mouse / View Delta, 2 = Rage / Directional

    bind_autostrafe = KEY_NONE,

    autopeek_enabled = false,     -- Auto Peek (Quick Peek Assist)

    bind_autopeek = KEY_NONE,

    col_autopeek = Color(0, 215, 255, 220),       -- Auto-Peek 3D Ring Color

    edgejump_enabled = false,     -- Edge Jump

    bind_edgejump = KEY_NONE,

    fakeduck_enabled = false,     -- Fake Duck (Standing View while Crouching)

    bind_fakeduck = KEY_NONE,

    crouchjump_enabled = false,   -- Crouch Jump (Air Duck with Auto-Stand)

    bind_crouchjump = KEY_NONE,

    slidewalk_enabled = false,    -- Slidewalk / Moonwalk (Smooth sliding in 3rd person)

    bind_panic = KEY_NONE,        -- Panic Key (Clean Cheat Unload)

    autoreload_enabled = true,    -- Auto Reload Weapon

    keybinds_list_enabled = true, -- Keybinds List HUD Window

    -- Viewmodel Customization & Offsets

    viewmodel_fov = 68,           -- Viewmodel FOV

    viewmodel_x = 0,              -- Viewmodel Offset X (Left / Right)

    viewmodel_y = 0,              -- Viewmodel Offset Y (Forward / Back)

    viewmodel_z = 0,              -- Viewmodel Offset Z (Up / Down)

    -- Kill Effects

    killeffect_enabled = true,    -- Dramatic Kill Effects

    killeffect_type = 1,          -- 1 = Tesla Lightning, 2 = Plasma Explosion, 3 = Blood Burst, 4 = Energy Wave

    col_killeffect = Color(0, 215, 255, 255), -- Kill Effect & Dynamic Light Color

    watermark_enabled = true,     -- Watermark & Speedometer HUD

    keybinds_x = 25,

    keybinds_y = 300,

    fov_changer = 100,

    bind_menu = KEY_INSERT,

    -- Options & Customization

    menu_theme = 1,               -- 1=Cyan, 2=Red, 3=Purple, 4=Green, 5=Orange, 6=Pink

    language = "en"               -- "ru" / "en" 

}

-- 2. Config System

function Garrylose.SaveConfig(name)

    if not name or string.Trim(name) == "" then name = "default" end

    name = string.lower(string.Trim(name))

    if not string.EndsWith(name, ".json") then name = name .. ".json" end

    Garrylose.Config.aimbot_hitbox = tonumber(Garrylose.Config.aimbot_hitbox) or 1

    Garrylose.Config.aimbot_lock_ticks = tonumber(Garrylose.Config.aimbot_lock_ticks) or 2

    Garrylose.Config.aimbot_shoot_mode = tonumber(Garrylose.Config.aimbot_shoot_mode) or 2

    Garrylose.Config.hitsound_type = tonumber(Garrylose.Config.hitsound_type) or 1

    Garrylose.Config.autostrafe_mode = tonumber(Garrylose.Config.autostrafe_mode) or 1

    Garrylose.Config.antiaim_pitch = tonumber(Garrylose.Config.antiaim_pitch) or 1

    Garrylose.Config.antiaim_yaw = tonumber(Garrylose.Config.antiaim_yaw) or 1

    Garrylose.Config.antiaim_spin_speed = tonumber(Garrylose.Config.antiaim_spin_speed) or 450

    Garrylose.Config.aimbot_fov = tonumber(Garrylose.Config.aimbot_fov) or 90

    Garrylose.Config.thirdperson_dist = tonumber(Garrylose.Config.thirdperson_dist) or 100

    Garrylose.Config.aspect_ratio_val = tonumber(Garrylose.Config.aspect_ratio_val) or 1.33

    Garrylose.Config.ui_style = tonumber(Garrylose.Config.ui_style) or 1

    Garrylose.Config.nightmode_darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50

    Garrylose.Config.fog_density = tonumber(Garrylose.Config.fog_density) or 2200

    Garrylose.Config.fov_changer = tonumber(Garrylose.Config.fov_changer) or 100

    Garrylose.Config.custom_accent_r = tonumber(Garrylose.Config.custom_accent_r) or 0

    Garrylose.Config.custom_accent_g = tonumber(Garrylose.Config.custom_accent_g) or 180

    Garrylose.Config.custom_accent_b = tonumber(Garrylose.Config.custom_accent_b) or 255

    Garrylose.Config.viewmodel_fov = tonumber(Garrylose.Config.viewmodel_fov) or 68

    Garrylose.Config.viewmodel_x = tonumber(Garrylose.Config.viewmodel_x) or 0

    Garrylose.Config.viewmodel_y = tonumber(Garrylose.Config.viewmodel_y) or 0

    Garrylose.Config.viewmodel_z = tonumber(Garrylose.Config.viewmodel_z) or 0

    Garrylose.Config.desync_ghost_mat = tonumber(Garrylose.Config.desync_ghost_mat) or 1

    Garrylose.Config.prop_transparency_mode = tonumber(Garrylose.Config.prop_transparency_mode) or 1

    Garrylose.Config.prop_alpha = tonumber(Garrylose.Config.prop_alpha) or 110

    Garrylose.Config.custom_skybox_type = tonumber(Garrylose.Config.custom_skybox_type) or 1

    Garrylose.Config.killeffect_type = tonumber(Garrylose.Config.killeffect_type) or 1

    local json = util.TableToJSON(Garrylose.Config, true)

    if json then

        file.Write("garrylose_configs/" .. name, json)

        notification.AddLegacy("Garrylose: Config '" .. name .. "' saved!", NOTIFY_HINT, 3)

    end

end

function Garrylose.LoadConfig(name)

    if not name or string.Trim(name) == "" then name = "default" end

    name = string.lower(string.Trim(name))

    if not string.EndsWith(name, ".json") then name = name .. ".json" end

    if file.Exists("garrylose_configs/" .. name, "DATA") then

        local json = file.Read("garrylose_configs/" .. name, "DATA")

        local tbl = util.JSONToTable(json)

        if tbl then

                        for k, v in pairs(tbl) do

                if type(v) == "table" and v.r and v.g and v.b then

                    Garrylose.Config[k] = Color(v.r, v.g, v.b, v.a or 255)

                else

                    Garrylose.Config[k] = v

                end

            end

            if tbl.col_esp_box and tbl.col_esp_box.r then Garrylose.Config.col_esp_box = Color(tbl.col_esp_box.r, tbl.col_esp_box.g, tbl.col_esp_box.b, tbl.col_esp_box.a or 255) end

            if tbl.col_esp_snaplines and tbl.col_esp_snaplines.r then Garrylose.Config.col_esp_snaplines = Color(tbl.col_esp_snaplines.r, tbl.col_esp_snaplines.g, tbl.col_esp_snaplines.b, tbl.col_esp_snaplines.a or 255) end

            if tbl.col_manual_arrows and tbl.col_manual_arrows.r then Garrylose.Config.col_manual_arrows = Color(tbl.col_manual_arrows.r, tbl.col_manual_arrows.g, tbl.col_manual_arrows.b, tbl.col_manual_arrows.a or 255) end

            if tbl.col_fov_ring and tbl.col_fov_ring.r then Garrylose.Config.col_fov_ring = Color(tbl.col_fov_ring.r, tbl.col_fov_ring.g, tbl.col_fov_ring.b, tbl.col_fov_ring.a or 120) end

            if tbl.col_autopeek and tbl.col_autopeek.r then Garrylose.Config.col_autopeek = Color(tbl.col_autopeek.r, tbl.col_autopeek.g, tbl.col_autopeek.b, tbl.col_autopeek.a or 220) end

            if tbl.col_killeffect and tbl.col_killeffect.r then Garrylose.Config.col_killeffect = Color(tbl.col_killeffect.r, tbl.col_killeffect.g, tbl.col_killeffect.b, tbl.col_killeffect.a or 255) end

            Garrylose.Config.aimbot_hitbox = tonumber(Garrylose.Config.aimbot_hitbox) or 1

            Garrylose.Config.aimbot_lock_ticks = tonumber(Garrylose.Config.aimbot_lock_ticks) or 2

            Garrylose.Config.aimbot_shoot_mode = tonumber(Garrylose.Config.aimbot_shoot_mode) or 2

            Garrylose.Config.antiaim_pitch = tonumber(Garrylose.Config.antiaim_pitch) or 1

            Garrylose.Config.antiaim_yaw = tonumber(Garrylose.Config.antiaim_yaw) or 1

    Garrylose.Config.antiaim_spin_speed = tonumber(Garrylose.Config.antiaim_spin_speed) or 450

            notification.AddLegacy("Garrylose: Config '" .. name .. "' loaded!", NOTIFY_GENERIC, 3)

            if Garrylose.OpenMenu and IsValid(Garrylose.MenuFrame) then

                Garrylose.OpenMenu()

            end

        end

    else

        notification.AddLegacy("Garrylose: Config '" .. name .. "' not found!", NOTIFY_ERROR, 3)

    end

end

function Garrylose.DeleteConfig(name)

    if not name or string.Trim(name) == "" then return end

    name = string.lower(string.Trim(name))

    if not string.EndsWith(name, ".json") then name = name .. ".json" end

    if file.Exists("garrylose_configs/" .. name, "DATA") then

        file.Delete("garrylose_configs/" .. name)

        notification.AddLegacy("Garrylose: Config '" .. name .. "' deleted!", NOTIFY_CLEANUP, 3)

        if Garrylose.OpenMenu and IsValid(Garrylose.MenuFrame) then

            Garrylose.OpenMenu()

        end

    end

end

-- HELPER FUNCTIONS & MAPPINGS

function Garrylose.IsValidFirearm(wep)

    if not IsValid(wep) then return false end

    local class = string.lower(wep:GetClass() or "")

    if class == "weapon_physgun" or class == "gmod_tool" or class == "gmod_camera" or class == "weapon_physcannon" or class == "weapon_medkit" or class == "none" then

        return false

    end

    return true

end

local IsValidFirearm = Garrylose.IsValidFirearm

function Garrylose.IsGrenadeWeapon(wep)

    if not IsValid(wep) then return false end

    local class = string.lower(wep:GetClass() or "")

    local hold = string.lower(wep:GetHoldType() or "")

    if hold == "grenade" or hold == "slam" then return true end

    if string.find(class, "grenade") or string.find(class, "frag") or string.find(class, "molotov") 

       or string.find(class, "flash") or string.find(class, "smoke") or string.find(class, "slam") 

       or string.find(class, "bomb") or string.find(class, "pipe") then

        return true

    end

    if wep.IsTFAWeapon and (wep.Type == "Grenade" or wep.Slot == 4) then return true end

    if wep.IsArcCW and (wep.Throwing or wep.Primary.Projectile) then return true end

    if wep.CW20Weapon and wep.Grenade then return true end

    return false

end

local IsGrenadeWeapon = Garrylose.IsGrenadeWeapon

function Garrylose.GetKeyName(key)

    if not key or key == KEY_NONE or key == 0 then return "NONE" end

    if key >= 107 then

        if key == MOUSE_LEFT then return "M1"

        elseif key == MOUSE_RIGHT then return "M2"

        elseif key == MOUSE_MIDDLE then return "M3"

        elseif key == MOUSE_4 then return "M4"

        elseif key == MOUSE_5 then return "M5"

        elseif key == MOUSE_WHEEL_UP then return "MWHEELUP"

        elseif key == MOUSE_WHEEL_DOWN then return "MWHEELWN"

        else return "MOUSE" .. (key - 106) end

    end

    return input.GetKeyName(key) and string.upper(input.GetKeyName(key)) or ("KEY " .. key)

end

-- GARRYLOSE THEMES & COLOR SYSTEM

Garrylose.ThemeColors = {

    [1] = { name = "Cyan Blue (Neverlose)", accent = Color(0, 180, 255),   glow = Color(0, 180, 255, 120), dim = Color(0, 180, 255, 30),  hov = Color(45, 200, 255) },

    [2] = { name = "Crimson Red",           accent = Color(245, 55, 75),    glow = Color(245, 55, 75, 120), dim = Color(245, 55, 75, 30),  hov = Color(255, 85, 105) },

    [3] = { name = "Purple Violet",         accent = Color(175, 75, 255),   glow = Color(175, 75, 255, 120),dim = Color(175, 75, 255, 30), hov = Color(195, 105, 255) },

    [4] = { name = "Emerald Green",         accent = Color(40, 215, 120),   glow = Color(40, 215, 120, 120),dim = Color(40, 215, 120, 30), hov = Color(70, 235, 145) },

    [5] = { name = "Gold Orange",           accent = Color(255, 165, 0),    glow = Color(255, 165, 0, 120),  dim = Color(255, 165, 0, 30),  hov = Color(255, 190, 45) },

    [6] = { name = "Hot Pink",              accent = Color(255, 60, 160),   glow = Color(255, 60, 160, 120), dim = Color(255, 60, 160, 30), hov = Color(255, 95, 185) }

}

function Garrylose.GetActiveTheme()

    local themeIdx = tonumber(Garrylose.Config.menu_theme) or 1

    if themeIdx == 7 then

        local r = tonumber(Garrylose.Config.custom_accent_r) or 0

        local g = tonumber(Garrylose.Config.custom_accent_g) or 180

        local b = tonumber(Garrylose.Config.custom_accent_b) or 255

        local col = Color(r, g, b, 255)

        local hov = Color(math.min(r + 35, 255), math.min(g + 35, 255), math.min(b + 35, 255), 255)

        local dim = Color(r, g, b, 30)

        local glow = Color(r, g, b, 120)

        return { name = "Custom Color Wheel", accent = col, glow = glow, dim = dim, hov = hov }

    end

    return Garrylose.ThemeColors[themeIdx] or Garrylose.ThemeColors[1]

end

-- LOCALIZATION (RU / EN)

Garrylose.Languages = {

    ["en"] = {

        ["tab_aim"] = "Aimbot",

        ["desc_aim"] = "Ragebot & Targeting",

        ["tab_aa"] = "Anti-Aim",

        ["desc_aa"] = "Desync & Yaw Angles",

        ["tab_vis"] = "Visuals",

        ["desc_vis"] = "ESP, Chams & Camera",

        ["tab_misc"] = "Miscellaneous",

        ["desc_misc"] = "Movement & System",

        ["tab_cfg"] = "Configs",

        ["desc_cfg"] = "Profile Management",

        ["tab_lua"] = "Lua Scripts",

        ["desc_lua"] = "In-Game IDE & Plugins",

        ["tab_opt"] = "Options",

        ["desc_opt"] = "Theme & Localization",

        ["aim_main"] = "Aimbot & Resolver",

        ["aim_targeting"] = "Hitboxes & Targeting",

        ["enable_aim"] = "Enable Aimbot",

        ["silent_aim"] = "Silent Aim",

        ["rcs"] = "Recoil Control (RCS)",

        ["auto_shoot"] = "Auto Shoot",

        ["doubletap"] = "Double Tap (Rapid Double-Shot)",

        ["resolver"] = "HvH Anti-Aim Resolver",

        ["resolver_mode"] = "Resolver Mode",

        ["multipoint"] = "Hitbox Multipoint Scan",

        ["mp_scale"] = "Multipoint Scale",

        ["aim_fov"] = "Aimbot FOV",

        ["fov_circle"] = "Draw FOV Circle",

        ["shoot_mode"] = "Shoot Mode",

        ["wall_check"] = "Wall Check (LoS)",

        ["min_damage"] = "Minimum Damage",

        ["min_damage_override"] = "Min Damage Override",

        ["target_players"] = "Target Players",

        ["team_check"] = "Team Check (Ignore Teammates)",

        ["target_npcs"] = "Target NPCs & Nextbots",

        ["vis_esp"] = "Player & NPC ESP",

        ["vis_world"] = "World & Camera",

        ["enable_esp"] = "Enable ESP",

        ["boxes"] = "2D Boxes",

        ["names_class"] = "Player Names & Class",

        ["health_status"] = "Health Status",

        ["snaplines"] = "Snaplines",

        ["thirdperson"] = "Thirdperson View",

        ["tp_dist"] = "Thirdperson Distance",

        ["cam_fov"] = "Camera FOV Override",

        ["fov_ring"] = "Draw FOV Ring Circle",

        ["misc_move"] = "Movement & Display",

        ["misc_hit"] = "Hit Feedback & System",

        ["bhop"] = "Auto BunnyHop",

        ["autostrafe"] = "Auto Strafer",

        ["strafer_mode"] = "Strafer Mode",

        ["edgejump"] = "Edge Jump",

        ["fakeduck"] = "Fake Duck",

        ["crouchjump"] = "Crouch Jump (Air Duck)",

        ["autopeek"] = "Peek Assist",

        ["pedals"] = "Subtick Exploit (Pedals)",

        ["autoreload"] = "Auto Reload Weapon",

        ["keybinds_hud"] = "Keybinds List (HUD)",

        ["aspect_ratio"] = "Aspect Ratio Override",

        ["aspect_scale"] = "Aspect Ratio",

        ["watermark"] = "Watermark & Speedometer",

        ["hitmarkers"] = "Crosshair Hitmarkers (X)",

        ["dmg_numbers"] = "Floating Damage (-HP)",

        ["hitsounds"] = "Enable Hitsound Audio",

        ["hitsound_preset"] = "Hitsound Preset",

        ["menu_bind"] = "Menu Keybind:",

        ["reset_default"] = "Reset Settings to Default",

        ["opt_theme"] = "Menu Theme & Accent",

        ["opt_lang"] = "Language & Localization",

        ["accent_preset"] = "Accent Color Preset",

        ["ui_language"] = "Interface Language"

    },

    ["ru"] = {

        ["tab_aim"] = "Р С’Р С‘Р СР В±Р С•РЎвЂљ",

        ["desc_aim"] = "Р РЋРЎвЂљРЎР‚Р ВµР В»РЎРЉР В±Р В° Р С‘ Р Р…Р В°Р Р†Р С•Р Т‘Р С”Р В°",

        ["tab_aa"] = "Р С’Р Р…РЎвЂљР С‘-Р С’Р С‘Р СРЎвЂ№",

        ["desc_aa"] = "Р Р€Р С–Р В»РЎвЂ№ Р С‘ Р В·Р В°РЎвЂ°Р С‘РЎвЂљР В°",

        ["tab_vis"] = "Р вЂ™Р С‘Р В·РЎС“Р В°Р В»РЎвЂ№",

        ["desc_vis"] = "ESP, Р В§Р В°Р СРЎРѓРЎвЂ№ Р С‘ Р С”Р В°Р СР ВµРЎР‚Р В°",

        ["tab_misc"] = "Р В Р В°Р В·Р Р…Р С•Р Вµ",

        ["desc_misc"] = "Р вЂќР Р†Р С‘Р В¶Р ВµР Р…Р С‘Р Вµ Р С‘ РЎРѓР С‘РЎРѓРЎвЂљР ВµР СР В°",

        ["tab_cfg"] = "Р С™Р С•Р Р…РЎвЂћР С‘Р С–Р С‘",

        ["desc_cfg"] = "Р Р€Р С—РЎР‚Р В°Р Р†Р В»Р ВµР Р…Р С‘Р Вµ Р С—РЎР‚Р С•РЎвЂћР С‘Р В»РЎРЏР СР С‘",

        ["tab_lua"] = "Lua Р РЋР С”РЎР‚Р С‘Р С—РЎвЂљРЎвЂ№",

        ["desc_lua"] = "IDE Р С‘ Р С—Р В»Р В°Р С–Р С‘Р Р…РЎвЂ№",

        ["tab_opt"] = "Р С›Р С—РЎвЂ Р С‘Р С‘",

        ["desc_opt"] = "Р СћР ВµР СР В° Р С‘ РЎРЏР В·РЎвЂ№Р С” Р СР ВµР Р…РЎР‹",

        ["aim_main"] = "Р С’Р С‘Р СР В±Р С•РЎвЂљ Р С‘ Р В Р ВµР В·Р С•Р В»РЎРЉР Р†Р ВµРЎР‚",

        ["aim_targeting"] = "Р ТђР С‘РЎвЂљР В±Р С•Р С”РЎРѓРЎвЂ№ Р С‘ Р В¦Р ВµР В»Р С‘",

        ["enable_aim"] = "Р вЂ™Р С”Р В»РЎР‹РЎвЂЎР С‘РЎвЂљРЎРЉ Р С’Р С‘Р СР В±Р С•РЎвЂљ",

        ["silent_aim"] = "Р РЋР В°Р в„–Р В»Р ВµР Р…РЎвЂљ Р С’Р С‘Р С",

        ["rcs"] = "Р С™Р С•Р Р…РЎвЂљРЎР‚Р С•Р В»РЎРЉ Р С•РЎвЂљР Т‘Р В°РЎвЂЎР С‘ (RCS)",

        ["auto_shoot"] = "Р С’Р Р†РЎвЂљР С•-Р Р†РЎвЂ№РЎРѓРЎвЂљРЎР‚Р ВµР В»",

        ["doubletap"] = "Double Tap (Р вЂРЎвЂ№РЎРѓРЎвЂљРЎР‚РЎвЂ№Р в„– Р Т‘Р В°Р В±Р В»-РЎв‚¬Р С•РЎвЂљ)",

        ["resolver"] = "HvH Р В Р ВµР В·Р С•Р В»РЎРЉР Р†Р ВµРЎР‚ РЎС“Р С–Р В»Р С•Р Р†",

        ["resolver_mode"] = "Р В Р ВµР В¶Р С‘Р С РЎР‚Р ВµР В·Р С•Р В»РЎРЉР Р†Р ВµРЎР‚Р В°",

        ["multipoint"] = "Р СљРЎС“Р В»РЎРЉРЎвЂљР С‘Р С—Р С•Р С‘Р Р…РЎвЂљРЎвЂ№ РЎвЂ¦Р С‘РЎвЂљР В±Р С•Р С”РЎРѓР С•Р Р†",

        ["mp_scale"] = "Р В Р В°Р Т‘Р С‘РЎС“РЎРѓ Р СРЎС“Р В»РЎРЉРЎвЂљР С‘Р С—Р С•Р С‘Р Р…РЎвЂљР С•Р Р†",

        ["aim_fov"] = "Р Р€Р С–Р С•Р В» Р С•Р В±Р В·Р С•РЎР‚Р В° (FOV)",

        ["fov_circle"] = "Р С™РЎР‚РЎС“Р С– FOV Р Р…Р В° РЎРЊР С”РЎР‚Р В°Р Р…Р Вµ",

        ["shoot_mode"] = "Р В Р ВµР В¶Р С‘Р С РЎРѓРЎвЂљРЎР‚Р ВµР В»РЎРЉР В±РЎвЂ№",

        ["wall_check"] = "Р СџРЎР‚Р С•Р Р†Р ВµРЎР‚Р С”Р В° Р Р†Р С‘Р Т‘Р С‘Р СР С•РЎРѓРЎвЂљР С‘ (LoS)",

        ["min_damage"] = "Р СљР С‘Р Р…Р С‘Р СР В°Р В»РЎРЉР Р…РЎвЂ№Р в„– РЎС“РЎР‚Р С•Р Р…",

        ["min_damage_override"] = "Р С›Р Р†Р ВµРЎР‚РЎР‚Р В°Р в„–Р Т‘ Р СР С‘Р Р…. РЎС“РЎР‚Р С•Р Р…Р В°",

        ["target_players"] = "Р В¦Р ВµР В»Р С‘РЎвЂљРЎРЉРЎРѓРЎРЏ Р Р† Р С‘Р С–РЎР‚Р С•Р С”Р С•Р Р†",

        ["team_check"] = "Р СџРЎР‚Р С•Р Р†Р ВµРЎР‚Р С”Р В° Р С”Р С•Р СР В°Р Р…Р Т‘РЎвЂ№ (Р СњР Вµ Р В±Р С‘РЎвЂљРЎРЉ РЎРѓР Р†Р С•Р С‘РЎвЂ¦)",

        ["target_npcs"] = "Р В¦Р ВµР В»Р С‘РЎвЂљРЎРЉРЎРѓРЎРЏ Р Р† NPC Р С‘ Р В±Р С•РЎвЂљР С•Р Р†",

        ["vis_esp"] = "ESP Р ВР С–РЎР‚Р С•Р С”Р С•Р Р† Р С‘ NPC",

        ["vis_world"] = "Р СљР С‘РЎР‚ Р С‘ Р С™Р В°Р СР ВµРЎР‚Р В°",

        ["enable_esp"] = "Р вЂ™Р С”Р В»РЎР‹РЎвЂЎР С‘РЎвЂљРЎРЉ ESP",

        ["boxes"] = "2D Р вЂР С•Р С”РЎРѓРЎвЂ№",

        ["names_class"] = "Р ВР СР ВµР Р…Р В° Р С‘ Р С”Р В»Р В°РЎРѓРЎРѓ РЎвЂ Р ВµР В»Р С‘",

        ["health_status"] = "Р СџР С•Р В»Р С•РЎРѓР В° Р В·Р Т‘Р С•РЎР‚Р С•Р Р†РЎРЉРЎРЏ",

        ["snaplines"] = "Р вЂєР С‘Р Р…Р С‘Р С‘ Р С” РЎвЂ Р ВµР В»Р С‘",

        ["thirdperson"] = "Р вЂ™Р С‘Р Т‘ Р С•РЎвЂљ 3-Р С–Р С• Р В»Р С‘РЎвЂ Р В°",

        ["tp_dist"] = "Р вЂќР С‘РЎРѓРЎвЂљР В°Р Р…РЎвЂ Р С‘РЎРЏ Р С”Р В°Р СР ВµРЎР‚РЎвЂ№",

        ["cam_fov"] = "Р Р€Р С–Р С•Р В» Р С•Р В±Р В·Р С•РЎР‚Р В° Р С”Р В°Р СР ВµРЎР‚РЎвЂ№",

        ["fov_ring"] = "Р С™РЎР‚РЎС“Р С– FOV Р Р…Р В° РЎРЊР С”РЎР‚Р В°Р Р…Р Вµ",

        ["misc_move"] = "Р вЂќР Р†Р С‘Р В¶Р ВµР Р…Р С‘Р Вµ Р С‘ Р В­Р С”РЎР‚Р В°Р Р…",

        ["misc_hit"] = "Р С›РЎвЂљР С”Р В»Р С‘Р С” Р С—Р С•Р С—Р В°Р Т‘Р В°Р Р…Р С‘Р в„– Р С‘ Р РЋР С‘РЎРѓРЎвЂљР ВµР СР В°",

        ["bhop"] = "Р С’Р Р†РЎвЂљР С•-РЎР‚Р В°РЎРѓР С—РЎР‚РЎвЂ№Р В¶Р С”Р В° (Bhop)",

        ["autostrafe"] = "Р С’Р Р†РЎвЂљР С•-РЎРѓРЎвЂљРЎР‚Р ВµР в„–РЎвЂћР ВµРЎР‚",

        ["strafer_mode"] = "Р В Р ВµР В¶Р С‘Р С РЎРѓРЎвЂљРЎР‚Р ВµР в„–РЎвЂћР ВµРЎР‚Р В°",

        ["edgejump"] = "Р СџРЎР‚РЎвЂ№Р В¶Р С•Р С” РЎРѓ Р С”РЎР‚Р В°РЎРЏ (Edge Jump)",

        ["fakeduck"] = "Р В¤Р ВµР в„–Р С”-Р С—РЎР‚Р С‘РЎРѓР ВµР Т‘ (Fake Duck)",

        ["crouchjump"] = "Crouch Jump (Air Duck)",

        ["autopeek"] = "Р С’Р Р†РЎвЂљР С•-Р С—Р С‘Р С” (Quick Peek)",

        ["pedals"] = "Subtick Exploit (Р СџР ВµР Т‘Р В°Р В»Р С‘)",

        ["autoreload"] = "Р С’Р Р†РЎвЂљР С•-Р С—Р ВµРЎР‚Р ВµР В·Р В°РЎР‚РЎРЏР Т‘Р С”Р В°",

        ["keybinds_hud"] = "Р РЋР С—Р С‘РЎРѓР С•Р С” Р В±Р С‘Р Р…Р Т‘Р С•Р Р† (HUD)",

        ["aspect_ratio"] = "Р В Р В°РЎРѓРЎвЂљРЎРЏР В¶Р ВµР Р…Р С‘Р Вµ РЎРЊР С”РЎР‚Р В°Р Р…Р В° (Aspect)",

        ["aspect_scale"] = "Р РЋР С•Р С•РЎвЂљР Р…Р С•РЎв‚¬Р ВµР Р…Р С‘Р Вµ РЎРѓРЎвЂљР С•РЎР‚Р С•Р Р…",

        ["watermark"] = "Р вЂ™Р В°РЎвЂљР ВµРЎР‚Р СР В°РЎР‚Р С” Р С‘ РЎРѓР С—Р С‘Р Т‘Р С•Р СР ВµРЎвЂљРЎР‚",

        ["hitmarkers"] = "Р ТђР С‘РЎвЂљР СР В°РЎР‚Р С”Р ВµРЎР‚ Р Р…Р В° Р С—РЎР‚Р С‘РЎвЂ Р ВµР В»Р Вµ (X)",

        ["dmg_numbers"] = "Р вЂ™РЎРѓР С—Р В»РЎвЂ№Р Р†Р В°РЎР‹РЎвЂ°Р С‘Р в„– РЎС“РЎР‚Р С•Р Р… (-HP)",

        ["hitsounds"] = "Р вЂ”Р Р†РЎС“Р С”Р С‘ Р С—Р С•Р С—Р В°Р Т‘Р В°Р Р…Р С‘РЎРЏ (Hitsound)",

        ["hitsound_preset"] = "Р СџРЎР‚Р ВµРЎРѓР ВµРЎвЂљ Р В·Р Р†РЎС“Р С”Р В°",

        ["menu_bind"] = "Р С™Р В»Р В°Р Р†Р С‘РЎв‚¬Р В° Р С•РЎвЂљР С”РЎР‚РЎвЂ№РЎвЂљР С‘РЎРЏ Р СР ВµР Р…РЎР‹:",

        ["reset_default"] = "Р РЋР В±РЎР‚Р С•РЎРѓР С‘РЎвЂљРЎРЉ Р Р…Р В°РЎРѓРЎвЂљРЎР‚Р С•Р в„–Р С”Р С‘",

        ["opt_theme"] = "Р В¦Р Р†Р ВµРЎвЂљР С•Р Р†Р В°РЎРЏ РЎвЂљР ВµР СР В° Р СР ВµР Р…РЎР‹",

        ["opt_lang"] = "Р Р‡Р В·РЎвЂ№Р С” Р С‘Р Р…РЎвЂљР ВµРЎР‚РЎвЂћР ВµР в„–РЎРѓР В°",

        ["accent_preset"] = "Р С›РЎРѓР Р…Р С•Р Р†Р Р…Р С•Р в„– РЎвЂ Р Р†Р ВµРЎвЂљ Р В°Р С”РЎвЂ Р ВµР Р…РЎвЂљР В°",

        ["ui_language"] = "Р вЂ™РЎвЂ№Р В±Р С•РЎР‚ РЎРЏР В·РЎвЂ№Р С”Р В° (Language)"

    }

}

function Garrylose.L(key, fallback)

    local lang = Garrylose.Config.language or "ru"

    local dict = Garrylose.Languages[lang] or Garrylose.Languages["ru"]

    return dict[key] or fallback or key

end

hook.Add("InitPostEntity", "Garrylose_AutoLoadDefaultCFG", function()

    if file.Exists("garrylose_configs/default.json", "DATA") then

        Garrylose.LoadConfig("default.json")

    end

end)

-- 3. HARDWARE KEYBIND LISTENER & MENU TOGGLER

local keyStates = {}

function Garrylose.ToggleMenu()

    if IsValid(Garrylose.MenuFrame) then

        Garrylose.MenuFrame:Remove()

        Garrylose.MenuFrame = nil

    else

        if Garrylose.OpenMenu then

            Garrylose.OpenMenu()

        end

    end

end

local function GetActiveBindsList()

    return {

        { config = "bind_aimbot", action = function() Garrylose.Config.aimbot_enabled = not Garrylose.Config.aimbot_enabled end, name = "Aimbot", targetVar = "aimbot_enabled" },

        { config = "bind_antiaim", action = function() Garrylose.Config.antiaim_enabled = not Garrylose.Config.antiaim_enabled end, name = "Anti-Aim", targetVar = "antiaim_enabled" },

        { config = "bind_thirdperson", action = function() Garrylose.Config.thirdperson_enabled = not Garrylose.Config.thirdperson_enabled end, name = "Thirdperson", targetVar = "thirdperson_enabled" },

        { config = "bind_radar", action = function() Garrylose.Config.radar_enabled = not Garrylose.Config.radar_enabled end, name = "Radar", targetVar = "radar_enabled" },

        { config = "bind_esp", action = function() Garrylose.Config.esp_enabled = not Garrylose.Config.esp_enabled end, name = "ESP", targetVar = "esp_enabled" },

        { config = "bind_bhop", action = function() Garrylose.Config.bhop_enabled = not Garrylose.Config.bhop_enabled end, name = "Bhop", targetVar = "bhop_enabled" },

        { config = "bind_autostrafe", action = function() Garrylose.Config.autostrafe_enabled = not Garrylose.Config.autostrafe_enabled end, name = "Auto-Strafe", targetVar = "autostrafe_enabled" },

        { config = "bind_edgejump", action = function() Garrylose.Config.edgejump_enabled = not Garrylose.Config.edgejump_enabled end, name = "Edge-Jump", targetVar = "edgejump_enabled" },

        { config = "bind_fakeduck", action = function() Garrylose.Config.fakeduck_enabled = not Garrylose.Config.fakeduck_enabled end, name = "Fake-Duck", targetVar = "fakeduck_enabled" },

        { config = "bind_crouchjump", action = function() Garrylose.Config.crouchjump_enabled = not Garrylose.Config.crouchjump_enabled end, name = "Crouch-Jump", targetVar = "crouchjump_enabled" },

        { config = "bind_min_damage_override", action = function() Garrylose.Config.min_damage_override_active = not Garrylose.Config.min_damage_override_active end, name = "Min-Damage", targetVar = "min_damage_override_active" },

        { config = "bind_hitchance_override",  action = function() Garrylose.Config.hitchance_override_active = not Garrylose.Config.hitchance_override_active end,   name = "HC-Override", targetVar = "hitchance_override_active" },

        { config = "bind_triggerbot",         action = function() Garrylose.Config.triggerbot_enabled = not Garrylose.Config.triggerbot_enabled end,                 name = "Triggerbot", targetVar = "triggerbot_enabled" },

        { config = "bind_airstop",            action = function() Garrylose.Config.airstop_enabled = not Garrylose.Config.airstop_enabled end,                       name = "Air-Stop",   targetVar = "airstop_enabled" },

        { config = "bind_panic",              action = function() if Garrylose.PanicUnload then Garrylose.PanicUnload() end end,                                      name = "Panic-Unload" },

        { config = "bind_doubletap", action = function() Garrylose.Config.doubletap_enabled = not Garrylose.Config.doubletap_enabled end, name = "Double-Tap", targetVar = "doubletap_enabled" },

        { config = "bind_manual_left", action = function() 

            Garrylose.Config.manual_aa_state = (Garrylose.Config.manual_aa_state == 1) and 0 or 1

            local stateName = (Garrylose.Config.manual_aa_state == 1) and "LEFT" or "OFF"

            notification.AddLegacy("Garrylose: Manual AA [" .. stateName .. "]", NOTIFY_GENERIC, 2)

        end, name = nil },

        { config = "bind_manual_right", action = function() 

            Garrylose.Config.manual_aa_state = (Garrylose.Config.manual_aa_state == 2) and 0 or 2

            local stateName = (Garrylose.Config.manual_aa_state == 2) and "RIGHT" or "OFF"

            notification.AddLegacy("Garrylose: Manual AA [" .. stateName .. "]", NOTIFY_GENERIC, 2)

        end, name = nil },

        { config = "bind_manual_back", action = function() 

            Garrylose.Config.manual_aa_state = (Garrylose.Config.manual_aa_state == 3) and 0 or 3

            local stateName = (Garrylose.Config.manual_aa_state == 3) and "BACK" or "OFF"

            notification.AddLegacy("Garrylose: Manual AA [" .. stateName .. "]", NOTIFY_GENERIC, 2)

        end, name = nil },

        { config = "bind_autopeek", action = function() 

            Garrylose.Config.autopeek_enabled = not Garrylose.Config.autopeek_enabled

            if Garrylose.Config.autopeek_enabled then

                local lp = LocalPlayer()

                if IsValid(lp) then

                    Garrylose.AutoPeekPos = lp:GetPos()

                    Garrylose.AutoPeekState = "IDLE"

                end

            else

                Garrylose.AutoPeekPos = nil

                Garrylose.AutoPeekState = nil

            end

        end, name = "Peek-Assist", targetVar = "autopeek_enabled" },

    }

end

local function IsKeyCurrentlyPressed(code)

    if not code or code == KEY_NONE or code == 0 then return false end

    if code < 107 then

        return input.IsKeyDown(code)

    else

        return input.IsMouseDown(code)

    end

end

local function TriggerBind(b)

    b.action()

    if b.name and b.targetVar then

        local state = Garrylose.Config[b.targetVar]

        notification.AddLegacy("Garrylose: " .. b.name .. " " .. (state and "[ON]" or "[OFF]"), NOTIFY_GENERIC, 2)

    end

end

hook.Add("Think", "Garrylose_UniversalKeybind_Think", function()

    if gui.IsConsoleVisible() or gui.IsGameUIVisible() then return end

    -- 1. Menu Toggle (Insert / Custom bind)

    local menuKey = Garrylose.Config.bind_menu or KEY_INSERT

    if menuKey and menuKey ~= KEY_NONE and menuKey ~= 0 then

        local isMenuDown = IsKeyCurrentlyPressed(menuKey)

        if isMenuDown then

            if not keyStates["bind_menu"] then

                keyStates["bind_menu"] = true

                Garrylose.ToggleMenu()

            end

        else

            keyStates["bind_menu"] = false

        end

    end

    -- If chatting / typing in a textbox / dragging UI, do not trigger combat binds

    if vgui.CursorVisible() then return end

    -- 2. Combat Feature Keybinds

    local binds = GetActiveBindsList()

    for _, b in ipairs(binds) do

        local key = Garrylose.Config[b.config]

        if key and key ~= KEY_NONE and key ~= 0 then

            local isDown = IsKeyCurrentlyPressed(key)

            if isDown then

                if not keyStates[b.config] then

                    keyStates[b.config] = true

                    TriggerBind(b)

                end

            else

                keyStates[b.config] = false

            end

        end

    end

end)

-- Chat Command Listener (!menu, /menu, .menu, !garrylose, /garrylose)

hook.Add("OnPlayerChat", "Garrylose_ChatCommands", function(ply, text, teamOnly, isDead)

    if ply == LocalPlayer() then

        local cmd = string.lower(string.Trim(text))

        if cmd == "!menu" or cmd == "/menu" or cmd == ".menu" or cmd == "!garrylose" or cmd == "/garrylose" or cmd == ".garrylose" or cmd == "!hvh" or cmd == "/hvh" or cmd == "-menu" then

            Garrylose.ToggleMenu()

            return true

        end

    end

end)

-- 4. CUSTOM PLUGIN API

function Garrylose.RegisterPlugin(id, pluginTable)

    Garrylose.Plugins[id] = pluginTable

    Garrylose.Plugins[id].enabled = pluginTable.enabled or false

    print("[Garrylose] Loaded Custom Plugin: " .. (pluginTable.name or id))

end

-- Built-in Plugin 2: Custom FOV Ring (Exact Mathematical Projection)

Garrylose.RegisterPlugin("fov_ring", {

    name = "Custom FOV Ring",

    author = "Garrylose Dev",

    enabled = true,

    onHUDPaint = function()

        if not Garrylose.Config.aimbot_enabled then return end

        local ply = LocalPlayer()

        if not IsValid(ply) then return end

        local currentFov = ply:GetFOV() or 90

        if currentFov <= 0 then currentFov = 90 end

        local aimFov = tonumber(Garrylose.Config.aimbot_fov) or 90

        local fovRadius = math.tan(math.rad(aimFov / 2)) / math.tan(math.rad(currentFov / 2)) * (ScrW() / 2)

        local ringCol = Garrylose.Config.col_fov_ring or Color(0, 190, 255, 140)

        surface.SetDrawColor(ringCol)

        local cx, cy = ScrW() / 2, ScrH() / 2

        local segments = 64

        for i = 1, segments do

            local a1 = math.rad((i - 1) * (360 / segments))

            local a2 = math.rad(i * (360 / segments))

            surface.DrawLine(cx + math.cos(a1) * fovRadius, cy + math.sin(a1) * fovRadius,

                             cx + math.cos(a2) * fovRadius, cy + math.sin(a2) * fovRadius)

        end

    end

})

file.CreateDir("garrylose_scripts")

local defaultRainbowCode = [[Garrylose.RegisterPlugin("rainbow_bar", {

    name = "Rainbow Bottom Bar",

    enabled = true,

    onHUDPaint = function()

        local w, h = ScrW(), ScrH()

        local barH = 4

        local t = CurTime() * 100

        local segs = 32

        local segW = math.ceil(w / segs)

        for i = 0, segs do

            local hue = (t + (i * (360 / segs))) % 360

            surface.SetDrawColor(HSVToColor(hue, 1, 1))

            surface.DrawRect(i * segW, h - barH, segW, barH)

        end

    end

})]]

local defaultCyberCrossCode = [[Garrylose.RegisterPlugin("cyber_crosshair", {

    name = "Cyber Ring Crosshair",

    enabled = true,

    onHUDPaint = function()

        local cx, cy = ScrW() / 2, ScrH() / 2

        local t = CurTime() * 3

        local col = HSVToColor((CurTime() * 90) % 360, 0.9, 1.0)

        draw.RoundedBox(2, cx - 2, cy - 2, 4, 4, col)

        for i = 1, 4 do

            local ang = t + ((i - 1) * (math.pi / 2))

            local x = cx + math.cos(ang) * 15

            local y = cy + math.sin(ang) * 15

            draw.RoundedBox(2, x - 2, y - 2, 4, 4, col)

        end

    end

})]]

local defaultKeystrokesCode = [[Garrylose.RegisterPlugin("keystrokes_hud", {

    name = "Keystrokes Movement HUD",

    enabled = true,

    onHUDPaint = function()

        local scrW, scrH = ScrW(), ScrH()

        local startX = scrW - 130

        local startY = scrH - 170

        local keySize = 32

        local sp = 4

        local keys = {

            { name = "W",  key = KEY_W,       x = startX + keySize + sp, y = startY },

            { name = "A",  key = KEY_A,       x = startX,                y = startY + keySize + sp },

            { name = "S",  key = KEY_S,       x = startX + keySize + sp, y = startY + keySize + sp },

            { name = "D",  key = KEY_D,       x = startX + (keySize + sp) * 2, y = startY + keySize + sp },

            { name = "JUMP", key = KEY_SPACE, x = startX,                y = startY + (keySize + sp) * 2, w = (keySize * 3) + (sp * 2), h = 20 },

        }

        local rainbow = HSVToColor((CurTime() * 90) % 360, 0.85, 1.0)

        local bgOff = Color(12, 16, 24, 210)

        local bgOn  = Color(rainbow.r, rainbow.g, rainbow.b, 170)

        for _, k in ipairs(keys) do

            local isDown = input.IsKeyDown(k.key)

            local kw = k.w or keySize

            local kh = k.h or keySize

            draw.RoundedBox(4, k.x, k.y, kw, kh, isDown and bgOn or bgOff)

            surface.SetDrawColor(isDown and rainbow or Color(40, 50, 70, 200))

            surface.DrawOutlinedRect(k.x, k.y, kw, kh)

            draw.SimpleText(k.name, "DefaultFixed", k.x + kw / 2, k.y + kh / 2, isDown and color_white or Color(170, 185, 210), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        end

    end

})]]

function Garrylose.GetAutoLoadScripts()

    if file.Exists("garrylose_autoload.json", "DATA") then

        local data = file.Read("garrylose_autoload.json", "DATA")

        local tbl = util.JSONToTable(data or "")

        if type(tbl) == "table" then return tbl end

    end

    return {}

end

function Garrylose.SetScriptAutoLoad(fn, state)

    local tbl = Garrylose.GetAutoLoadScripts()

    tbl[fn] = state and true or nil

    file.Write("garrylose_autoload.json", util.TableToJSON(tbl, true))

end

function Garrylose.IsScriptAutoLoad(fn)

    local tbl = Garrylose.GetAutoLoadScripts()

    return tbl[fn] == true

end

local function EnsureDefaultScripts()

    file.CreateDir("garrylose_scripts")

    if not file.Exists("garrylose_scripts/rainbow_bar.txt", "DATA") then

        file.Write("garrylose_scripts/rainbow_bar.txt", defaultRainbowCode)

    end

    if not file.Exists("garrylose_scripts/cyber_cross.txt", "DATA") then

        file.Write("garrylose_scripts/cyber_cross.txt", defaultCyberCrossCode)

    end

    if not file.Exists("garrylose_scripts/keystrokes_hud.txt", "DATA") then

        file.Write("garrylose_scripts/keystrokes_hud.txt", defaultKeystrokesCode)

    end

end

EnsureDefaultScripts()

hook.Add("InitPostEntity", "Garrylose_LoadSavedUserScript", function()

    EnsureDefaultScripts()

    -- Auto-load only scripts that have auto-load enabled

    local scriptFiles = file.Find("garrylose_scripts/*.txt", "DATA")

    for _, sf in ipairs(scriptFiles or {}) do

        if Garrylose.IsScriptAutoLoad(sf) then

            local code = file.Read("garrylose_scripts/" .. sf, "DATA")

            if code and code ~= "" then

                RunString(code, "Garrylose_" .. sf)

                print("[Garrylose] Auto-loaded script: " .. sf)

            end

        end

    end

end)

-- HIGH-PERFORMANCE ENTITY & TARGET CACHING SYSTEM (Zero-Lag Engine)

Garrylose.CachedTargets = Garrylose.CachedTargets or {}

local nextTargetCacheTime = 0

local ignoredNPCs = {

    ["npc_grenade_frag"] = true,

    ["npc_tripmine"] = true,

    ["npc_satchel"] = true,

    ["npc_bullseye"] = true,

    ["npc_heli_bomb"] = true,

    ["npc_handgrenade"] = true,

    ["npc_contactgrenade"] = true,

    ["npc_laserdot"] = true,

    ["npc_spotlight"] = true,

    ["npc_maker"] = true,

    ["npc_template_maker"] = true,

    ["npc_launcher"] = true,

}

local function IsIgnoredEntity(ent, className)

    if not IsValid(ent) then return true end

    local cls = className or string.lower(ent:GetClass() or "")

    if ignoredNPCs[cls] then return true end

    if string.find(cls, "grenade") or string.find(cls, "tripmine") or string.find(cls, "satchel") or string.find(cls, "bullseye") or string.find(cls, "laserdot") or string.find(cls, "maker") then

        return true

    end

    return false

end

local function UpdateTargetCache()

    if CurTime() < nextTargetCacheTime then return end

    nextTargetCacheTime = CurTime() + 0.1 -- Update target list 10 times per second instead of every frame

    table.Empty(Garrylose.CachedTargets)

    local ply = LocalPlayer()

    if not IsValid(ply) then return end

    -- 1. Cache Players

    if Garrylose.Config.aimbot_target_players or Garrylose.Config.esp_enabled then

        for _, p in ipairs(player.GetAll()) do

            if IsValid(p) and p ~= ply and p:Alive() and p:GetMoveType() ~= MOVETYPE_NOCLIP then

                if not Garrylose.Config.aimbot_team_check or (p:Team() ~= ply:Team() or p:Team() == 0 or p:Team() == 1001) then

                    table.insert(Garrylose.CachedTargets, p)

                end

            end

        end

    end

    -- 2. Cache NPCs & Nextbots (Filtering out grenades, tripmines, makers)

    if Garrylose.Config.aimbot_target_npcs or Garrylose.Config.esp_enabled then

        for _, ent in ipairs(ents.GetAll()) do

            if IsValid(ent) and ent ~= ply then

                local className = string.lower(ent:GetClass() or "")

                if not IsIgnoredEntity(ent, className) then

                    if ent:IsNPC() and ent:Health() > 0 then

                        table.insert(Garrylose.CachedTargets, ent)

                    elseif ent:IsNextBot() and (ent:Health() > 0 or not ent:IsDormant()) then

                        table.insert(Garrylose.CachedTargets, ent)

                    elseif (string.find(className, "npc_") or string.find(className, "nextbot") or ent.Type == "nextbot") and ent:Health() > 0 then

                        table.insert(Garrylose.CachedTargets, ent)

                    end

                end

            end

        end

    end

end

-- 5. TARGET VALIDATION ENGINE

local function IsValidTarget(ent)

    if not IsValid(ent) or ent == LocalPlayer() then return false end

    if IsIgnoredEntity(ent) then return false end

    -- Check Players

    if ent:IsPlayer() and Garrylose.Config.aimbot_target_players then

        if not ent:Alive() or ent:GetMoveType() == MOVETYPE_NOCLIP then return false end

        if Garrylose.Config.aimbot_team_check and ent:Team() == LocalPlayer():Team() and ent:Team() ~= 0 and ent:Team() ~= 1001 then

            return false

        end

        return true

    end

    -- Check NPCs & Nextbots

    if Garrylose.Config.aimbot_target_npcs then

        if ent:IsNPC() then

            return ent:Health() > 0

        end

        if ent:IsNextBot() then

            return ent:Health() > 0

        end

        local className = string.lower(ent:GetClass() or "")

        if string.find(className, "npc_") or string.find(className, "nextbot") or ent.Type == "nextbot" then

            return ent:Health() > 0

        end

    end

    return false

end

-- --- FAST OPTIMIZED LINE OF SIGHT CHECK ---

local function IsTargetVisible(ply, target, targetPos)

    if not Garrylose.Config.aimbot_vischeck then return true end

    if not targetPos then return false end

    -- Fast 1-Ray Line of Sight Check (Massive FPS boost over double raycast)

    local trEye = util.TraceLine({

        start = ply:GetShootPos(),

        endpos = targetPos,

        filter = {ply, ply:GetActiveWeapon()},

        mask = MASK_SHOT

    })

    if trEye.Entity == target or trEye.Fraction >= 0.97 then

        return true

    end

    return false

end

-- Hitbox Scanning

local function GetBonePosSafe(ent, boneName, velPredict)
    if not IsValid(ent) then return nil end
    local b = ent:LookupBone(boneName)
    if not b then return nil end

    local matrix = ent:GetBoneMatrix(b)
    if matrix then
        local pos = matrix:GetTranslation()
        if pos and pos:LengthSqr() > 1 then
            return pos + (velPredict or Vector(0,0,0))
        end
    end

    local pos, ang = ent:GetBonePosition(b)
    if pos and pos:LengthSqr() > 1 then
        return pos + (velPredict or Vector(0,0,0))
    end

    return nil
end

local function GetAllTargetScanPoints(ply, ent)
    local points = {}
    if not IsValid(ent) then return points end

    if ent.InvalidateBoneCache then ent:InvalidateBoneCache() end
    ent:SetupBones()

    local velPredict = Vector(0, 0, 0)
    local targetVel = (ent.GetVelocity and ent:GetVelocity()) or Vector(0, 0, 0)
    local targetSpeed = targetVel:Length2D()
    local activeWep = ply:GetActiveWeapon()

    -- ADVANCED TRAJECTORY & LERP EXTRAPOLATION
    local isProjectile = IsValid(activeWep) and (activeWep:GetClass() == "weapon_crossbow" or activeWep:GetClass() == "weapon_rpg")

    if isProjectile and ent:IsPlayer() and targetSpeed > 20 then
        local dist = ply:GetShootPos():Distance(ent:WorldSpaceCenter())
        local projSpeed = (activeWep:GetClass() == "weapon_crossbow") and 2000 or 1500
        local flyTime = dist / projSpeed
        local grav = (GetConVar("sv_gravity") and GetConVar("sv_gravity"):GetFloat()) or 600
        
        local zOffset = targetVel.z * flyTime
        if not ent:OnGround() then
            zOffset = zOffset - (0.5 * grav * flyTime * flyTime)
        end
        velPredict = Vector(targetVel.x * flyTime, targetVel.y * flyTime, zOffset)
    else
        -- Hitscan Weapons (AK, M4, Pistol, Shotgun, etc)
        -- NEVER extrapolate velocity for hitscan. We rely 100% on engine Backtracking (cmd:SetTickCount).
        -- Aiming ahead of the target while sending a past tick causes bullets to hit thin air.
        velPredict = Vector(0, 0, 0)
    end

    local ang = ent:EyeAngles()
    local right = ang:Right()
    local fwd = ang:Forward()
    local up = Vector(0, 0, 1)
    local scale = math.Clamp(tonumber(Garrylose.Config.aimbot_multipoint_scale) or 0.8, 0.1, 1.0)
    local doMultipoint = Garrylose.Config.aimbot_multipoint or false

    local headPoints = {}
    local bodyPoints = {}
    local limbPoints = {}

    -- 1. HEAD SCAN POINTS
    if Garrylose.Config.aimbot_hitbox_head then
        local baseHead = GetBonePosSafe(ent, "ValveBiped.Bip01_Head1", velPredict) or
                         GetBonePosSafe(ent, "head", velPredict) or
                         GetBonePosSafe(ent, "ValveBiped.Bip01_Head", velPredict)

        if not baseHead then
            local attach = ent:LookupAttachment("eyes") or ent:LookupAttachment("head")
            if attach and attach > 0 then
                local attData = ent:GetAttachment(attach)
                if attData and attData.Pos and attData.Pos:LengthSqr() > 1 then
                    baseHead = attData.Pos + velPredict
                end
            end
        end

        if not baseHead then
            baseHead = (ent.EyePos and ent:EyePos() or (ent:GetPos() + Vector(0, 0, 60))) + velPredict
        end

        table.insert(headPoints, baseHead)

        if doMultipoint or targetSpeed > 80 then
            local r = 1.6 * scale
            table.insert(headPoints, baseHead + (right * r))
            table.insert(headPoints, baseHead - (right * r))
            table.insert(headPoints, baseHead + (up * (r * 0.8)))
            table.insert(headPoints, baseHead + (fwd * (r * 0.6)))

            -- Precision top skull / forehead point for rushing / bhopping enemies
            if targetSpeed > 80 then
                table.insert(headPoints, baseHead + (up * 1.5))
            end
        end
    end

    -- 2. CHEST SCAN POINTS
    if Garrylose.Config.aimbot_hitbox_chest then
        local chestPos = GetBonePosSafe(ent, "ValveBiped.Bip01_Spine2", velPredict) or
                         GetBonePosSafe(ent, "spine", velPredict) or
                         GetBonePosSafe(ent, "ValveBiped.Bip01_Spine4", velPredict) or
                         (ent:WorldSpaceCenter() + Vector(0, 0, 4) + velPredict)

        table.insert(bodyPoints, chestPos)

        if doMultipoint then
            local r = 4.5 * scale
            table.insert(bodyPoints, chestPos + (up * (r * 1.0)))
            table.insert(bodyPoints, chestPos + (right * r))
            table.insert(bodyPoints, chestPos - (right * r))
        end
    end

    -- 3. STOMACH / PELVIS SCAN POINTS
    if Garrylose.Config.aimbot_hitbox_stomach then
        local pelvisPos = GetBonePosSafe(ent, "ValveBiped.Bip01_Pelvis", velPredict) or
                          GetBonePosSafe(ent, "ValveBiped.Bip01_Spine", velPredict) or
                          (ent:WorldSpaceCenter() - Vector(0, 0, 8) + velPredict)

        table.insert(bodyPoints, pelvisPos)

        if doMultipoint then
            local r = 4.0 * scale
            table.insert(bodyPoints, pelvisPos + (right * r))
            table.insert(bodyPoints, pelvisPos - (right * r))
        end
    end

    -- 4. ARMS & LEGS
    if Garrylose.Config.aimbot_hitbox_arms then
        for _, b in ipairs({"ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_R_Forearm"}) do
            local p = GetBonePosSafe(ent, b, velPredict)
            if p then table.insert(limbPoints, p) end
        end
    end

    if Garrylose.Config.aimbot_hitbox_legs then
        for _, b in ipairs({"ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_L_Foot", "ValveBiped.Bip01_R_Foot"}) do
            local p = GetBonePosSafe(ent, b, velPredict)
            if p then table.insert(limbPoints, p) end
        end
    end

    -- Assembly
    if Garrylose.Config.aimbot_head_priority then
        for _, p in ipairs(headPoints) do table.insert(points, { pos = p, isHead = true }) end
        for _, p in ipairs(bodyPoints) do table.insert(points, { pos = p, isHead = false }) end
        for _, p in ipairs(limbPoints) do table.insert(points, { pos = p, isHead = false }) end
    else
        for _, p in ipairs(bodyPoints) do table.insert(points, { pos = p, isHead = false }) end
        for _, p in ipairs(headPoints) do table.insert(points, { pos = p, isHead = true }) end
        for _, p in ipairs(limbPoints) do table.insert(points, { pos = p, isHead = false }) end
    end

    if #points == 0 then
        table.insert(points, { pos = ent:WorldSpaceCenter() + velPredict, isHead = false })
    end

    return points
end

-- Simple CS2-Style Weapon Damage Estimator

local function GetCS2EstimatedDamage(ply, isHead)

    local wep = ply:GetActiveWeapon()

    if not IsValid(wep) then return 25 end

    local base = 25

    local wClass = string.lower(wep:GetClass() or "")

    if wep.Primary and tonumber(wep.Primary.Damage) and wep.Primary.Damage > 0 then

        base = tonumber(wep.Primary.Damage)

    elseif string.find(wClass, "smg1") then

        base = (GetConVar("sk_plr_dmg_smg1") and GetConVar("sk_plr_dmg_smg1"):GetInt()) or 4

    elseif string.find(wClass, "pistol") then

        base = (GetConVar("sk_plr_dmg_pistol") and GetConVar("sk_plr_dmg_pistol"):GetInt()) or 5

    elseif string.find(wClass, "357") then

        base = (GetConVar("sk_plr_dmg_357") and GetConVar("sk_plr_dmg_357"):GetInt()) or 75

    elseif string.find(wClass, "ar2") then

        base = (GetConVar("sk_plr_dmg_ar2") and GetConVar("sk_plr_dmg_ar2"):GetInt()) or 8

    elseif string.find(wClass, "shotgun") then

        base = 64

    elseif string.find(wClass, "crossbow") then

        base = 100

    elseif string.find(wClass, "awp") then

        base = 115

    elseif string.find(wClass, "scout") or string.find(wClass, "ssg08") then

        base = 75

    elseif string.find(wClass, "deagle") or string.find(wClass, "revolver") then

        base = 54

    elseif string.find(wClass, "ak47") or string.find(wClass, "m4") then

        base = 34

    end

    if isHead then

        return base * 3.5

    else

        return base * 1.0

    end

end

-- Compatibility helpers

local function GetTargetMultipoints(ply, ent, hitboxType)

    return GetAllTargetScanPoints(ply or LocalPlayer(), ent)

end

local function GetTargetAimPos(ent, hitboxType)

    if not IsValid(ent) then return nil end

    local pts = GetAllTargetScanPoints(LocalPlayer(), ent)

    if pts and pts[1] then

        return (type(pts[1]) == "table" and pts[1].pos) or pts[1]

    end

    return ent:WorldSpaceCenter()

end

-- Movement Correction

local function FixMovement(cmd, realAngles, fakeAngles)

    local fmove = cmd:GetForwardMove()

    local smove = cmd:GetSideMove()

    if fmove == 0 and smove == 0 then return end

    -- Exact 2D angle delta transformation for Source engine wishdir:

    -- Ensures full WASD agility and strafing in any direction regardless of spin speed

    local delta = math.rad(fakeAngles.y - realAngles.y)

    local cosD = math.cos(delta)

    local sinD = math.sin(delta)

    local newFmove = cosD * fmove - sinD * smove

    local newSmove = sinD * fmove + cosD * smove

    cmd:SetForwardMove(math.Clamp(newFmove, -10000, 10000))

    cmd:SetSideMove(math.Clamp(newSmove, -10000, 10000))

end

-- 6. CORE ENGINE HOOKS

-- CreateMove Hook

-- MULTI-RAY CONE SAMPLING HITCHANCE ENGINE

local function CalculateWeaponHitchance(ply, target, targetAimPos, wep)
    if not IsValid(target) or not targetAimPos then return 100 end
    if Garrylose.Config.nospread_enabled then return 100 end

    local shootPos = ply:GetShootPos()
    local dir = (targetAimPos - shootPos):Angle()

    local spread = 0.005
    local isSniper = false
    if IsValid(wep) then
        local class = string.lower(wep:GetClass() or "")
        isSniper = (class == "weapon_crossbow" or class == "weapon_357" or
                    string.find(class, "sniper") ~= nil or string.find(class, "awp") ~= nil or
                    string.find(class, "scout") ~= nil or string.find(class, "ssg") ~= nil)
        if wep.Primary and tonumber(wep.Primary.Cone) and tonumber(wep.Primary.Cone) > 0 then
            spread = tonumber(wep.Primary.Cone)
        elseif wep.Cone and tonumber(wep.Cone) and tonumber(wep.Cone) > 0 then
            spread = tonumber(wep.Cone)
        end
        if isSniper then spread = 0.001 end
    end

    local vel2D = ply:GetVelocity():Length2D()
    if vel2D > 40 and not isSniper and not Garrylose.Config.aimbot_autostop then
        spread = spread * 1.3
    end

    local hitCount = 0
    local totalSamples = 16

    local targetRadius = 32
    if target:IsPlayer() or target:IsNPC() then
        local mins, maxs = target:GetCollisionBounds()
        if maxs and mins then
            targetRadius = math.max((maxs.x - mins.x) * 1.1, 28)
        end
    end

    local distToTarget = shootPos:Distance(targetAimPos)

    for i = 1, totalSamples do
        local randAngle = math.Rand(0, math.pi * 2)
        local randRadius = math.Rand(0, 1)
        local spreadX = math.cos(randAngle) * randRadius * spread
        local spreadY = math.sin(randAngle) * randRadius * spread
        local spreadDir = dir:Forward() + (dir:Right() * spreadX) + (dir:Up() * spreadY)

        local tr = util.TraceLine({
            start = shootPos,
            endpos = shootPos + (spreadDir * (distToTarget + 64)),
            filter = ply,
            mask = MASK_SHOT
        })

        local rayEnd = shootPos + (spreadDir * distToTarget)
        local distFromRay = rayEnd:Distance(targetAimPos)

        if tr.Entity == target or distFromRay <= targetRadius then
            hitCount = hitCount + 1
        end
    end

    return math.Round((hitCount / totalSamples) * 100)
end

hook.Add("CreateMove", "Garrylose_Core_CreateMove", function(cmd)

    local ply = LocalPlayer()

    if not IsValid(ply) or not ply:Alive() then return end

    -- Freecam Movement
    local fcKey = Garrylose.Config.bind_freecam
    if fcKey and fcKey > 0 and IsKeyCurrentlyPressed(fcKey) then
        if not Garrylose.FreecamKeyHeld then
            Garrylose.FreecamKeyHeld = true
            Garrylose.Config.freecam_enabled = not Garrylose.Config.freecam_enabled
        end
    else
        Garrylose.FreecamKeyHeld = false
    end

    local is_freecam = Garrylose.Config.freecam_enabled
    if is_freecam and not Garrylose.OldFreecam then
        Garrylose.FreecamPos = ply:EyePos()
        Garrylose.FreecamAng = cmd:GetViewAngles()
    end
    Garrylose.OldFreecam = is_freecam

    if is_freecam then
        local speed = (tonumber(Garrylose.Config.freecam_speed) or 10) * (IsKeyCurrentlyPressed(KEY_LSHIFT) and 2 or 1)
        local fwd = Garrylose.FreecamAng:Forward()
        local right = Garrylose.FreecamAng:Right()
        local up = Garrylose.FreecamAng:Up()
        
        local fSpeed, sSpeed, uSpeed = 0, 0, 0
        if IsKeyCurrentlyPressed(KEY_W) then fSpeed = 1 end
        if IsKeyCurrentlyPressed(KEY_S) then fSpeed = -1 end
        if IsKeyCurrentlyPressed(KEY_A) then sSpeed = -1 end
        if IsKeyCurrentlyPressed(KEY_D) then sSpeed = 1 end
        if IsKeyCurrentlyPressed(KEY_SPACE) then uSpeed = 1 end
        if IsKeyCurrentlyPressed(KEY_LCONTROL) then uSpeed = -1 end
        
        Garrylose.FreecamPos = Garrylose.FreecamPos + (fwd * fSpeed * speed)
        Garrylose.FreecamPos = Garrylose.FreecamPos + (right * sSpeed * speed)
        Garrylose.FreecamPos = Garrylose.FreecamPos + (up * uSpeed * speed)
        
        Garrylose.FreecamAng = cmd:GetViewAngles()
        cmd:ClearMovement()
        cmd:ClearButtons()
        return
    end

    -- Flashlight Spammer
    if Garrylose.Config.flash_spam then
        cmd:SetImpulse(100)
    end
    
    -- Auto Reload
    if Garrylose.Config.auto_reload then
        local wep = ply:GetActiveWeapon()
        if IsValid(wep) and wep:Clip1() == 0 then
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_RELOAD))
        end
    end

    -- --- Global Double Tap Continuous Recharge Engine ---

    local curT = CurTime()

    local dtDelay = Garrylose.DTRechargeDelay or 0.35

    if Garrylose.Config.doubletap_enabled then

        if (curT - (Garrylose.LastDTShootTime or 0)) >= dtDelay then

            local wep = ply:GetActiveWeapon()

            if IsValid(wep) then

                local clip = wep:Clip1()

                if clip == -1 or clip >= 2 then

                    Garrylose.DoubleTapCharged = true

                end

            else

                Garrylose.DoubleTapCharged = true

            end

        end

    else

        Garrylose.DoubleTapCharged = false

    end

    -- Noclip bypass

    if ply:GetMoveType() == MOVETYPE_NOCLIP then

        Garrylose.RealViewAngles = cmd:GetViewAngles()

        return

    end

    -- --- High-Precision View Angle Tracking (Handles Silent Aim & Anti-Aim decoupling) ---

    local mouseX = cmd:GetMouseX()

    local mouseY = cmd:GetMouseY()

    local sens = GetConVar("sensitivity"):GetFloat() or 3.0

    local mPitch = GetConVar("m_pitch"):GetFloat() or 0.022

    local mYaw = GetConVar("m_yaw"):GetFloat() or 0.022

    if not Garrylose.RealViewAngles or Garrylose.RealViewAngles == Angle(0, 0, 0) then

        Garrylose.RealViewAngles = cmd:GetViewAngles()

    end

    -- Always track true mouse delta if Anti-Aim OR Silent Aim is active to prevent view snapping/drift

    if Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent then

        local newPitch = math.Clamp(Garrylose.RealViewAngles.p + (mouseY * mPitch * sens), -89, 89)

        local newYaw = math.NormalizeAngle(Garrylose.RealViewAngles.y - (mouseX * mYaw * sens))

        Garrylose.RealViewAngles = Angle(newPitch, newYaw, 0)

    else

        Garrylose.RealViewAngles = cmd:GetViewAngles()

    end

    local realAngles = Angle(Garrylose.RealViewAngles.p, Garrylose.RealViewAngles.y, 0)

    -- --- Auto Peek (Quick Peek Assist State Tracker) ---

    if Garrylose.Config.autopeek_enabled then

        if not Garrylose.AutoPeekPos then

            Garrylose.AutoPeekPos = ply:GetPos()

            Garrylose.AutoPeekState = "IDLE"

        end

        local rawFmove = cmd:GetForwardMove()

        local rawSmove = cmd:GetSideMove()

        local isPressingMovement = (rawFmove ~= 0 or rawSmove ~= 0 or cmd:KeyDown(IN_FORWARD) or cmd:KeyDown(IN_BACK) or cmd:KeyDown(IN_MOVELEFT) or cmd:KeyDown(IN_MOVERIGHT))

        local dist2D = (Garrylose.AutoPeekPos - ply:GetPos()):Length2D()

        -- Trigger RETURNING condition:

        -- 1) Fired weapon (manual click, aimbot auto-shot, or recent shot)

        if cmd:KeyDown(IN_ATTACK) or Garrylose.ShotState or (Garrylose.LastShotTime and (CurTime() - Garrylose.LastShotTime) < 0.15) then

            Garrylose.AutoPeekState = "RETURNING"

        -- 2) Walked away from origin point (>20 units) and released movement keys / stopped moving

        elseif dist2D > 20 and not isPressingMovement and Garrylose.AutoPeekState ~= "RETURNING" then

            Garrylose.AutoPeekState = "RETURNING"

        end

    else

        Garrylose.AutoPeekPos = nil

        Garrylose.AutoPeekState = nil

    end

    -- --- Fake Duck Engine (Cycle-Based Duck Toggle) ---

    if Garrylose.Config.fakeduck_enabled and ply:OnGround() then

        Garrylose.FakeDuckTick = (Garrylose.FakeDuckTick or 0) + 1

        -- Alternate: 7 ticks ducked, 1 tick standing to keep server duck amount near 1.0

        if (Garrylose.FakeDuckTick % 8) < 7 then

            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))

        else

            cmd:RemoveKey(IN_DUCK)

        end

    else

        Garrylose.FakeDuckTick = 0

    end

    -- --- Edge Jump Engine ---

    if Garrylose.Config.edgejump_enabled and ply:OnGround() and ply:GetMoveType() == MOVETYPE_WALK then

        local vel = ply:GetVelocity()

        if vel:Length2D() > 10 then

            local predictPos = ply:GetPos() + (vel * FrameTime() * 1.5)

            local trDown = util.TraceLine({

                start = predictPos + Vector(0, 0, 10),

                endpos = predictPos - Vector(0, 0, 40),

                filter = ply,

                mask = MASK_PLAYERSOLID

            })

            -- If the ground under next step drops off, trigger instant jump

            if not trDown.Hit then

                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))

            end

        end

    end

    local pPos = ply:GetPos()
    local vel = ply:GetVelocity()
    local speed2D = vel:Length2D()
    local dt = engine.TickInterval() or 0.015

    -- 1. Direct and Slope Contact Detection
    local mins, maxs = ply:GetCollisionBounds()
    local trGround = util.TraceHull({
        start = pPos + Vector(0, 0, 2),
        endpos = pPos - Vector(0, 0, 6),
        mins = mins,
        maxs = maxs,
        filter = ply,
        mask = MASK_PLAYERSOLID
    })

    local isTouchingGround = ply:OnGround() or (ply:GetGroundEntity() and IsValid(ply:GetGroundEntity())) or (trGround.Hit and trGround.HitNormal.z >= 0.1)
    local ground = isTouchingGround
    local onIncline = trGround.Hit and (trGround.HitNormal.z < 0.95 and trGround.HitNormal.z >= 0.1)
    local isHoldingDuck = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)

    -- --- Crouch Jump (Air Duck Engine) ---
    if Garrylose.Config.crouchjump_enabled and ply:GetMoveType() == MOVETYPE_WALK then
        if not ply:OnGround() then
            local trPreLand = util.TraceLine({
                start = pPos,
                endpos = pPos - Vector(0, 0, 24),
                filter = ply,
                mask = MASK_PLAYERSOLID
            })

            if trPreLand.Hit and vel.z < -40 then
                if not isHoldingDuck and not Garrylose.Config.fakeduck_enabled then
                    cmd:RemoveKey(IN_DUCK)
                end
            else
                Garrylose.DuckBurstTick = (Garrylose.DuckBurstTick or 0) + 1
                if (Garrylose.DuckBurstTick % 4) < 2 then
                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
                else
                    if not isHoldingDuck and not Garrylose.Config.fakeduck_enabled then
                        cmd:RemoveKey(IN_DUCK)
                    end
                end
            end
        else
            Garrylose.DuckBurstTick = 0
            if not isHoldingDuck and not Garrylose.Config.fakeduck_enabled then
                cmd:RemoveKey(IN_DUCK)
            end
        end
    end

    -- Auto Bhop
    if Garrylose.Config.bhop_enabled and cmd:KeyDown(IN_JUMP) then
        if isTouchingGround then
            if Garrylose.BhopWasInAir then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
                Garrylose.BhopWasInAir = false
            else
                -- Release jump for 1 tick to reset engine edge trigger on continuous slope contact
                cmd:RemoveKey(IN_JUMP)
                Garrylose.BhopWasInAir = true
            end
        else
            cmd:RemoveKey(IN_JUMP)
            Garrylose.BhopWasInAir = true
        end

        if cmd:KeyDown(IN_FORWARD) then
            cmd:SetForwardMove(450)
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_FORWARD))
        end
    else
        Garrylose.BhopWasInAir = true
    end

    -- --- Robust Ladder Detection ---
    local trLadder = util.TraceHull({
        start = ply:GetPos(),
        endpos = ply:GetPos() + Vector(0, 0, 2),
        mins = Vector(-18, -18, 0),
        maxs = Vector(18, 18, 72),
        filter = ply,
        mask = 536870912 -- CONTENTS_LADDER
    })

    local isOnLadder = (ply:GetMoveType() == MOVETYPE_LADDER) or (ply:GetMoveType() == 9) or (trLadder and trLadder.Hit)

    -- --- Auto Strafer Engine ---
    if Garrylose.Config.autostrafe_enabled and not ground and not isOnLadder and ply:GetMoveType() == MOVETYPE_WALK then
        local mode = tonumber(Garrylose.Config.autostrafe_mode) or 1

        -- Only clear forward move if user is NOT pressing W and NOT climbing an incline
        if not onIncline and not cmd:KeyDown(IN_FORWARD) and not cmd:KeyDown(IN_BACK) and speed2D > 15 then
            cmd:SetForwardMove(0)
            cmd:RemoveKey(IN_FORWARD)
            cmd:RemoveKey(IN_BACK)
        end

        if mode == 1 then

            -- Mode 1: Mouse / View Delta Strafer (Smooth Legit Air Acceleration)

            if mouseX > 0 then

                cmd:SetSideMove(10000)

                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVERIGHT))

                cmd:RemoveKey(IN_MOVELEFT)

            elseif mouseX < 0 then

                cmd:SetSideMove(-10000)

                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVELEFT))

                cmd:RemoveKey(IN_MOVERIGHT)

            else

                -- If mouse is stationary, check manual A/D keys

                if cmd:KeyDown(IN_MOVERIGHT) or cmd:GetSideMove() > 0 then

                    cmd:SetSideMove(10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVERIGHT))

                    cmd:RemoveKey(IN_MOVELEFT)

                elseif cmd:KeyDown(IN_MOVELEFT) or cmd:GetSideMove() < 0 then

                    cmd:SetSideMove(-10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVELEFT))

                    cmd:RemoveKey(IN_MOVERIGHT)

                end

            end

        elseif mode == 2 then

            -- Mode 2: Rage / Directional Auto-Strafer (Maximum Speed Gain)

            if speed < 30 then

                cmd:SetForwardMove(10000)

            else

                cmd:SetForwardMove(0)

                cmd:RemoveKey(IN_FORWARD)

                cmd:RemoveKey(IN_BACK)

                Garrylose.StrafeSwitch = not Garrylose.StrafeSwitch

                if Garrylose.StrafeSwitch then

                    cmd:SetSideMove(-10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVELEFT))

                    cmd:RemoveKey(IN_MOVERIGHT)

                else

                    cmd:SetSideMove(10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVERIGHT))

                    cmd:RemoveKey(IN_MOVELEFT)

                end

            end

        end

    end

    -- --- Auto Peek Absolute Return Navigation (Overrides ALL Manual & Other Movements) ---

    if Garrylose.Config.autopeek_enabled and Garrylose.AutoPeekPos and Garrylose.AutoPeekState == "RETURNING" then

        local myPos = ply:GetPos()

        local diff = Garrylose.AutoPeekPos - myPos

        local dist2D = diff:Length2D()

        if dist2D > 10 then

            local worldDir = Vector(diff.x / dist2D, diff.y / dist2D, 0)

            local worldWishVel = worldDir * 10000

            local realYaw = math.rad(realAngles.y)

            local realFwd = Vector(math.cos(realYaw), math.sin(realYaw), 0)

            local realRt  = Vector(math.sin(realYaw), -math.cos(realYaw), 0)

            local autoFmove = worldWishVel:Dot(realFwd)

            local autoSmove = worldWishVel:Dot(realRt)

            -- Absolute override of forward and side move

            cmd:SetForwardMove(math.Clamp(autoFmove, -10000, 10000))

            cmd:SetSideMove(math.Clamp(autoSmove, -10000, 10000))

            -- Strip manual movement keys completely so player input never fights the return

            cmd:RemoveKey(IN_FORWARD)

            cmd:RemoveKey(IN_BACK)

            cmd:RemoveKey(IN_MOVELEFT)

            cmd:RemoveKey(IN_MOVERIGHT)

        else

            -- Reached safe origin point!

            Garrylose.AutoPeekState = "IDLE"

            cmd:SetForwardMove(0)

            cmd:SetSideMove(0)

        end

    end

    -- --- Fast Target Cache Refresh ---

    UpdateTargetCache()

    -- --- Min Damage Override (Hold & Toggle) ---

    local overrideKey = Garrylose.Config.bind_min_damage_override

    local isOverrideHeld = false

    if overrideKey and overrideKey ~= KEY_NONE and overrideKey ~= 0 then

        if overrideKey >= 107 then

            isOverrideHeld = input.IsMouseDown(overrideKey)

        else

            isOverrideHeld = input.IsKeyDown(overrideKey)

        end

    end

    local isOverrideActive = isOverrideHeld or Garrylose.Config.min_damage_override_active

    local activeMinDmg = isOverrideActive and (tonumber(Garrylose.Config.aimbot_min_damage_override) or 1) or (tonumber(Garrylose.Config.aimbot_min_damage) or 1)

    -- --- Aimbot with CS2-Style Min Damage & Multi-Hitbox Hitscan ---

    local target = nil

    local targetAimPos = nil

    local bestFov = Garrylose.Config.aimbot_fov

    local shootPos = ply:GetShootPos()

    if Garrylose.Config.aimbot_enabled then

        local candidates = {}

        if IsValid(Garrylose.CurrentTarget) and IsValidTarget(Garrylose.CurrentTarget) then

            table.insert(candidates, Garrylose.CurrentTarget)

        end

        for _, ent in ipairs(Garrylose.CachedTargets) do

            if IsValid(ent) and ent ~= Garrylose.CurrentTarget and IsValidTarget(ent) then

                table.insert(candidates, ent)

            end

        end

        for _, ent in ipairs(candidates) do

            if IsValid(ent) and ent:Health() > 0 then

                local entHp = ent:Health()

                local entPos = ent:WorldSpaceCenter()

                local roughAngle = (entPos - shootPos):Angle()

                local fovP = math.abs(math.AngleDifference(realAngles.p, roughAngle.p))

                local fovY = math.abs(math.AngleDifference(realAngles.y, roughAngle.y))

                local roughFov = math.sqrt(fovP * fovP + fovY * fovY)

                if roughFov <= Garrylose.Config.aimbot_fov + 25 then

                    local points = GetAllTargetScanPoints(ply, ent)
                    local isCurrentTarget = (ent == Garrylose.CurrentTarget)
                    local maxFov = isCurrentTarget and (Garrylose.Config.aimbot_fov + 15) or Garrylose.Config.aimbot_fov

                    for _, ptData in ipairs(points) do
                        local pt = (type(ptData) == "table" and ptData.pos) or ptData
                        local isHead = (type(ptData) == "table" and ptData.isHead) or false

                        if isvector(pt) then
                            -- CS2 Min Damage Check
                            local estDmg = GetCS2EstimatedDamage(ply, isHead)
                            local passesDamage = (activeMinDmg <= 1) or (estDmg >= activeMinDmg) or (entHp <= estDmg)

                            if passesDamage then
                                local angleToTarget = (pt - shootPos):Angle()
                                local pFovP = math.abs(math.AngleDifference(realAngles.p, angleToTarget.p))
                                local pFovY = math.abs(math.AngleDifference(realAngles.y, angleToTarget.y))
                                local totalFov = math.sqrt(pFovP * pFovP + pFovY * pFovY)

                                if totalFov <= maxFov and IsTargetVisible(ply, ent, pt) then
                                    if totalFov < bestFov or (isHead and Garrylose.Config.aimbot_head_priority and not bestIsHead) then
                                        bestFov = totalFov
                                        target = ent
                                        targetAimPos = pt
                                        bestIsHead = isHead

                                        if isHead and Garrylose.Config.aimbot_head_priority then
                                            break
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end

        Garrylose.CurrentTarget = target
    end

    local aimbotActive = false

    if target and targetAimPos and Garrylose.Config.aimbot_enabled then
        Garrylose.AimbotTargetTicks = (Garrylose.AimbotTargetTicks or 0) + 1
        aimbotActive = true
        
        if Garrylose.Config.aimbot_autostop then
            cmd:SetForwardMove(0)
            cmd:SetSideMove(0)
            cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(bit.bor(IN_FORWARD, IN_BACK, IN_MOVELEFT, IN_MOVERIGHT))))
        end

        -- TARGET TICK & BACKTRACK SYNCHRONIZATION
        if IsValid(target) and target:IsPlayer() and isfunction(target.GetSimulationTime) then
            local simTime = target:GetSimulationTime()
            if simTime and simTime > 0 then
                local lerp = (GetConVar("cl_interp") and GetConVar("cl_interp"):GetFloat()) or 0.03
                local targetTick = math.floor((simTime + lerp) / (engine.TickInterval() or 0.015) + 0.5)
                if targetTick > 0 then
                    cmd:SetTickCount(targetTick)
                end
            end
        end

        -- LOCAL PLAYER PREDICTION:
        local tickInterval = engine.TickInterval() or 0.015
        local predictedShootPos = ply:GetShootPos() + (ply:GetVelocity() * tickInterval)
        local aimAngle = (targetAimPos - predictedShootPos):Angle()

        if Garrylose.Config.aimbot_rcs then
            local punch = ply:GetPunchAngle() or Angle(0, 0, 0)
            aimAngle = Angle(aimAngle.p - (punch.p * 1.0), aimAngle.y - (punch.y * 1.0), 0)
        end

        aimAngle:Normalize()
        cmd:SetViewAngles(aimAngle)
        FixMovement(cmd, realAngles, aimAngle)

        if not Garrylose.Config.aimbot_silent then
            ply:SetEyeAngles(aimAngle)
            Garrylose.RealViewAngles = aimAngle
        end

        local curT = CurTime()
        if Garrylose.Config.doubletap_enabled then
            if not Garrylose.DoubleTapCharged then
                local rechargeDelay = Garrylose.DTRechargeDelay or 0.35
                if (curT - (Garrylose.LastDTShootTime or 0)) >= rechargeDelay then
                    local wep = ply:GetActiveWeapon()
                    if IsValid(wep) then
                        local clip = wep:Clip1()
                        if clip == -1 or clip >= 2 then
                            Garrylose.DoubleTapCharged = true
                        end
                    else
                        Garrylose.DoubleTapCharged = true
                    end
                end
            end
        end

        local wep = ply:GetActiveWeapon()
        if Garrylose.Config.aimbot_auto_shoot then
            local canShoot = true
            if IsValid(wep) then
                local clip1 = wep:Clip1()
                local maxClip = wep:GetMaxClip1()
                if maxClip > 0 and clip1 == 0 then
                    canShoot = false
                end

                local nextPrimary = wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0
                if curT < nextPrimary then
                    canShoot = false
                end
            end

            -- Multi-Tick Head Aim Tracking:
            -- Prevents premature 1-tick snap firing ("taking photos" on bhoppers)
            local minLockTicks = tonumber(Garrylose.Config.aimbot_lock_ticks) or 2
            if (Garrylose.AimbotTargetTicks or 0) < minLockTicks then
                canShoot = false
            end

                        if canShoot and Garrylose.Config.hitchance_enabled and tonumber(Garrylose.Config.aimbot_hitchance) and tonumber(Garrylose.Config.aimbot_hitchance) > 0 then

                local isHCOverride = false

                local hcKey = Garrylose.Config.bind_hitchance_override

                if hcKey and hcKey ~= KEY_NONE and hcKey ~= 0 then

                    isHCOverride = (hcKey >= 107 and input.IsMouseDown(hcKey)) or (hcKey < 107 and input.IsKeyDown(hcKey))

                end

                isHCOverride = isHCOverride or Garrylose.Config.hitchance_override_active

                local requiredHC = isHCOverride and (tonumber(Garrylose.Config.aimbot_hitchance_override) or 0) or tonumber(Garrylose.Config.aimbot_hitchance)

                if requiredHC > 0 then

                    local sampledHC = CalculateWeaponHitchance(ply, target, targetAimPos, wep)

                    if sampledHC < requiredHC then

                        canShoot = false

                    end

                end

            end

            if canShoot then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                Garrylose.LastShotTarget = target
                Garrylose.LastShotTargetPos = targetAimPos
                Garrylose.LastShotTime = curT

                                if Garrylose.Config.doubletap_enabled and Garrylose.DoubleTapCharged then

                    local clip1 = IsValid(wep) and wep:Clip1() or 0

                    if clip1 == -1 or clip1 >= 2 then

                        Garrylose.DoubleTapCharged = false

                        Garrylose.LastDTShootTime = curT

                        if IsValid(wep) and wep.SetNextPrimaryFire then

                            wep:SetNextPrimaryFire(curT)

                        end

                        pcall(function()

                            net.Start("Garrylose_DoubleTapFire")

                                net.WriteVector(targetAimPos or Vector(0, 0, 0))

                                net.WriteBool(Garrylose.Config.aimbot_head_priority or false)

                            net.SendToServer()

                        end)

                    end

                end

            else
                cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
            end

        elseif cmd:KeyDown(IN_ATTACK) then

            Garrylose.LastShotTarget = target

            Garrylose.LastShotTargetPos = targetAimPos

            local wep = ply:GetActiveWeapon()

            local nextPrimary = IsValid(wep) and wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0

            local clip1 = IsValid(wep) and wep:Clip1() or 0

            if not Garrylose.ManualShotState and curT >= nextPrimary and (clip1 > 0 or clip1 == -1) then

                Garrylose.ManualShotState = true

                Garrylose.LastShotTime = curT

                if Garrylose.Config.doubletap_enabled and Garrylose.DoubleTapCharged and (clip1 >= 2 or clip1 == -1) then

                    Garrylose.DoubleTapCharged = false

                    Garrylose.LastDTShootTime = curT

                    if IsValid(wep) and wep.SetNextPrimaryFire then

                        wep:SetNextPrimaryFire(curT)

                    end

                    net.Start("Garrylose_DoubleTapFire")

                        net.WriteVector(targetAimPos or Vector(0, 0, 0))

                        net.WriteBool(Garrylose.Config.aimbot_head_priority or false)

                    net.SendToServer()

                end

            end

        else

            Garrylose.ManualShotState = false

        end

        aimbotActive = true

    else
        Garrylose.AimbotTargetTicks = 0
        Garrylose.ShotState = false

        Garrylose.ManualShotState = false

                if cmd:KeyDown(IN_ATTACK) then

            local wep = ply:GetActiveWeapon()

            local curT = CurTime()

            local nextPrimary = IsValid(wep) and wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0

            local clip1 = IsValid(wep) and wep:Clip1() or 0

            if not Garrylose.ManualShotState and curT >= nextPrimary and (clip1 > 0 or clip1 == -1) then

                Garrylose.ManualShotState = true

                Garrylose.LastShotTime = curT

                if Garrylose.Config.doubletap_enabled and Garrylose.DoubleTapCharged and (clip1 >= 2 or clip1 == -1) then

                    Garrylose.DoubleTapCharged = false

                    Garrylose.LastDTShootTime = curT

                    if IsValid(wep) and wep.SetNextPrimaryFire then

                        wep:SetNextPrimaryFire(curT)

                    end

                    local tr = util.QuickTrace(ply:GetShootPos(), ply:GetAimVector() * 4000, ply)

                    local hitPos = tr.HitPos or (ply:GetShootPos() + ply:GetAimVector() * 4000)

                    net.Start("Garrylose_DoubleTapFire")

                        net.WriteVector(hitPos)

                        net.WriteBool(false)

                    net.SendToServer()

                end

            end

        else

            Garrylose.ManualShotState = false

        end

    end

    -- - ---

    if cmd:KeyDown(IN_ATTACK) and not aimbotActive then

                cmd:SetViewAngles(realAngles)

        FixMovement(cmd, realAngles, realAngles)

        local wep = ply:GetActiveWeapon()

        local nextPrimary = IsValid(wep) and wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0

        local clip1 = IsValid(wep) and wep:Clip1() or 0

        local curT = CurTime()

                if curT >= nextPrimary and (clip1 > 0 or clip1 == -1) and (Garrylose.LastShotNextPrimary ~= nextPrimary) and not isHoldingGrenade then

            Garrylose.LastShotNextPrimary = nextPrimary

            local shootSrc = ply:GetShootPos()

            local shootTr = util.TraceLine({

                start = shootSrc,

                endpos = shootSrc + (realAngles:Forward() * 50000),

                filter = ply,

                mask = MASK_SHOT

            })

            if shootTr then

                Garrylose_RecordShot(shootSrc, shootTr.HitPos)

            end

        end

    else

        Garrylose.LastShotNextPrimary = nil

    end

        local activeWep = ply:GetActiveWeapon()

    local isHoldingGrenade = IsGrenadeWeapon(activeWep)

    local isHoldingTool = IsValid(activeWep) and (activeWep:GetClass() == "weapon_physgun" or activeWep:GetClass() == "gmod_tool" or activeWep:GetClass() == "gmod_camera")

    local isCursorOpen = vgui.CursorVisible() or gui.IsGameUIVisible() or gui.IsConsoleVisible()

    local shouldSuspendAA = isHoldingGrenade or isHoldingTool or isCursorOpen or isOnLadder or cmd:KeyDown(IN_ATTACK) or cmd:KeyDown(IN_ATTACK2)

    if Garrylose.Config.antiaim_enabled and not aimbotActive and not shouldSuspendAA then

                local fakePitch = realAngles.p

        local fakeYaw = realAngles.y

        local pitchMode = tonumber(Garrylose.Config.antiaim_pitch) or 1

        if pitchMode == 1 then

            fakePitch = 89.0

        elseif pitchMode == 2 then

            fakePitch = -89.0

        elseif pitchMode == 3 then

            local pjAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_pitch_jitter_angle) or 45, 1, 89)

            fakePitch = Garrylose.JitterFlip and pjAngle or -pjAngle

        elseif pitchMode == 4 then

            -- Random Jitter Pitch
            local pjAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_pitch_jitter_angle) or 89, 1, 89)

            fakePitch = math.Rand(-pjAngle, pjAngle)

        end

        -- pitchMode == 0: None — keep realAngles.p (player look direction)

        Garrylose.JitterFlip = not Garrylose.JitterFlip

        -- Manual AA Direction Override (Priority over default yaw)

        if Garrylose.Config.manual_aa_state == 1 then

            fakeYaw = fakeYaw + 90

        elseif Garrylose.Config.manual_aa_state == 2 then

            fakeYaw = fakeYaw - 90

        elseif Garrylose.Config.manual_aa_state == 3 then

            fakeYaw = fakeYaw + 180

        else

            if Garrylose.Config.antiaim_yaw == 1 then

                fakeYaw = fakeYaw + 180

            elseif Garrylose.Config.antiaim_yaw == 2 then

                -- Spinbot

                local spinSpeed = tonumber(Garrylose.Config.antiaim_spin_speed) or 450

                local tickDelta = engine.TickInterval() or (1 / 66.6)

                Garrylose.SpinbotYaw = math.NormalizeAngle((Garrylose.SpinbotYaw or realAngles.y) + (spinSpeed * tickDelta))

                fakeYaw = Garrylose.SpinbotYaw

            elseif Garrylose.Config.antiaim_yaw == 3 then

                -- Jitter (Stable alternating offset with custom angle + side)

                local jAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_jitter_angle) or 90, 1, 360)

                local jBase = (tonumber(Garrylose.Config.antiaim_jitter_side) or 1) == 2 and 0 or 180

                fakeYaw = fakeYaw + jBase + (Garrylose.JitterFlip and jAngle or -jAngle)

            elseif Garrylose.Config.antiaim_yaw == 4 then

                -- Random Jitter (Full 360° customizable radius)

                local jAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_jitter_angle) or 180, 1, 360)

                local jBase = (tonumber(Garrylose.Config.antiaim_jitter_side) or 1) == 2 and 0 or 180

                fakeYaw = fakeYaw + jBase + math.Rand(-jAngle, jAngle)

            end

        end

        local fakeAngles = Angle(fakePitch, math.NormalizeAngle(fakeYaw), 0)

        Garrylose.LastSentFakeAngles = fakeAngles

        FixMovement(cmd, realAngles, fakeAngles)

        cmd:SetViewAngles(fakeAngles)

    elseif not aimbotActive then

                cmd:SetViewAngles(realAngles)

        Garrylose.LastSentFakeAngles = realAngles

    end

    -- - ---

    local isTrigKey = false

    local tbKey = Garrylose.Config.bind_triggerbot

    if tbKey and tbKey ~= KEY_NONE and tbKey ~= 0 then

        isTrigKey = (tbKey >= 107 and input.IsMouseDown(tbKey)) or (tbKey < 107 and input.IsKeyDown(tbKey))

    end

    if (Garrylose.Config.triggerbot_enabled or isTrigKey) and not aimbotActive then

        local trCross = util.TraceLine({

            start = ply:GetShootPos(),

            endpos = ply:GetShootPos() + (cmd:GetViewAngles():Forward() * 10000),

            filter = ply,

            mask = MASK_SHOT

        })

        if trCross and trCross.Hit and IsValid(trCross.Entity) and IsValidTarget(trCross.Entity) then

            local isHead = (trCross.HitGroup == 1 or trCross.HitGroup == HITGROUP_HEAD)

            local allowShoot = not Garrylose.Config.triggerbot_head_only or isHead

            if allowShoot then

                local delay = (tonumber(Garrylose.Config.triggerbot_delay) or 0) / 1000

                Garrylose.TriggerbotTimer = Garrylose.TriggerbotTimer or CurTime()

                if (CurTime() - Garrylose.TriggerbotTimer) >= delay then

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))

                    Garrylose.TriggerbotTimer = CurTime() + 0.12

                end

            end

        else

            Garrylose.TriggerbotTimer = CurTime()

        end

    end

    -- --- Auto Reload Engine ---

    if Garrylose.Config.autoreload_enabled then

        local wep = ply:GetActiveWeapon()

        if IsValid(wep) then

            local clip1 = wep:Clip1()

            local maxClip = wep:GetMaxClip1()

            if maxClip > 0 and clip1 == 0 and not aimbotActive and not cmd:KeyDown(IN_ATTACK) then

                if ply:GetAmmoCount(wep:GetPrimaryAmmoType()) > 0 then

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_RELOAD))

                end

            end

        end

    end

    -- - ---

    local isAirStopKey = false

    local asKey = Garrylose.Config.bind_airstop

    if asKey and asKey ~= KEY_NONE and asKey ~= 0 then

        isAirStopKey = (asKey >= 107 and input.IsMouseDown(asKey)) or (asKey < 107 and input.IsKeyDown(asKey))

    end

    local shouldAirStop = isAirStopKey or (Garrylose.Config.airstop_enabled and aimbotActive and IsValid(target))

    if shouldAirStop and not ply:OnGround() and ply:GetMoveType() == MOVETYPE_WALK then

        local curVel = ply:GetVelocity()

        local curVel2D = Vector(curVel.x, curVel.y, 0)

        if curVel2D:Length() > 2 then

            local velAng = curVel:Angle()

            local viewAng = cmd:GetViewAngles()

            local diffYaw = math.rad(math.NormalizeAngle(velAng.y - viewAng.y))

                        local fmove = -math.cos(diffYaw) * 10000

            local smove = math.sin(diffYaw) * 10000

            cmd:SetForwardMove(math.Clamp(fmove, -10000, 10000))

            cmd:SetSideMove(math.Clamp(smove, -10000, 10000))

            cmd:SetUpMove(0)

            cmd:RemoveKey(IN_FORWARD)

            cmd:RemoveKey(IN_BACK)

            cmd:RemoveKey(IN_MOVELEFT)

            cmd:RemoveKey(IN_MOVERIGHT)

        else

            cmd:SetForwardMove(0)

            cmd:SetSideMove(0)

            cmd:SetUpMove(0)

        end

    end

    -- - ---

    for id, plugin in pairs(Garrylose.Plugins) do

        if plugin.enabled and plugin.onCreateMove then

            pcall(plugin.onCreateMove, cmd)

        end

    end

end)

-- ASPECT RATIO RENDER ENGINE (Garrylose Aspect Ratio Engine)

local isRenderingAspect = false

hook.Add("RenderScene", "Garrylose_AspectRatio_RenderSceneEngine", function(origin, angles, fov)

    if isRenderingAspect then return end

    if not Garrylose.Config.aspect_ratio_enabled then return end

    local aspect = tonumber(Garrylose.Config.aspect_ratio_val)

    if not aspect or aspect <= 0.05 then return end

    local currentFov = (Garrylose.Config.fov_changer and Garrylose.Config.fov_changer > 0) and Garrylose.Config.fov_changer or fov

    if Garrylose.Config.freecam_enabled then
        return {
            origin = Garrylose.FreecamPos,
            angles = Garrylose.FreecamAng,
            fov = fov,
            drawviewer = true
        }
    end
    local viewAngles = Garrylose.RealViewAngles or angles

    local ply = LocalPlayer()

    local viewOrigin = origin

    -- Support thirdperson inside RenderView

    if Garrylose.Config.thirdperson_enabled and IsValid(ply) and ply:Alive() then

        local dist = Garrylose.Config.thirdperson_dist or 100

        local tr = util.TraceLine({

            start = origin,

            endpos = origin - (viewAngles:Forward() * dist),

            filter = ply,

            mask = MASK_SOLID

        })

        viewOrigin = tr.HitPos + tr.HitNormal * 4

    end

    local viewData = {

        x = 0,

        y = 0,

        w = ScrW(),

        h = ScrH(),

        origin = viewOrigin,

        angles = viewAngles,

        fov = currentFov,

        drawmonitors = true,

        drawviewmodel = not Garrylose.Config.thirdperson_enabled,

        aspectratio = aspect,

        bloomtone = true

    }

    isRenderingAspect = true

    render.RenderView(viewData)

    -- Explicitly render screenspace post-processing (Night Mode, Fullbright, Color Grading) inside Aspect Ratio

    pcall(function()

        hook.Run("RenderScreenspaceEffects")

    end)

    render.RenderHUD(0, 0, ScrW(), ScrH())

    isRenderingAspect = false

    return true

end)

-- Camera & Aspect Ratio Fix

-- =========================================================================
-- EYEANGLES DETOUR (Zero Viewmodel/Hands/Radar Shake During Anti-Aim)
-- =========================================================================
local plyMeta = FindMetaTable("Player")
local entMeta = FindMetaTable("Entity")

local orig_PlyEyeAngles = plyMeta and plyMeta.EyeAngles
local orig_EntEyeAngles = entMeta and entMeta.EyeAngles
local orig_EyeAngles = _G.EyeAngles

if plyMeta and orig_PlyEyeAngles then
    function plyMeta:EyeAngles()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles
        end
        return orig_PlyEyeAngles(self)
    end
end

if entMeta and orig_EntEyeAngles then
    function entMeta:EyeAngles()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles
        end
        return orig_EntEyeAngles(self)
    end
end

if orig_EyeAngles then
    function _G.EyeAngles()
        if (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles
        end
        return orig_EyeAngles()
    end
end

local orig_PlyGetAimVector = plyMeta and plyMeta.GetAimVector
local orig_EntGetAimVector = entMeta and entMeta.GetAimVector

if plyMeta and orig_PlyGetAimVector then
    function plyMeta:GetAimVector()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles:Forward()
        end
        return orig_PlyGetAimVector(self)
    end
end

if entMeta and orig_EntGetAimVector then
    function entMeta:GetAimVector()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles:Forward()
        end
        return orig_EntGetAimVector(self)
    end
end

hook.Add("CalcView", "Garrylose_FixCameraView", function(ply, pos, angles, fov)

    if not IsValid(ply) then return end

    if ply:GetMoveType() == MOVETYPE_NOCLIP then return end
    
    -- Absolute Jitter Prevention: Force the engine to use our RealViewAngles instead of the Anti-Aim angles
    if (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
        local punch = ply:GetViewPunchAngles() or Angle(0, 0, 0)
        angles = Angle(Garrylose.RealViewAngles.p + punch.p, Garrylose.RealViewAngles.y + punch.y, Garrylose.RealViewAngles.r + punch.r)
    end

    local currentFov = (Garrylose.Config.fov_changer and Garrylose.Config.fov_changer > 0) and Garrylose.Config.fov_changer or fov

    if Garrylose.Config.freecam_enabled then
        return {
            origin = Garrylose.FreecamPos,
            angles = Garrylose.FreecamAng,
            fov = fov,
            drawviewer = true
        }
    end
    local viewAngles = Garrylose.RealViewAngles or angles

    local customAspect = (Garrylose.Config.aspect_ratio_enabled and Garrylose.Config.aspect_ratio_val and Garrylose.Config.aspect_ratio_val > 0) and Garrylose.Config.aspect_ratio_val or nil

    local standingEyePos = ply:GetPos() + Vector(0, 0, 64)

    local isFakeDucking = Garrylose.Config.fakeduck_enabled and ply:OnGround()

    -- 3rd Person View

    if Garrylose.Config.thirdperson_enabled then

        local dist = Garrylose.Config.thirdperson_dist or 100

        local camOrigin = isFakeDucking and standingEyePos or pos

        local tr = util.TraceLine({

            start = camOrigin,

            endpos = camOrigin - (viewAngles:Forward() * dist),

            filter = ply,

            mask = MASK_SOLID

        })

        local view = {

            origin = tr.HitPos + tr.HitNormal * 4,

            angles = viewAngles,

            fov = currentFov,

            drawviewer = true

        }

        if customAspect then view.aspectratio = customAspect end

        return view

    end

    -- 1st Person Camera Fix (with Fake Duck standing height override)

    local camPos = isFakeDucking and standingEyePos or pos

    local view = {

        origin = camPos,

        angles = Garrylose.RealViewAngles or angles,

        fov = currentFov,

        drawviewer = false

    }

    if customAspect then view.aspectratio = customAspect end

    return view

end)

-- REMOVE SPREAD / NO-SPREAD ENGINE (Zero Bullet Spread & Perfect Pinpoint)

hook.Add("EntityFireBullets", "Garrylose_NoSpread_Engine", function(ent, data)

    if ent ~= LocalPlayer() then return end

    if not Garrylose.Config.nospread_enabled then return end

    data.Spread = Vector(0, 0, 0)

    return true

end)

hook.Add("Think", "Garrylose_NoSpread_WeaponCone", function()

    if not Garrylose.Config.nospread_enabled then return end

    local ply = LocalPlayer()

    if not IsValid(ply) then return end

    local wep = ply:GetActiveWeapon()

    if not IsValid(wep) then return end

    if wep.Primary then

        if wep.Primary.Cone and wep.Primary.Cone > 0 then wep.Primary.Cone = 0 end

        if wep.Primary.Spread and wep.Primary.Spread > 0 then wep.Primary.Spread = 0 end

    end

    if wep.Secondary then

        if wep.Secondary.Cone and wep.Secondary.Cone > 0 then wep.Secondary.Cone = 0 end

        if wep.Secondary.Spread and wep.Secondary.Spread > 0 then wep.Secondary.Spread = 0 end

    end

    if wep.Cone and wep.Cone > 0 then wep.Cone = 0 end

    if wep.Spread and wep.Spread > 0 then wep.Spread = 0 end

    if wep.Inaccuracy and wep.Inaccuracy > 0 then wep.Inaccuracy = 0 end

end)

-- ViewModel Customization & Anti-Aim Viewmodel/Hands Stabilization Engine
-- Flawlessly fixes viewmodel & hand jitter across ALL HL2 weapons and custom SWEPs

hook.Add("CalcViewModelView", "Garrylose_FixViewModelView", function(wep, vm, oldPos, oldAng, pos, ang)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local isAAActive = (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent)

    -- When Anti-Aim is active, engine 'pos' and 'ang' contain corrupt C++ sway from spinning server angles.
    -- We anchor cleanly to the true camera position (oldPos) and player aim angles (RealViewAngles).
    local basePos = isAAActive and oldPos or pos
    local baseAng = isAAActive and (Garrylose.RealViewAngles or oldAng) or ang

    local punch = ply:GetViewPunchAngles() or Angle(0, 0, 0)
    local targetAng = Angle(baseAng.p + punch.p, baseAng.y + punch.y, baseAng.r + punch.r)
    local targetPos = Vector(basePos.x, basePos.y, basePos.z)

    -- Suppress weapon sway/bob spasm from Anti-Aim angle deltas on all Lua SWEPs
    if IsValid(wep) and isAAActive then
        if wep.SwayScale and wep.SwayScale > 0 then wep.SwayScale = 0 end
        if wep.BobScale and wep.BobScale > 0 then wep.BobScale = 0 end
    end

    -- Allow custom SWEP animations, iron sights, and position overrides
    if IsValid(wep) then
        if wep.GetViewModelPosition then
            local p, a = wep:GetViewModelPosition(targetPos * 1, targetAng * 1)
            if p then targetPos = p end
            if a then targetAng = a end
        end
        if wep.CalcViewModelView then
            local p, a = wep:CalcViewModelView(vm, oldPos * 1, oldAng * 1, targetPos * 1, targetAng * 1)
            if p then targetPos = p end
            if a then targetAng = a end
        end
    end

    -- Viewmodel Position Offsets (X, Y, Z)
    local vmX = tonumber(Garrylose.Config.viewmodel_x) or 0
    local vmY = tonumber(Garrylose.Config.viewmodel_y) or 0
    local vmZ = tonumber(Garrylose.Config.viewmodel_z) or 0
    if vmX ~= 0 or vmY ~= 0 or vmZ ~= 0 then
        targetPos = targetPos + (targetAng:Right() * vmX) + (targetAng:Forward() * vmY) + (targetAng:Up() * vmZ)
    end

    -- Viewmodel Angles (Pitch, Yaw, Roll)
    local vPitch = tonumber(Garrylose.Config.viewmodel_pitch) or 0
    local vYaw = tonumber(Garrylose.Config.viewmodel_yaw) or 0
    local vRoll = tonumber(Garrylose.Config.viewmodel_roll) or 0
    if vPitch ~= 0 or vYaw ~= 0 or vRoll ~= 0 then
        targetAng:RotateAroundAxis(targetAng:Right(), vPitch)
        targetAng:RotateAroundAxis(targetAng:Up(), vYaw)
        targetAng:RotateAroundAxis(targetAng:Forward(), vRoll)
    end

    if IsValid(wep) and Garrylose.Config.viewmodel_fov and Garrylose.Config.viewmodel_fov > 0 then
        wep.ViewModelFOV = Garrylose.Config.viewmodel_fov
    end

    return targetPos, targetAng
end)

-- Hitmarker & Hitsound

Garrylose.Hitmarkers = Garrylose.Hitmarkers or {}

Garrylose.DamageNumbers = Garrylose.DamageNumbers or {}

Garrylose.LastHitTime = 0

Garrylose.LastHitHead = false

Garrylose.LastHitFatal = false

local hitsoundFiles = {

    [1] = "buttons/bell1.wav",                             -- Garrylose Bell

    [2] = "physics/metal/metal_solid_impact_bullet2.wav",   -- Metallic Ping

    [3] = "buttons/button15.wav",                          -- Tactical Click

    [4] = "garrysmod/balloon_pop.wav",                     -- Balloon Pop

    [5] = "garrylose_hitsound.wav"                         -- Custom Sound in garrysmod/sound/

}

local lastSoundPlayTime = 0

-- HVH KILL EFFECTS ENGINE (Dynamic Lights, Particle Bursts & Tesla Shockwaves)

function Garrylose.SpawnKillEffect(hitPos, isHead)

    if not hitPos or hitPos == Vector(0, 0, 0) then return end

    local effectType = tonumber(Garrylose.Config.killeffect_type) or 1

    local col = Garrylose.Config.col_killeffect or Color(0, 215, 255, 255)

    -- 1. Vibrant Dynamic Light Flash

    local dlight = DynamicLight(LocalPlayer():EntIndex() + math.random(1000, 3000))

    if dlight then

        dlight.pos = hitPos + Vector(0, 0, 15)

        dlight.r = col.r

        dlight.g = col.g

        dlight.b = col.b

        dlight.brightness = 5

        dlight.Decay = 1200

        dlight.Size = 280

        dlight.DieTime = CurTime() + 0.6

    end

    -- 2. Visual Particle / Spark / Shockwave Effects

    if effectType == 1 then

        -- Tesla Lightning / Electric Sparks

        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetMagnitude(4)

        ed:SetScale(2)

        ed:SetRadius(20)

        util.Effect("Sparks", ed)

        util.Effect("cball_explode", ed)

        sound.Play("ambient/energy/zap" .. math.random(1, 3) .. ".wav", hitPos, 85, math.random(95, 115))

    elseif effectType == 2 then

        -- Plasma / AR2 Explosion

        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetScale(1.8)

        util.Effect("AR2Explosion", ed)

        sound.Play("weapons/physcannon/energy_sing_explosion2.wav", hitPos, 85, 105)

    elseif effectType == 3 then

        -- Blood Burst

        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetScale(3)

        util.Effect("BloodImpact", ed)

        sound.Play("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav", hitPos, 85, 100)

    elseif effectType == 4 then

        -- Energy Shockwave / Gravity Vortex

        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetScale(2.2)

        util.Effect("cball_bounce", ed)

        sound.Play("weapons/physcannon/energy_bounce" .. math.random(1, 2) .. ".wav", hitPos, 85, 110)

    end

end

function Garrylose.TriggerHit(dmg, isHead, hitPos, isFatal)

    Garrylose.LastHitTime = CurTime()

    Garrylose.LastHitHead = isHead or false

    Garrylose.LastHitFatal = isFatal or false

    -- Spawn Kill Effect on Fatal Hit

    if isFatal and Garrylose.Config.killeffect_enabled and hitPos and hitPos ~= Vector(0,0,0) then

        Garrylose.SpawnKillEffect(hitPos, isHead)

    end

    -- Play Sound Audio

    if Garrylose.Config.hitsound_enabled and (CurTime() - lastSoundPlayTime > 0.03) then

        lastSoundPlayTime = CurTime()

        local soundIdx = tonumber(Garrylose.Config.hitsound_type) or 1

        local soundFile = hitsoundFiles[soundIdx] or hitsoundFiles[1]

        if soundIdx == 5 and not file.Exists("sound/" .. soundFile, "GAME") then

            soundFile = "buttons/bell1.wav"

        end

        surface.PlaySound(soundFile)

    end

    -- Floating Damage in 3D Space (Pure White)

    if Garrylose.Config.hitmarker_damage_numbers then

        local spawnPos = hitPos or (LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 80)

        table.insert(Garrylose.DamageNumbers, {

            pos = spawnPos + Vector(math.random(-6, 6), math.random(-6, 6), 12),

            dmg = math.Round(dmg or (isFatal and 100 or 25)),

            time = CurTime(),

            isHead = isHead,

            isFatal = isFatal

        })

    end

    -- Trigger HvH Killsay Trash-Talk on any fatal kill (NPC, Nextbot, Player)

    if isFatal and Garrylose.TriggerKillsay then

        Garrylose.TriggerKillsay()

    end

end

-- Server Network Event Receiver

-- Server Bullet Tracer Receiver

net.Receive("Garrylose_BulletTracer", function()

    local src = net.ReadVector()

    local dir = net.ReadVector()

    local tr = util.TraceLine({

        start = src,

        endpos = src + (dir * 50000),

        mask = MASK_SHOT

    })

    if tr then

        Garrylose_RecordShot(src, tr.HitPos)

    end

end)

net.Receive("Garrylose_HitEvent", function()

    local dmg = net.ReadFloat()

    local hitPos = net.ReadVector()

    local isHead = net.ReadBool()

    local isFatal = net.ReadBool()

    Garrylose.TriggerHit(dmg, isHead, hitPos, isFatal)

end)

-- 2. Client Bullet Impact & Tracer Capture Engine

hook.Add("EntityFireBullets", "Garrylose_Client_BulletImpact", function(ent, data)

    if ent ~= LocalPlayer() then return end

    local src = data.Src or ent:GetShootPos()

    local dir = data.Dir or ent:GetAimVector()

    local trDirect = util.TraceLine({

        start = src,

        endpos = src + (dir * 50000),

        filter = ent,

        mask = MASK_SHOT

    })

    if trDirect then

        Garrylose_RecordShot(src, trDirect.HitPos)

    end

    local oldCallback = data.Callback

    data.Callback = function(attacker, tr, dmginfo)

        if oldCallback then oldCallback(attacker, tr, dmginfo) end

        if tr and tr.Hit and IsValid(tr.Entity) and tr.Entity ~= LocalPlayer() then

            local e = tr.Entity

            local className = string.lower(e:GetClass() or "")

            if e:IsPlayer() or e:IsNPC() or e:IsNextBot() or e.Type == "nextbot" or string.find(className, "npc_") or string.find(className, "nextbot") or e:IsRagdoll() or string.find(className, "ragdoll") then

                local isHead = (tr.HitGroup == 1 or tr.HitGroup == HITGROUP_HEAD)

                local dmg = dmginfo and dmginfo:GetDamage() or 25

                local isFatal = (e.Health and e:Health() > 0 and (e:Health() - dmg <= 0)) or e:IsRagdoll()

                Garrylose.TriggerHit(dmg, isHead, tr.HitPos, isFatal)

            end

        end

    end

    return true

end)

-- 3. Universal Multi-Target Life Tracker (Optimized with Cached Targets)

Garrylose.TrackedTargets = Garrylose.TrackedTargets or {}

local nextThinkScan = 0

hook.Add("Think", "Garrylose_Universal_HitTracker", function()

    local ply = LocalPlayer()

    if not IsValid(ply) then return end

    local curT = CurTime()

    if curT < nextThinkScan then return end

    nextThinkScan = curT + 0.05 -- Run 20 times/sec instead of every tick

    -- Scan active living cached targets

    for _, ent in ipairs(Garrylose.CachedTargets) do

        if IsValid(ent) then

            local idx = ent:EntIndex()

            local curHp = ent:Health()

            local curPos = ent:WorldSpaceCenter()

            local track = Garrylose.TrackedTargets[idx]

            if track and track.lastHp and curHp < track.lastHp and track.lastHp > 0 then

                local dmg = track.lastHp - curHp

                local isFatal = (curHp <= 0)

                if Garrylose.CurrentTarget == ent or Garrylose.LastShotTarget == ent or (ply:GetShootPos():DistToSqr(curPos) < 16000000) then

                    Garrylose.TriggerHit(dmg, false, curPos, isFatal)

                end

            end

            Garrylose.TrackedTargets[idx] = {

                ent = ent,

                lastHp = curHp,

                lastPos = curPos,

                lastSeen = curT

            }

        end

    end

    -- Process dead / deleted entities that disappeared on fatal hit

    for idx, data in pairs(Garrylose.TrackedTargets) do

        if not IsValid(data.ent) or data.ent:Health() <= 0 then

            if curT - data.lastSeen < 0.45 then

                if data.lastHp and data.lastHp > 0 then

                    if Garrylose.LastShotTarget == data.ent or Garrylose.CurrentTarget == data.ent or (ply:GetShootPos():DistToSqr(data.lastPos) < 16000000) then

                        Garrylose.TriggerHit(data.lastHp, true, data.lastPos, true)

                    end

                end

            end

            Garrylose.TrackedTargets[idx] = nil

        end

    end

end)

-- HUDPaint (ESP with Resolver & AutoWall Badges)

hook.Add("HUDPaint", "Garrylose_Core_HUDPaint", function()

    local ply = LocalPlayer()

    if not IsValid(ply) then return end

    local currentHitbox = tonumber(Garrylose.Config.aimbot_hitbox) or 1

    if Garrylose.Config.esp_enabled then

        -- Offscreen Enemy Indicator Arrows

        if Garrylose.Config.offscreen_esp_enabled then

            local center = Vector(ScrW() / 2, ScrH() / 2, 0)

            local offCol = Garrylose.Config.col_offscreen_esp or Color(255, 60, 90, 255)

            local radius = math.min(ScrW(), ScrH()) * 0.28

            for _, ent in ipairs(Garrylose.CachedTargets) do

                if IsValid(ent) and ent:Health() > 0 and ent ~= ply then

                    local targetPos = ent:WorldSpaceCenter()

                    local toTarget = (targetPos - ply:GetShootPos()):Angle()

                    local diffYaw = math.AngleDifference(toTarget.y, (Garrylose.RealViewAngles or ply:EyeAngles()).y)

                    local screen = targetPos:ToScreen()

                    if not screen.visible or screen.x < 40 or screen.x > ScrW() - 40 or screen.y < 40 or screen.y > ScrH() - 40 then

                        -- Exactly mapped screen angle (-diffYaw - 90 deg):

                        -- Right (-90 diffYaw) -> 0 deg (Right)

                        -- Left (+90 diffYaw)  -> -180 deg (Left)

                        -- Behind (180 diffYaw) -> 90 deg (Bottom)

                        local rad = math.rad(-diffYaw - 90)

                        local ax = center.x + math.cos(rad) * radius

                        local ay = center.y + math.sin(rad) * radius

                        local forwardVec = Vector(math.cos(rad), math.sin(rad), 0)

                        local rightVec = Vector(-math.sin(rad), math.cos(rad), 0)

                        local p1 = Vector(ax, ay, 0) + forwardVec * 12

                        local p2 = Vector(ax, ay, 0) - forwardVec * 6 + rightVec * 8

                        local p3 = Vector(ax, ay, 0) - forwardVec * 6 - rightVec * 8

                        draw.NoTexture()

                        surface.SetDrawColor(offCol)

                        surface.DrawPoly({

                            { x = p1.x, y = p1.y },

                            { x = p2.x, y = p2.y },

                            { x = p3.x, y = p3.y }

                        })

                    end

                end

            end

        end

        for _, ent in ipairs(Garrylose.CachedTargets) do

            if IsValid(ent) then

                local pos = ent:GetPos()

                local height = ent:OBBMaxs().z

                if height <= 20 then height = 72 end

                local screenPos = pos:ToScreen()

                local headPos = (pos + Vector(0, 0, height + 4)):ToScreen()

                if screenPos.visible or headPos.visible then

                    local h = math.abs(screenPos.y - headPos.y)

                    local w = math.max(h / 2, 14)

                    local boxCol = Garrylose.Config.col_esp_boxes or Color(0, 210, 255, 255)

                    local snapCol = Garrylose.Config.col_esp_snaplines or Color(0, 210, 255, 200)

                    -- Box

                    if Garrylose.Config.esp_boxes then

                        surface.SetDrawColor(boxCol)

                        surface.DrawOutlinedRect(screenPos.x - w / 2, headPos.y, w, h)

                    end

                    if Garrylose.Config.esp_box_fill then
                        local colFill = Garrylose.Config.col_esp_box_fill or Color(255, 255, 255, 30)
                        surface.SetDrawColor(colFill)
                        surface.DrawRect(screenPos.x - w / 2, headPos.y, w, h)
                    end


                    -- Custom Colors

                    local nameCol = Garrylose.Config.col_esp_names or Color(240, 245, 255, 255)

                    local hpCol = Garrylose.Config.col_esp_health or Color(0, 230, 180, 255)

                    local snapCol = Garrylose.Config.col_esp_snaplines or Color(0, 210, 255, 255)

                    -- Skeleton ESP

                    if Garrylose.Config.esp_skeleton and ent.LookupBone and ent:LookupBone("ValveBiped.Bip01_Head1") then

                        local skelCol = Garrylose.Config.col_esp_skeleton or Color(255, 255, 255, 220)

                        surface.SetDrawColor(skelCol)

                        local bones = {

                            {"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1"},

                            {"ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Spine4"},

                            {"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2"},

                            {"ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Pelvis"},

                            {"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_L_UpperArm"},

                            {"ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm"},

                            {"ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand"},

                            {"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_R_UpperArm"},

                            {"ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm"},

                            {"ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand"},

                            {"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh"},

                            {"ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf"},

                            {"ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot"},

                            {"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh"},

                            {"ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf"},

                            {"ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot"}

                        }

                        for _, pair in ipairs(bones) do

                            local b1 = ent:LookupBone(pair[1])

                            local b2 = ent:LookupBone(pair[2])

                            if b1 and b2 then

                                local p1 = ent:GetBonePosition(b1)

                                local p2 = ent:GetBonePosition(b2)

                                if p1 and p2 then

                                    local s1 = p1:ToScreen()

                                    local s2 = p2:ToScreen()

                                    if s1.visible and s2.visible then

                                        surface.DrawLine(s1.x, s1.y, s2.x, s2.y)

                                    end

                                end

                            end

                        end

                    end

                    -- Name

                    if Garrylose.Config.esp_names then

                        local name = ent:IsPlayer() and ent:Nick() or ent:GetClass()

                        draw.SimpleText(name, "DefaultFixed", screenPos.x, headPos.y - 14, nameCol, TEXT_ALIGN_CENTER)

                    end

                    -- Health

                    if Garrylose.Config.esp_health then

                        local hp = ent:Health()

                        if hp > 0 then

                            draw.SimpleText("HP: " .. hp, "DefaultFixed", screenPos.x, screenPos.y + 4, hpCol, TEXT_ALIGN_CENTER)

                        end

                    end

                    -- Weapon & Ammo ESP

                    if Garrylose.Config.esp_weapon_info and ent.GetActiveWeapon then

                        local wep = ent:GetActiveWeapon()

                        if IsValid(wep) then

                            local wName = string.upper(string.Replace(wep:GetClass() or "", "weapon_", ""))

                            local clip = wep:Clip1()

                            local maxClip = wep:GetMaxClip1()

                            local txt = (clip >= 0) and (wName .. " [" .. clip .. "]") or wName

                            local wCol = Garrylose.Config.col_esp_weapon or Color(240, 245, 255, 255)

                            local yOff = (Garrylose.Config.esp_health and 16 or 4)

                            draw.SimpleText(txt, "DefaultFixed", screenPos.x, screenPos.y + yOff, wCol, TEXT_ALIGN_CENTER)

                            -- Ammo Bar ESP

                            if Garrylose.Config.esp_ammo and clip >= 0 and maxClip > 0 then

                                local ammoPct = math.Clamp(clip / maxClip, 0, 1)

                                local barW = w

                                local barH = 3

                                local barX = screenPos.x - w / 2

                                local barY = screenPos.y + yOff + 13

                                local ammoCol = Garrylose.Config.col_esp_ammo or Color(255, 180, 40, 255)

                                surface.SetDrawColor(0, 0, 0, 200)

                                surface.DrawRect(barX - 1, barY - 1, barW + 2, barH + 2)

                                surface.SetDrawColor(ammoCol)

                                surface.DrawRect(barX, barY, math.max(barW * ammoPct, 1), barH)

                            end

                        end

                    end

                    -- Snaplines

                    if Garrylose.Config.esp_snaplines then

                        surface.SetDrawColor(snapCol)

                        surface.DrawLine(ScrW() / 2, ScrH(), screenPos.x, screenPos.y)

                    end

                end

            end

        end

    end

    -- --- Hitmarker & Floating Damage Numbers ---

    local cx, cy = ScrW() / 2, ScrH() / 2

    local curTime = CurTime()

    -- 1. Center Crosshair Hitmarker (X) - Pure White

    if Garrylose.Config.hitmarker_enabled and Garrylose.LastHitTime > 0 then

        local delta = curTime - Garrylose.LastHitTime

        local dur = 0.35

        if delta < dur then

            local alpha = (1 - (delta / dur)) * 255

            local baseCol = Garrylose.Config.col_hitmarker or Color(255, 255, 255, 255)

            local col = Color(baseCol.r, baseCol.g, baseCol.b, (baseCol.a / 255) * alpha)

            surface.SetDrawColor(col)

            local gap = 4

            local len = 8

            -- Diagonal X lines

            surface.DrawLine(cx - gap, cy - gap, cx - gap - len, cy - gap - len)

            surface.DrawLine(cx + gap, cy - gap, cx + gap + len, cy - gap - len)

            surface.DrawLine(cx - gap, cy + gap, cx - gap - len, cy + gap + len)

            surface.DrawLine(cx + gap, cy + gap, cx + gap + len, cy + gap + len)

        end

    end

    -- 2. Floating Damage Numbers in 3D Space - Pure White

    if Garrylose.Config.hitmarker_damage_numbers and #Garrylose.DamageNumbers > 0 then

        for i = #Garrylose.DamageNumbers, 1, -1 do

            local item = Garrylose.DamageNumbers[i]

            local age = curTime - item.time

            local lifetime = 1.0

            if age > lifetime then

                table.remove(Garrylose.DamageNumbers, i)

            else

                local progress = age / lifetime

                local floatPos = item.pos + Vector(0, 0, progress * 35)

                local scr = floatPos:ToScreen()

                if scr.visible then

                    local alpha = (1 - progress) * 255

                    local text = "- " .. tostring(item.dmg)

                    if item.isFatal then

                        text = text .. " [KILL]"

                    elseif item.isHead then

                        text = text .. " [HEAD]"

                    end

                    local baseCol = Garrylose.Config.col_dmg_numbers or Color(255, 255, 255, 255)

                    local col = Color(baseCol.r, baseCol.g, baseCol.b, (baseCol.a / 255) * alpha)

                    draw.SimpleTextOutlined(text, "DermaDefaultBold", scr.x, scr.y, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, alpha))

                end

            end

        end

    end

        -- 3. Top Watermark & Speedometer (Dynamic Active Theme Color)

    local curTheme = Garrylose.GetActiveTheme()

    local themeAccent = curTheme.accent or Color(0, 180, 255, 255)

    if Garrylose.Config.watermark_enabled then

        local speed = math.Round(ply:GetVelocity():Length2D())

        local wmText = "GARRYLOSE.cc | v1.0.0 | FPS: " .. math.Round(1 / math.max(FrameTime(), 0.001)) .. " | Speed: " .. speed .. " u/s"

        surface.SetFont("DermaDefaultBold")

        local tw, th = surface.GetTextSize(wmText)

        draw.RoundedBox(6, ScrW() - tw - 25, 15, tw + 15, th + 10, Color(11, 14, 20, 240))

        surface.SetDrawColor(themeAccent)

        surface.DrawOutlinedRect(ScrW() - tw - 25, 15, tw + 15, th + 10)

        -- Left theme accent pip inside watermark

        draw.RoundedBox(2, ScrW() - tw - 20, 19, 3, th + 2, themeAccent)

        draw.SimpleText(wmText, "DermaDefaultBold", ScrW() - tw - 13, 20, Color(230, 240, 255), TEXT_ALIGN_LEFT)

    end

    -- --- 5. 2D Tactical Radar HUD (Neverlose Minimap Style) ---

    if Garrylose.Config.radar_enabled then

        local rx = Garrylose.Config.radar_pos_x or 24

        local ry = Garrylose.Config.radar_pos_y or 65

        local rSize = tonumber(Garrylose.Config.radar_size) or 140

        local rRadius = rSize / 2

        local rRange = tonumber(Garrylose.Config.radar_range) or 2500

        local cx = rx + rRadius

        local cy = ry + rRadius

        local localPly = LocalPlayer()

        local myPos = localPly:GetPos()

        local viewAng = EyeAngles()

        local myYawAng = Angle(0, viewAng.y, 0)

        local fwdVec = myYawAng:Forward()

        local rgtVec = myYawAng:Right()

        -- Radar Main Card Glass Frame

        draw.RoundedBox(6, rx, ry, rSize, rSize, Color(12, 16, 24, 235))

        surface.SetDrawColor(curTheme.dim or Color(35, 45, 65, 200))

        surface.DrawOutlinedRect(rx, ry, rSize, rSize)

        -- Radar Axis Crosshairs

        surface.SetDrawColor(Color(55, 70, 95, 90))

        surface.DrawLine(cx, ry + 4, cx, ry + rSize - 4)

        surface.DrawLine(rx + 4, cy, rx + rSize - 4, cy)

        -- Radar Range Circles

        surface.DrawCircle(cx, cy, rRadius * 0.45, 55, 70, 95, 50)

        surface.DrawCircle(cx, cy, rRadius * 0.85, 55, 70, 95, 70)

        -- Local Player Center Dot & Forward Arrow

        draw.RoundedBox(2, cx - 2, cy - 2, 4, 4, curTheme.accent or Color(0, 220, 255))

        surface.SetDrawColor(curTheme.accent or Color(0, 220, 255))

        surface.DrawLine(cx, cy, cx, cy - 7)

        -- Radar Target Blips

        local targetMode = Garrylose.Config.radar_target_mode or 1

        local colPlayers = Garrylose.Config.col_radar_players or Color(245, 55, 75, 255)

        local colNPCs = Garrylose.Config.col_radar_npcs or Color(255, 185, 45, 255)

        for _, ent in ipairs(Garrylose.CachedTargets or {}) do

            if IsValid(ent) and ent ~= localPly and ent:Health() > 0 then

                local isPlayer = ent:IsPlayer()

                local isNPC = ent:IsNPC() or ent:IsNextBot() or ent.Type == "nextbot"

                local show = false

                if targetMode == 1 and (isPlayer or isNPC) then

                    show = true

                elseif targetMode == 2 and isPlayer then

                    show = true

                elseif targetMode == 3 and isNPC then

                    show = true

                end

                if show then

                    local entPos = ent:GetPos()

                    local diff = entPos - myPos

                    local dist = diff:Length2D()

                    if dist <= rRange then

                        -- View-Space Dot Product

                        local forwardDist = diff:Dot(fwdVec)

                        local rightDist = diff:Dot(rgtVec)

                        local scale = (rRadius * 0.85) / rRange

                        local blipX = cx + (rightDist * scale)

                        local blipY = cy - (forwardDist * scale)

                        -- Constrain inside radar window

                        blipX = math.Clamp(blipX, rx + 4, rx + rSize - 4)

                        blipY = math.Clamp(blipY, ry + 4, ry + rSize - 4)

                        local blipCol = isPlayer and colPlayers or colNPCs

                        draw.RoundedBox(3, blipX - 3, blipY - 3, 6, 6, blipCol)

                        surface.SetDrawColor(Color(0, 0, 0, 180))

                        surface.DrawOutlinedRect(blipX - 3, blipY - 3, 6, 6)

                        -- Target Heading Direction Pointer

                        local entFwd = ent:EyeAngles():Forward()

                        local entFwdRel = entFwd:Dot(fwdVec)

                        local entRgtRel = entFwd:Dot(rgtVec)

                        local pX = blipX + (entRgtRel * 6)

                        local pY = blipY - (entFwdRel * 6)

                        surface.SetDrawColor(blipCol)

                        surface.DrawLine(blipX, blipY, pX, pY)

                    end

                end

            end

        end

        -- Header Label

        draw.SimpleText("RADAR", "DefaultFixed", rx + 6, ry + 4, Color(130, 150, 180, 180), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

    end

    -- --- 5. Grenade Proximity Danger HUD Banner ---

    if Garrylose.Config.grenade_warning_enabled then

        local myPos = ply:GetPos()

        local isNearBlast = false

        for _, ent in ipairs(ents.FindByClass("npc_grenade_frag")) do if IsValid(ent) and ent:GetPos():Distance(myPos) < 320 then isNearBlast = true break end end

        if not isNearBlast then for _, ent in ipairs(ents.FindByClass("grenade_hand")) do if IsValid(ent) and ent:GetPos():Distance(myPos) < 320 then isNearBlast = true break end end end

        if not isNearBlast then for _, ent in ipairs(ents.FindByClass("item_ammo_ar2_altfire")) do if IsValid(ent) and ent:GetPos():Distance(myPos) < 300 then isNearBlast = true break end end end

        if isNearBlast then

            local pulse = (math.sin(CurTime() * 12) + 1) * 0.5

            local warnCol = Color(255, 40 + math.floor(pulse * 60), 40, 240)

            local bannerY = ScrH() * 0.28

            draw.RoundedBox(6, ScrW()/2 - 160, bannerY - 14, 320, 28, Color(20, 0, 0, 220))

            surface.SetDrawColor(warnCol)

            surface.DrawOutlinedRect(ScrW()/2 - 160, bannerY - 14, 320, 28)

            draw.SimpleText("⚠ DANGER: GRENADE BLAST RADIUS ⚠", "DermaDefaultBold", ScrW()/2, bannerY, warnCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        end

    end

    -- --- 6. Spectator List (Creepypasta Scare Easter Egg) ---

    if Garrylose.Config.spectator_list_enabled then

        Garrylose.SpectatorStartTime = Garrylose.SpectatorStartTime or CurTime()

        local elapsed = CurTime() - Garrylose.SpectatorStartTime

        local specs = {}

        -- 1. Real Multiplayer Spectators

        for _, p in ipairs(player.GetAll()) do

            if IsValid(p) and p ~= ply and p:GetObserverTarget() == ply then

                table.insert(specs, { name = p:Nick(), col = Color(220, 235, 255, 255) })

            end

        end

        -- 2. Creepypasta Entity 1: meaty (after 5 seconds)

        if elapsed >= 5 then

            table.insert(specs, { name = "meaty", col = Color(255, 55, 55, 255) })

        end

        -- 3. Creepypasta Entity 2: The Watcher (after 10 seconds)

        if elapsed >= 10 then

            table.insert(specs, { name = "The Watcher", col = Color(185, 85, 255, 255) })

        end

        local spW = 175

        local spH = 28 + (math.max(#specs, 1) * 20) + 4

        local spX = ScrW() - spW - 20

        local spY = 70

        local hudAccent = (Garrylose.GetActiveTheme and Garrylose.GetActiveTheme().accent) or Color(0, 180, 255, 255)

        draw.RoundedBox(6, spX, spY, spW, spH, Color(11, 14, 20, 240))

        surface.SetDrawColor(hudAccent)

        surface.DrawOutlinedRect(spX, spY, spW, spH)

        -- Header

        draw.SimpleText("SPECTATORS (" .. #specs .. ")", "DefaultFixed", spX + 8, spY + 7, hudAccent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        surface.SetDrawColor(40, 50, 70, 200)

        surface.DrawLine(spX + 4, spY + 24, spX + spW - 4, spY + 24)

        if #specs == 0 then

            draw.SimpleText("None", "DefaultFixed", spX + 12, spY + 28, Color(120, 135, 160, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        else

            local rowY = spY + 28

            for _, s in ipairs(specs) do

                draw.SimpleText(s.name, "DefaultFixed", spX + 12, rowY, s.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

                rowY = rowY + 20

            end

        end

    else

        Garrylose.SpectatorStartTime = nil

    end

    -- --- 4. HvH On-Screen Status Indicators (DT, FD, DMG, AA) ---

    if Garrylose.Config.indicators_enabled ~= false then

        local indX = ScrW() / 2

        local indY = ScrH() / 2 + 45

        -- Double-Tap Status Indicator

        if Garrylose.Config.doubletap_enabled then

            local dtDelay = Garrylose.DTRechargeDelay or 0.35

            local timeSinceLastShot = curTime - (Garrylose.LastDTShootTime or 0)

            local isCharged = (timeSinceLastShot >= dtDelay)

            Garrylose.DoubleTapCharged = isCharged

            local dtText = "DT"

            local dtCol = Color(50, 255, 120, 240)

            if not isCharged then

                local progress = math.Clamp(timeSinceLastShot / dtDelay, 0, 1)

                local pct = math.floor(progress * 100)

                dtText = "DT (" .. pct .. "%)"

                dtCol = Color(255, 65, 65, 230)

            end

            draw.SimpleTextOutlined(dtText, "DermaDefaultBold", indX, indY, dtCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))

            indY = indY + 15

        end

        -- Fake-Duck Status Indicator

        if Garrylose.Config.fakeduck_enabled then

            draw.SimpleTextOutlined("FD", "DermaDefaultBold", indX, indY, Color(255, 160, 20, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))

            indY = indY + 15

        end

        -- Manual AA Direction Arrows HUD (Neverlose / Gamesense High-Visibility Chevrons)

        if Garrylose.Config.manual_aa_arrows then

            local mainCol = Garrylose.Config.col_manual_arrows or Color(0, 215, 255, 255)

            local baseCol = Color(mainCol.r, mainCol.g, mainCol.b, 255)

            local dimCol  = Color(mainCol.r, mainCol.g, mainCol.b, 50)

            local shadowCol = Color(0, 0, 0, 180)

            local cx = ScrW() / 2

            local cy = ScrH() / 2

            local dist = 55

            local aaState = tonumber(Garrylose.Config.manual_aa_state) or 0

            -- Robust Clockwise Triangle Drawer with Shadow Outline

            local function DrawArrow(xPeak, yPeak, xBase1, yBase1, xBase2, yBase2, isActive)

                local col = isActive and baseCol or dimCol

                draw.NoTexture()

                -- Shadow / Outline (slightly larger)

                local dx1 = (xPeak > cx) and 2 or ((xPeak < cx) and -2 or 0)

                local dy1 = (yPeak > cy) and 2 or ((yPeak < cy) and -2 or 0)

                surface.SetDrawColor(shadowCol)

                surface.DrawPoly({

                    { x = xPeak + dx1, y = yPeak + dy1 },

                    { x = xBase1, y = yBase1 },

                    { x = xBase2, y = yBase2 }

                })

                -- Foreground colored polygon

                surface.SetDrawColor(col)

                surface.DrawPoly({

                    { x = xPeak, y = yPeak },

                    { x = xBase1, y = yBase1 },

                    { x = xBase2, y = yBase2 }

                })

            end

            local size = 12

            local hSize = 9

            -- 1. LEFT ARROW (Points Left: CW order)

            local isL = (aaState == 1)

            local lSize = isL and (size + 3) or size

            local lHSize = isL and (hSize + 2) or hSize

            DrawArrow(

                cx - dist - lSize, cy,

                cx - dist + 2, cy - lHSize,

                cx - dist + 2, cy + lHSize,

                isL

            )

            -- 2. RIGHT ARROW (Points Right: CW order)

            local isR = (aaState == 2)

            local rSize = isR and (size + 3) or size

            local rHSize = isR and (hSize + 2) or hSize

            DrawArrow(

                cx + dist + rSize, cy,

                cx + dist - 2, cy + rHSize,

                cx + dist - 2, cy - rHSize,

                isR

            )

            -- 3. BACK ARROW (Points Down: CW order)

            local isB = (aaState == 3)

            local bSize = isB and (size + 3) or size

            local bHSize = isB and (hSize + 2) or hSize

            DrawArrow(

                cx, cy + dist + bSize,

                cx - bHSize, cy + dist - 2,

                cx + bHSize, cy + dist - 2,

                isB

            )

        end

        -- Min-Damage Override Status Indicator

        if Garrylose.Config.min_damage_override_active then

            local dmgVal = Garrylose.Config.aimbot_min_damage_override or 1

            draw.SimpleTextOutlined("DMG: " .. dmgVal, "DermaDefaultBold", indX, indY, Color(255, 220, 50, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))

            indY = indY + 15

        end

        -- Hitchance Override Status Indicator

        if Garrylose.Config.hitchance_override_active then

            local hcVal = Garrylose.Config.aimbot_hitchance_override or 20

            draw.SimpleTextOutlined("HC: " .. hcVal .. "%", "DermaDefaultBold", indX, indY, Color(0, 220, 255, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))

            indY = indY + 15

        end

    end

        -- --- Keybinds List HUD Window (Always-Visible when Enabled) ---

    if Garrylose.Config.keybinds_list_enabled then

        local activeBinds = {}

        local curTheme = Garrylose.GetActiveTheme()

        local themeAccent = curTheme.accent or Color(0, 180, 255, 255)

        local features = {

            { name = "Aimbot",        config = "aimbot_enabled",             bind = "bind_aimbot" },

            { name = "Night-Mode",    config = "nightmode_enabled",          bind = "bind_nightmode" },

            { name = "Anti-Aim",      config = "antiaim_enabled",            bind = "bind_antiaim" },

            { name = "Peek-Assist",  config = "autopeek_enabled",           bind = "bind_autopeek" },

            { name = "Min-Damage",    config = "min_damage_override_active", bind = "bind_min_damage_override", checkHold = true },

            { name = "HC-Override",   config = "hitchance_override_active",  bind = "bind_hitchance_override", checkHold = true },

            { name = "Triggerbot",    config = "triggerbot_enabled",         bind = "bind_triggerbot" },

            { name = "Air-Stop",      config = "airstop_enabled",            bind = "bind_airstop", checkHold = true },

            { name = "Double-Tap",    config = "doubletap_enabled",          bind = "bind_doubletap" },

            { name = "Fake-Duck",     config = "fakeduck_enabled",           bind = "bind_fakeduck" },

            { name = "Edge-Jump",     config = "edgejump_enabled",           bind = "bind_edgejump" },

            { name = "Crouch-Jump",   config = "crouchjump_enabled",         bind = "bind_crouchjump" },

            { name = "Thirdperson",   config = "thirdperson_enabled",        bind = "bind_thirdperson" },

            { name = "Auto-Strafe",   config = "autostrafe_enabled",         bind = "bind_autostrafe" },

            { name = "Auto-Bhop",     config = "bhop_enabled",               bind = "bind_bhop" },

            { name = "Player ESP",    config = "esp_enabled",                bind = "bind_esp" },

            { name = "Manual AA L",   config = "manual_aa_state",            bind = "bind_manual_left",  customCheck = function() return Garrylose.Config.manual_aa_state == 1 end },

            { name = "Manual AA R",   config = "manual_aa_state",            bind = "bind_manual_right", customCheck = function() return Garrylose.Config.manual_aa_state == 2 end },

            { name = "Manual AA B",   config = "manual_aa_state",            bind = "bind_manual_back",  customCheck = function() return Garrylose.Config.manual_aa_state == 3 end },

        }

        for _, f in ipairs(features) do

            local key = Garrylose.Config[f.bind]

            local hasKey = (key and key ~= KEY_NONE and key ~= 0 and key ~= -1)

            -- Strictly show ONLY features that have a key bound!

            if hasKey then

                local state = false

                if f.customCheck then

                    state = f.customCheck()

                else

                    state = Garrylose.Config[f.config] and true or false

                end

                if f.checkHold then

                    local isHeld = false

                    pcall(function()

                        if (key >= 107 and input.IsMouseDown(key)) or (key < 107 and input.IsKeyDown(key)) or input.IsButtonDown(key) then

                            isHeld = true

                        end

                    end)

                    state = state or isHeld

                end

                local kName = Garrylose.GetKeyName(key)

                local keyBadge = "[" .. kName .. "]"

                -- Active: vivid green / high contrast; Inactive: dimmed gray

                local activeColor = Color(50, 240, 110)

                local inactiveColor = Color(115, 130, 150)

                table.insert(activeBinds, {

                    name = f.name,

                    keyText = keyBadge,

                    state = state,

                    keyCol = state and activeColor or inactiveColor,

                    nameCol = state and Color(245, 252, 255) or Color(135, 145, 165)

                })

            end

        end

        -- Position tracking & Dragging

        Garrylose.KeybindsPos = Garrylose.KeybindsPos or {

            x = tonumber(Garrylose.Config.keybinds_x) or 30,

            y = tonumber(Garrylose.Config.keybinds_y) or (ScrH() / 2 - 80)

        }

        local kW = 205

        local rowH = 22

        local itemsCount = math.max(#activeBinds, 1)

        local kH = 28 + (itemsCount * rowH) + 6

        local kX = Garrylose.KeybindsPos.x

        local kY = Garrylose.KeybindsPos.y

        -- Dragging Logic

        if vgui.CursorVisible() then

            local mx, my = gui.MousePos()

            if input.IsMouseDown(MOUSE_LEFT) then

                if not Garrylose.IsDraggingKeybinds then

                    if mx >= kX and mx <= kX + kW and my >= kY and my <= kY + 28 then

                        Garrylose.IsDraggingKeybinds = true

                        Garrylose.DragOffset = { x = mx - kX, y = my - kY }

                    end

                else

                    Garrylose.KeybindsPos.x = math.Clamp(mx - Garrylose.DragOffset.x, 0, ScrW() - kW)

                    Garrylose.KeybindsPos.y = math.Clamp(my - Garrylose.DragOffset.y, 0, ScrH() - kH)

                    Garrylose.Config.keybinds_x = Garrylose.KeybindsPos.x

                    Garrylose.Config.keybinds_y = Garrylose.KeybindsPos.y

                    kX = Garrylose.KeybindsPos.x

                    kY = Garrylose.KeybindsPos.y

                end

            else

                Garrylose.IsDraggingKeybinds = false

            end

        else

            Garrylose.IsDraggingKeybinds = false

        end

        -- Window Background (Dark Glass)

        draw.RoundedBox(6, kX, kY, kW, kH, Color(11, 14, 20, 245))

        surface.SetDrawColor(Color(28, 38, 56, 255))

        surface.DrawOutlinedRect(kX, kY, kW, kH)

        -- Header Bar

        draw.RoundedBoxEx(6, kX, kY, kW, 26, Color(18, 24, 34, 255), true, true, false, false)

        surface.SetDrawColor(themeAccent)

        surface.DrawLine(kX + 1, kY + 26, kX + kW - 1, kY + 26)

        -- Left Accent Pip

        draw.RoundedBox(2, kX + 8, kY + 8, 3, 10, themeAccent)

        draw.SimpleText("KEYBINDS", "DermaDefaultBold", kX + 16, kY + 13, Color(235, 245, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        draw.SimpleText("[" .. #activeBinds .. "]", "DefaultFixed", kX + kW - 8, kY + 13, themeAccent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

        if #activeBinds == 0 then

            draw.SimpleText("No bound keys", "DefaultFixed", kX + kW / 2, kY + 38, Color(125, 145, 170), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        else

            for idx, b in ipairs(activeBinds) do

                local rY = kY + 28 + (idx - 1) * rowH + 11

                if b.state then

                    draw.RoundedBox(4, kX + 5, rY - 9, kW - 10, rowH - 2, Color(50, 240, 110, 15))

                end

                draw.SimpleText(b.name, "DermaDefaultBold", kX + 10, rY, b.nameCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText(b.keyText, "DefaultFixed", kX + kW - 10, rY, b.keyCol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

            end

        end

    end

    -- --- FOV Circle Drawing Engine ---

    if Garrylose.Config.aimbot_enabled and Garrylose.Config.draw_fov_ring then

        local fovVal = tonumber(Garrylose.Config.aimbot_fov) or 90

        local plyFov = (IsValid(ply) and ply:GetFOV()) or 90

        if plyFov <= 0 then plyFov = 90 end

        local fovRadius = math.tan(math.rad(fovVal / 2)) / math.tan(math.rad(plyFov / 2)) * (ScrH() / 2)

        local ringCol = Garrylose.Config.col_fov_ring or Color(0, 190, 255, 140)

        surface.SetDrawColor(ringCol)

        local cx, cy = ScrW() / 2, ScrH() / 2

        local segments = 64

        local poly = {}

        for i = 1, segments do

            local a = math.rad((i / segments) * 360)

            table.insert(poly, {

                x = cx + math.cos(a) * fovRadius,

                y = cy + math.sin(a) * fovRadius

            })

        end

        for i = 1, #poly do

            local nextPt = poly[i + 1] or poly[1]

            surface.DrawLine(poly[i].x, poly[i].y, nextPt.x, nextPt.y)

        end

    end

    for id, plugin in pairs(Garrylose.Plugins) do

        if plugin.enabled and plugin.onHUDPaint then

            pcall(plugin.onHUDPaint)

        end

    end

end)

-- INTERACTIVE COLOR PICKER MODAL WINDOW (Dark Glass Neverlose Style)

function Garrylose.OpenColorPicker(title, configKey, onColorChanged)

    if IsValid(Garrylose.ColorPickerFrame) then

        Garrylose.ColorPickerFrame:Remove()

    end

    local C_MAIN_BG     = Color(11, 14, 20, 252)

    local C_CARD_BG     = Color(18, 24, 34, 250)

    local C_CARD_BORDER = Color(28, 38, 56, 255)

    local C_ACCENT      = Garrylose.GetActiveTheme().accent

    local C_TEXT        = Color(230, 240, 255, 255)

    local C_TEXT_MUTED  = Color(125, 145, 170, 255)

    local cp = vgui.Create("DFrame")

    Garrylose.ColorPickerFrame = cp

    cp:SetTitle("")

    cp:SetSize(290, 330)

    cp:Center()

    cp:MakePopup()

    cp:ShowCloseButton(false)

    cp:SetDraggable(true)

    local initialCol = Garrylose.Config[configKey] or Color(0, 210, 255, 255)

    local curR = initialCol.r or 0

    local curG = initialCol.g or 210

    local curB = initialCol.b or 255

    local curA = initialCol.a or 255

    cp.Paint = function(self, w, h)

        draw.RoundedBox(8, 0, 0, w, h, C_MAIN_BG)

        surface.SetDrawColor(C_CARD_BORDER)

        surface.DrawOutlinedRect(0, 0, w, h)

        -- Header

        draw.RoundedBoxEx(8, 0, 0, w, 28, Color(22, 30, 44, 255), true, true, false, false)

        surface.SetDrawColor(C_ACCENT)

        surface.DrawLine(0, 28, w, 28)

        draw.SimpleText(string.upper(title or "COLOR PICKER"), "DermaDefaultBold", 12, 14, C_TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        -- Live Color Preview Bar

        local previewCol = Color(curR, curG, curB, curA)

        draw.RoundedBox(4, 15, 36, w - 30, 24, previewCol)

        surface.SetDrawColor(C_CARD_BORDER)

        surface.DrawOutlinedRect(15, 36, w - 30, 24)

        local lum = curR * 0.299 + curG * 0.587 + curB * 0.114

        draw.SimpleText(string.format("RGBA: %d, %d, %d, %d", curR, curG, curB, curA), "DefaultFixed", w / 2, 48, lum > 150 and Color(10,10,10) or Color(250,250,250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    end

    local closeBtn = vgui.Create("DButton", cp)

    closeBtn:SetSize(24, 24)

    closeBtn:SetPos(290 - 30, 2)

    closeBtn:SetText("X")

    closeBtn:SetFont("DermaDefaultBold")

    closeBtn:SetTextColor(C_TEXT_MUTED)

    closeBtn.Paint = function() end

    closeBtn.DoClick = function() cp:Close() end

    -- Color Preset Chips (1-Click selection)

    local chipsPnl = vgui.Create("DPanel", cp)

    chipsPnl:SetPos(15, 68)

    chipsPnl:SetSize(260, 24)

    chipsPnl.Paint = function() end

    local presets = {

        Color(0, 210, 255),   -- Cyan

        Color(245, 55, 75),   -- Red

        Color(40, 215, 120),  -- Green

        Color(175, 75, 255),  -- Purple

        Color(255, 165, 0),   -- Orange

        Color(255, 60, 160),  -- Pink

        Color(255, 255, 255), -- White

        Color(255, 225, 50),  -- Yellow

    }

    local mixer -- forward declaration

    local function ApplyColor()

        local newCol = Color(curR, curG, curB, curA)

        Garrylose.Config[configKey] = newCol

        if onColorChanged then onColorChanged(newCol) end

    end

    local chipW = (260 - (7 * 4)) / 8

    for idx, col in ipairs(presets) do

        local cBtn = vgui.Create("DButton", chipsPnl)

        cBtn:SetPos((idx - 1) * (chipW + 4), 2)

        cBtn:SetSize(chipW, 20)

        cBtn:SetText("")

        cBtn.Paint = function(self, bw, bh)

            draw.RoundedBox(3, 0, 0, bw, bh, col)

            surface.SetDrawColor(C_CARD_BORDER)

            surface.DrawOutlinedRect(0, 0, bw, bh)

        end

        cBtn.DoClick = function()

            curR = col.r

            curG = col.g

            curB = col.b

            if IsValid(mixer) then mixer:SetColor(Color(curR, curG, curB, curA)) end

            ApplyColor()

        end

    end

    -- Color Mixer / Sliders

    mixer = vgui.Create("DColorMixer", cp)

    mixer:SetPos(15, 98)

    mixer:SetSize(260, 175)

    mixer:SetPalette(false)

    mixer:SetAlphaBar(true)

    mixer:SetWangs(true)

    mixer:SetColor(initialCol)

    mixer.ValueChanged = function(self, col)

        curR = col.r

        curG = col.g

        curB = col.b

        curA = col.a

        ApplyColor()

    end

    -- Apply Button

    local applyBtn = vgui.Create("DButton", cp)

    applyBtn:SetPos(15, 285)

    applyBtn:SetSize(260, 28)

    applyBtn:SetText("CONFIRM COLOR")

    applyBtn:SetFont("DermaDefaultBold")

    applyBtn:SetTextColor(Color(250, 250, 250))

    applyBtn.Paint = function(self, bw, bh)

        draw.RoundedBox(4, 0, 0, bw, bh, self:IsHovered() and C_ACCENT or Color(22, 30, 44))

        surface.SetDrawColor(C_ACCENT)

        surface.DrawOutlinedRect(0, 0, bw, bh)

    end

    applyBtn.DoClick = function()

        ApplyColor()

        cp:Close()

    end

end

-- 7. GARRYLOSE MENU РІР‚вЂќ NEVERLOSE STYLE

local function GetKeyName(key)

    return Garrylose.GetKeyName(key)

end

function Garrylose.OpenMenu()

    if IsValid(Garrylose.MenuFrame) then

        Garrylose.MenuFrame:Remove()

    end

    local curTheme   = Garrylose.GetActiveTheme()

    local isLight = (Garrylose.Config.ui_style == 2)

    local BG         = isLight and Color(245, 247, 252, 255) or Color(18,  20,  27,  255)

    local SIDE_BG    = isLight and Color(235, 238, 245, 255) or Color(14,  16,  22,  255)

    local ITEM_BG    = isLight and Color(255, 255, 255, 255) or Color(22,  25,  34,  255)

    local ITEM_HOVER = isLight and Color(225, 230, 242, 255) or Color(28,  32,  44,  255)

    local BORDER     = isLight and Color(205, 212, 225, 255) or Color(35,  40,  58,  255)

    local HEADER_BG  = isLight and Color(240, 243, 250, 255) or Color(20,  23,  32,  255)

    local ACCENT     = curTheme.accent

    local ACCENT_DIM = curTheme.dim

    local ACCENT_HOV = curTheme.hov

    local TEXT       = isLight and Color(25,  30,  45,  255) or Color(220, 225, 240, 255)

    local TEXT_MUT   = isLight and Color(115, 125, 145, 255) or Color(110, 120, 145, 255)

    local TEXT_DARK  = isLight and Color(155, 165, 185, 255) or Color(60,  68,  90,  255)

    local C_GREEN    = Color(50,  210, 120, 255)

    local C_RED      = Color(230, 60,  80,  255)

    local C_INPUT    = isLight and Color(255, 255, 255, 255) or Color(12,  14,  20,  255)

    local scrW, scrH = ScrW(), ScrH()

    local FW     = math.min(900, scrW - 60)

    local FH     = math.min(600, scrH - 60)

    local SIDE_W = 165

    local CON_W  = FW - SIDE_W

    local HEAD_H = 40

    local frame = vgui.Create("DFrame")

    Garrylose.MenuFrame = frame

    frame:SetTitle(""); frame:SetSize(FW, FH); frame:Center()

    frame:MakePopup(); frame:ShowCloseButton(false); frame:SetDraggable(false)

    frame.Paint = function(self, w, h)

        draw.RoundedBox(6, 0, 0, w, h, BG)

        surface.SetDrawColor(BORDER)

        surface.DrawOutlinedRect(0, 0, w, h)

        -- top accent line

        surface.SetDrawColor(ACCENT)

        surface.DrawLine(1, 0, w - 1, 0)

    end

    local isDragging = false

    local dragOffset = { x = 0, y = 0 }

    local function MakeDraggable(pnl)

        if not IsValid(pnl) then return end

        pnl:SetMouseInputEnabled(true)

        pnl.OnMousePressed = function(self, mouseCode)

            if mouseCode == MOUSE_LEFT then

                isDragging = true

                local mx, my = gui.MousePos()

                local fx, fy = frame:GetPos()

                dragOffset.x = mx - fx

                dragOffset.y = my - fy

                self:MouseCapture(true)

            end

        end

        pnl.OnMouseReleased = function(self, mouseCode)

            if mouseCode == MOUSE_LEFT and isDragging then

                isDragging = false

                self:MouseCapture(false)

            end

        end

        pnl.OnCursorMoved = function(self, mx, my)

            if isDragging and input.IsMouseDown(MOUSE_LEFT) then

                local curMx, curMy = gui.MousePos()

                local newX = math.Clamp(curMx - dragOffset.x, 0, ScrW() - frame:GetWide())

                local newY = math.Clamp(curMy - dragOffset.y, 0, ScrH() - frame:GetTall())

                frame:SetPos(newX, newY)

            elseif isDragging and not input.IsMouseDown(MOUSE_LEFT) then

                isDragging = false

                self:MouseCapture(false)

            end

        end

    end

    frame.Think = function(self)

        if isDragging and not input.IsMouseDown(MOUSE_LEFT) then

            isDragging = false

        end

    end

    MakeDraggable(frame)

    local sidebar = vgui.Create("DPanel", frame)

    sidebar:SetPos(0, 0); sidebar:SetSize(SIDE_W, FH)

    sidebar.Paint = function(self, w, h)

        draw.RoundedBoxEx(6, 0, 0, w, h, SIDE_BG, true, false, true, false)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(w - 1, 0, w - 1, h)

    end

    MakeDraggable(sidebar)

    -- Logo

    local logo = vgui.Create("DPanel", sidebar)

    logo:SetPos(0, 0); logo:SetSize(SIDE_W, 50)

    logo.Paint = function(self, w, h)

        draw.SimpleText("GARRYLOSE", "DermaDefaultBold", 14, 18, ACCENT,   TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        draw.SimpleText(".CC",       "DermaDefault",     14 + surface.GetTextSize("GARRYLOSE") + 2, 18, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(10, h - 1, w - 10, h - 1)

    end

    MakeDraggable(logo)

    -- Category label

    local function SideLabel(parent, txt, y)

        local lbl = vgui.Create("DPanel", parent)

        lbl:SetPos(0, y); lbl:SetSize(SIDE_W, 20)

        lbl.Paint = function(self, w, h)

            draw.SimpleText(string.upper(txt), "DefaultFixed", 14, 10, TEXT_DARK, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

        MakeDraggable(lbl)

        return lbl

    end

    local activeTab = Garrylose.CurrentMenuTab or 1

    local tabs = {

        { name = "Rage",        desc = "Ragebot & Auto-Fire", icon = "aim"  },

        { name = "Anti-Aim",    desc = "Desync & Angles",   icon = "aa"   },

        { name = "Visuals",     desc = "ESP & Camera",      icon = "vis"  },

        { name = "Misc",        desc = "Movement & System", icon = "misc" },

        { name = "Configs",     desc = "Profile Manager",   icon = "cfg"  },

        { name = "Lua Scripts", desc = "IDE & Plugins",     icon = "lua"  },

        { name = "Options",     desc = "Theme & Settings",  icon = "opt"  },

    }

    local LoadTabContent  -- forward decl

    local navBtns = {}

    -- Pixel & Vector Icon Renderer (crisp on 32px buttons)

    local function DrawTabIcon(icon, cx, cy, col)

        surface.SetDrawColor(col)

        if icon == "aim" then

            -- Precision Crosshair

            surface.DrawLine(cx, cy - 6, cx, cy - 2)

            surface.DrawLine(cx, cy + 2, cx, cy + 6)

            surface.DrawLine(cx - 6, cy, cx - 2, cy)

            surface.DrawLine(cx + 2, cy, cx + 6, cy)

            surface.DrawOutlinedRect(cx - 4, cy - 4, 9, 9)

            draw.RoundedBox(0, cx - 1, cy - 1, 3, 3, col)

        elseif icon == "aa" then

            -- Anti-Aim Shield / Spin Vector

            surface.DrawLine(cx - 5, cy - 5, cx + 5, cy - 5)

            surface.DrawLine(cx - 5, cy - 5, cx - 5, cy + 1)

            surface.DrawLine(cx + 5, cy - 5, cx + 5, cy + 1)

            surface.DrawLine(cx - 5, cy + 1, cx, cy + 6)

            surface.DrawLine(cx + 5, cy + 1, cx, cy + 6)

            surface.DrawLine(cx - 2, cy - 1, cx + 2, cy - 1)

            surface.DrawLine(cx + 2, cy - 1, cx, cy - 3)

            surface.DrawLine(cx + 2, cy - 1, cx, cy + 1)

        elseif icon == "vis" then

            -- Visuals Eye

            surface.DrawLine(cx - 6, cy, cx - 2, cy - 4)

            surface.DrawLine(cx - 2, cy - 4, cx + 2, cy - 4)

            surface.DrawLine(cx + 2, cy - 4, cx + 6, cy)

            surface.DrawLine(cx - 6, cy, cx - 2, cy + 4)

            surface.DrawLine(cx - 2, cy + 4, cx + 2, cy + 4)

            surface.DrawLine(cx + 2, cy + 4, cx + 6, cy)

            draw.RoundedBox(2, cx - 2, cy - 2, 5, 5, col)

        elseif icon == "misc" then

            -- Lightning bolt / Controls

            surface.DrawLine(cx + 1, cy - 6, cx - 3, cy)

            surface.DrawLine(cx - 3, cy, cx + 2, cy)

            surface.DrawLine(cx + 2, cy, cx - 2, cy + 6)

            surface.DrawLine(cx - 2, cy + 6, cx + 3, cy - 1)

            surface.DrawLine(cx + 3, cy - 1, cx - 1, cy - 1)

            surface.DrawLine(cx - 1, cy - 1, cx + 1, cy - 6)

        elseif icon == "cfg" then

            -- Config Floppy Disk

            surface.DrawOutlinedRect(cx - 5, cy - 5, 11, 11)

            surface.DrawRect(cx - 3, cy - 5, 7, 4)

            surface.DrawOutlinedRect(cx - 4, cy + 1, 9, 4)

            surface.DrawLine(cx - 2, cy + 3, cx + 3, cy + 3)

        elseif icon == "lua" then

            -- Code Brackets < / >

            surface.DrawLine(cx - 2, cy - 5, cx - 6, cy)

            surface.DrawLine(cx - 6, cy, cx - 2, cy + 5)

            surface.DrawLine(cx + 1, cy - 6, cx - 1, cy + 6)

            surface.DrawLine(cx + 2, cy - 5, cx + 6, cy)

            surface.DrawLine(cx + 6, cy, cx + 2, cy + 5)

        elseif icon == "opt" then

            -- Settings Gear

            surface.DrawLine(cx - 2, cy - 5, cx + 2, cy - 5)

            surface.DrawLine(cx + 2, cy - 5, cx + 5, cy - 2)

            surface.DrawLine(cx + 5, cy - 2, cx + 5, cy + 2)

            surface.DrawLine(cx + 5, cy + 2, cx + 2, cy + 5)

            surface.DrawLine(cx + 2, cy + 5, cx - 2, cy + 5)

            surface.DrawLine(cx - 2, cy + 5, cx - 5, cy + 2)

            surface.DrawLine(cx - 5, cy + 2, cx - 5, cy - 2)

            surface.DrawLine(cx - 5, cy - 2, cx - 2, cy - 5)

            surface.DrawOutlinedRect(cx - 2, cy - 2, 5, 5)

        end

    end

    SideLabel(sidebar, "Main", 58)

    local function MakeTabBtn(idx, t, yPos)

        local btn = vgui.Create("DButton", sidebar)

        btn:SetPos(0, yPos); btn:SetSize(SIDE_W, 32)

        btn:SetText(""); btn.Index = idx

        btn.Paint = function(self, w, h)

            local act = (activeTab == self.Index)

            local hov = self:IsHovered()

            local ICO_X, ICO_Y = 22, h/2

            if act then

                draw.RoundedBox(0, 0, 0, w, h, ITEM_HOVER)

                draw.RoundedBox(2, 0, 5, 3, h - 10, ACCENT)

                DrawTabIcon(t.icon, ICO_X, ICO_Y, ACCENT)

                draw.SimpleText(t.name, "DermaDefaultBold", 38, h/2, ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            elseif hov then

                draw.RoundedBox(0, 0, 0, w, h, ITEM_BG)

                DrawTabIcon(t.icon, ICO_X, ICO_Y, TEXT)

                draw.SimpleText(t.name, "DermaDefault", 38, h/2, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            else

                DrawTabIcon(t.icon, ICO_X, ICO_Y, TEXT_MUT)

                draw.SimpleText(t.name, "DermaDefault", 38, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            end

        end

        btn.DoClick = function(self)

            activeTab = self.Index

            Garrylose.CurrentMenuTab = activeTab

            LoadTabContent(activeTab)

            for _, b in ipairs(navBtns) do b:InvalidateLayout(true) end

        end

        table.insert(navBtns, btn)

        return btn

    end

    local catBreaks = { [4] = "System" }

    local yOff = 78

    for i, t in ipairs(tabs) do

        if catBreaks[i] then

            SideLabel(sidebar, catBreaks[i], yOff)

            yOff = yOff + 20

        end

        MakeTabBtn(i, t, yOff)

        yOff = yOff + 30

    end

    -- User footer

    local foot = vgui.Create("DPanel", sidebar)

    foot:SetPos(0, FH - 44); foot:SetSize(SIDE_W, 44)

    foot.Paint = function(self, w, h)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(10, 0, w - 10, 0)

        -- avatar dot

        draw.RoundedBox(10, 10, 10, 22, 22, ACCENT_DIM)

        surface.SetDrawColor(ACCENT)

        surface.DrawOutlinedRect(10, 10, 22, 22)

        draw.SimpleText("G", "DermaDefaultBold", 21, 21, ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local nick = IsValid(LocalPlayer()) and LocalPlayer():Nick() or "Player"

        if #nick > 13 then nick = nick:sub(1, 12) .. ".." end

        draw.SimpleText(nick, "DermaDefault", 38, 16, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        draw.SimpleText("v1.0.0", "DefaultFixed", 38, 30, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    end

    MakeDraggable(foot)

    local header = vgui.Create("DPanel", frame)

    header:SetPos(SIDE_W, 0); header:SetSize(CON_W, HEAD_H)

    header.Paint = function(self, w, h)

        draw.RoundedBoxEx(6, 0, 0, w, h, HEADER_BG, false, true, false, false)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(0, h - 1, w, h - 1)

        -- breadcrumb

        if activeTab == "SEARCH" then

            draw.SimpleText("SEARCH", "DermaDefaultBold", 18, h/2, ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            draw.SimpleText("/ Feature Omnibar Search Results", "DermaDefault", 78, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        else

            local cur = tabs[activeTab] or tabs[1]

            draw.SimpleText(cur.name, "DermaDefaultBold", 18, h/2, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            local offX = 18 + select(1, surface.GetTextSize(cur.name)) + 8

            draw.SimpleText("/ " .. cur.desc, "DermaDefault", offX, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

    end

    MakeDraggable(header)

    -- Close button

    local closeBtn = vgui.Create("DButton", header)

    closeBtn:SetPos(CON_W - 36, 6); closeBtn:SetSize(28, 28)

    closeBtn:SetText("✕"); closeBtn:SetFont("DermaDefaultBold"); closeBtn:SetTextColor(TEXT_MUT)

    closeBtn.Paint = function(self, w, h)

        if self:IsHovered() then

            draw.RoundedBox(4, 0, 0, w, h, C_RED)

            self:SetTextColor(color_white)

        else

            draw.RoundedBox(4, 0, 0, w, h, ITEM_BG)

            surface.SetDrawColor(BORDER)

            surface.DrawOutlinedRect(0, 0, w, h)

            self:SetTextColor(TEXT_MUT)

        end

    end

    closeBtn.DoClick = function() frame:Close() end

    -- Config Selector Dropdown
    local cfgCombo = vgui.Create("DComboBox", header)
    cfgCombo:SetPos(CON_W - 36 - 190 - 130, 7)
    cfgCombo:SetSize(120, 26)
    cfgCombo:SetValue("Select Config...")
    cfgCombo:SetFont("DermaDefault")
    cfgCombo:SetTextColor(TEXT)
    cfgCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, C_INPUT)
        surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)
    end
    -- Populate configs
    local files, _ = file.Find("garrylose_configs/*.json", "DATA")
    for _, f in ipairs(files or {}) do
        cfgCombo:AddChoice(string.Replace(f, ".json", ""), f)
    end
    cfgCombo.OnSelect = function(self, index, value, data)
        Garrylose.LoadConfig(data)
        notification.AddLegacy("Loaded config: " .. value, NOTIFY_GENERIC, 3)
    end
    hook.Add("Garrylose_ConfigLoaded", "Garrylose_Combo_ConfigSync", function(loadedName)
        if not IsValid(cfgCombo) then return end
        local niceName = string.Replace(loadedName, ".json", "")
        cfgCombo:SetValue(niceName)
    end)

    -- Feature Search Omnibar Entry

    local searchEntry = vgui.Create("DTextEntry", header)

    searchEntry:SetPos(CON_W - 36 - 190, 7); searchEntry:SetSize(180, 26)

    searchEntry:SetPlaceholderText("🔍 Search features...")

    searchEntry:SetFont("DermaDefault")

    searchEntry:SetTextColor(TEXT)

    searchEntry:SetCursorColor(ACCENT)

    searchEntry.Paint = function(self, w, h)

        draw.RoundedBox(4, 0, 0, w, h, C_INPUT)

        surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

        surface.DrawOutlinedRect(0, 0, w, h)

        self:DrawTextEntryText(TEXT, ACCENT, color_white)

    end

    local scroll = vgui.Create("DScrollPanel", frame)

    scroll:SetPos(SIDE_W, HEAD_H); scroll:SetSize(CON_W, FH - HEAD_H)

    scroll.Paint = function() end

    MakeDraggable(scroll)

    local sbar = scroll:GetVBar()

    sbar:SetWide(4)

    sbar.Paint            = function(self, w, h) draw.RoundedBox(2, 0, 0, w, h, C_INPUT) end

    sbar.btnUp.Paint      = function() end

    sbar.btnDown.Paint    = function() end

    sbar.btnGrip.Paint    = function(self, w, h) draw.RoundedBox(2, 0, 0, w, h, ACCENT) end

    -- ════════════════════════════════════════════════════════════════════════

    -- WIDGET HELPERS

    -- ════════════════════════════════════════════════════════════════════════

    -- Section divider label (like "AIM", "OTHER" in Neverlose)

    local function Section(parent, txt, yRef)

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(14, yRef[1]); pnl:SetSize(parent:GetWide() - 28, 18)

        pnl.Paint = function(self, w, h)

            draw.SimpleText(string.upper(txt), "DefaultFixed", 0, h/2, TEXT_DARK, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            surface.SetDrawColor(BORDER)

            surface.DrawLine(surface.GetTextSize(string.upper(txt)) + 6, h/2, w, h/2)

        end

        MakeDraggable(pnl)

        yRef[1] = yRef[1] + 24

        return pnl

    end

    -- Neverlose-style row with Pill toggle, optional keybind badge, and optional color picker button

    local function Row(parent, txt, configKey, bindKey, colorKey, onChange, yRef)

        -- Handle overloaded parameter positions

        if type(colorKey) == "function" then

            yRef = onChange; onChange = colorKey; colorKey = nil

        elseif type(colorKey) == "table" and colorKey[1] ~= nil then

            yRef = colorKey; colorKey = nil

        end

        if type(onChange) == "table" then

            yRef = onChange; onChange = nil

        end

        local rowH = 28

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(0, yRef[1]); pnl:SetSize(parent:GetWide(), rowH)

        pnl.Paint = function(self, w, h)

            if self:IsHovered() then surface.SetDrawColor(ITEM_HOVER); surface.DrawRect(0, 0, w, h) end

        end

        pnl:SetMouseInputEnabled(true)

        -- Right-side widget positioning

        local rightPad = 14

        if colorKey then rightPad = rightPad + 24 end

        if bindKey  then rightPad = rightPad + 52 end

        -- Label

        local lbl = vgui.Create("DLabel", pnl)

        lbl:SetPos(14, 0); lbl:SetSize(parent:GetWide() - rightPad - 40, rowH)

        lbl:SetText(txt); lbl:SetFont("DermaDefault"); lbl:SetTextColor(TEXT)

        -- Pill toggle (only if configKey is provided)

        if configKey then

            local PILL_W, PILL_H = 32, 16

            local pillX = parent:GetWide() - rightPad - PILL_W

            local pillBtn = vgui.Create("DButton", pnl)

            pillBtn:SetPos(pillX, (rowH - PILL_H) / 2)

            pillBtn:SetSize(PILL_W, PILL_H); pillBtn:SetText("")

            pillBtn.Paint = function(self, w, h)

                local on = Garrylose.Config[configKey] and true or false

                draw.RoundedBox(h/2, 0, 0, w, h, on and ACCENT or BORDER)

                local kX = on and (w - h + 2) or 2

                draw.RoundedBox(h/2 - 1, kX, 2, h - 4, h - 4, color_white)

            end

            pillBtn.DoClick = function()

                Garrylose.Config[configKey] = not Garrylose.Config[configKey]

                if onChange then onChange(Garrylose.Config[configKey]) end

            end

            lbl:SetMouseInputEnabled(true)

            lbl.DoClick = function() pillBtn:DoClick() end

        elseif colorKey then

            lbl:SetMouseInputEnabled(true)

            lbl.DoClick = function()

                Garrylose.OpenColorPicker(txt, colorKey, function(newCol)

                    if onChange then onChange(newCol) end

                end)

            end

        end

        -- Keybind badge

        if bindKey then

            local bb = vgui.Create("DBinder", pnl)

            local bbX = parent:GetWide() - (colorKey and 38 or 14) - 46

            bb:SetPos(bbX, (rowH - 18) / 2)

            bb:SetSize(46, 18); bb:SetSelectedNumber(Garrylose.Config[bindKey] or KEY_NONE)

            bb.OnChange = function(self, num) Garrylose.Config[bindKey] = num end

            bb.Paint = function(self, w, h)

                local isListen = self.Trapping

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsHovered() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                local kn = GetKeyName(self:GetSelectedNumber())

                draw.SimpleText(isListen and "..." or kn, "DefaultFixed", w/2, h/2,

                    isListen and ACCENT or TEXT_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            end

        end

        -- Color picker button (small square preview showing current color)

        if colorKey then

            local colBtn = vgui.Create("DButton", pnl)

            colBtn:SetPos(parent:GetWide() - 14 - 18, (rowH - 16) / 2)

            colBtn:SetSize(18, 16); colBtn:SetText("")

            colBtn.Paint = function(self, w, h)

                local c = Garrylose.Config[colorKey] or Color(0, 210, 255)

                draw.RoundedBox(3, 0, 0, w, h, c)

                surface.SetDrawColor(self:IsHovered() and color_white or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

            end

            colBtn.DoClick = function()

                Garrylose.OpenColorPicker(txt, colorKey, function(newCol)

                    if onChange then onChange(newCol) end

                end)

            end

        end

        yRef[1] = yRef[1] + rowH

        return pnl

    end

    -- Slim Neverlose-style slider

    local function Slider(parent, txt, configKey, minV, maxV, decs, suffix, yRef)

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(0, yRef[1]); pnl:SetSize(parent:GetWide(), 44)

        pnl.Paint = function(self, w, h)

            draw.SimpleText(txt, "DermaDefault", 14, 10, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            local v = tonumber(Garrylose.Config[configKey]) or minV

            local str = string.format("%." .. (decs or 0) .. "f", v) .. (suffix or "")

            draw.SimpleText(str, "DefaultFixed", w - 14, 10, ACCENT, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

        end

        local sl = vgui.Create("DSlider", pnl)

        sl:SetPos(14, 24); sl:SetSize(parent:GetWide() - 28, 16)

        local frac = math.Clamp(((tonumber(Garrylose.Config[configKey]) or minV) - minV) / (maxV - minV), 0, 1)

        sl:SetSlideX(frac)

        sl.Paint = function(self, w, h)

            draw.RoundedBox(2, 0, 5, w, 4, BORDER)

            local fw = self:GetSlideX() * w

            if fw > 0 then draw.RoundedBox(2, 0, 5, fw, 4, ACCENT) end

        end

        sl.Knob.Paint = function(self, w, h)

            draw.RoundedBox(5, w/2-5, h/2-5, 10, 10, TEXT)

            surface.SetDrawColor(ACCENT); surface.DrawOutlinedRect(w/2-5, h/2-5, 10, 10)

        end

        sl.OnValueChanged = function(self, fx)

            local v = minV + fx * (maxV - minV)

            v = (decs or 0) == 0 and math.Round(v) or math.Round(v, decs)

            Garrylose.Config[configKey] = v

            if configKey == "nightmode_darkness" and v > 0 then

                Garrylose.Config.nightmode_enabled = true

            end

        end

        yRef[1] = yRef[1] + 50

        return pnl

    end

    -- Dropdown

    local function Combo(parent, txt, opts, configKey, onChange, yRef)

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(0, yRef[1]); pnl:SetSize(parent:GetWide(), 44)

        pnl.Paint = function(self, w, h)

            draw.SimpleText(txt, "DermaDefault", 14, 10, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

        local cb = vgui.Create("DComboBox", pnl)

        cb:SetPos(14, 22); cb:SetSize(parent:GetWide() - 28, 18)

        cb:SetTextColor(TEXT); cb:SetFont("DermaDefault")

        local selIdx = 1

        for i, o in ipairs(opts) do

            cb:AddChoice(o.label, o.data)

            if o.data == Garrylose.Config[configKey] then selIdx = i end

        end

        cb.Initializing = true

        cb:ChooseOptionID(selIdx)

        cb.Initializing = false

        cb.Paint = function(self, w, h)

            draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

            surface.SetDrawColor(self:IsHovered() and ACCENT or BORDER)

            surface.DrawOutlinedRect(0, 0, w, h)

            draw.SimpleText("▾", "DefaultFixed", w - 12, h/2, ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        end

        cb.OnSelect = function(self, idx, lbl, data)

            if self.Initializing then return end

            Garrylose.Config[configKey] = data

            if onChange then

                timer.Simple(0, function()

                    if isfunction(onChange) then

                        onChange(data)

                    end

                end)

            end

        end

        yRef[1] = yRef[1] + 50

        return pnl

    end

    -- Button

    local function Btn(parent, txt, col, onClick, yRef)

        local b = vgui.Create("DButton", parent)

        b:SetPos(14, yRef[1]); b:SetSize(parent:GetWide() - 28, 26)

        b:SetText(txt); b:SetFont("DermaDefaultBold"); b:SetTextColor(TEXT)

        b.Paint = function(self, w, h)

            local c = col or ACCENT

            if self:IsHovered() then

                draw.RoundedBox(4, 0, 0, w, h, c); self:SetTextColor(color_white)

            else

                draw.RoundedBox(4, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(c); surface.DrawOutlinedRect(0, 0, w, h)

                self:SetTextColor(TEXT)

            end

        end

        b.DoClick = onClick

        yRef[1] = yRef[1] + 32

        return b

    end

    -- Column builder (returns two panels side by side, each with a y-ref table)

    local function Columns(parent, padTop)

        padTop = padTop or 14

        local totalW = parent:GetWide() - 2

        local colW   = math.floor(totalW / 2) - 1

        local divX   = colW + 1

        -- divider

        local div = vgui.Create("DPanel", parent)

        div:SetPos(divX, 0); div:SetSize(1, 9999)

        div.Paint = function(self, w, h) surface.SetDrawColor(BORDER); surface.DrawRect(0, 0, w, h) end

        MakeDraggable(div)

        local c1 = vgui.Create("DPanel", parent)

        c1:SetPos(0, 0); c1:SetSize(colW, 9999)

        c1.Paint = function() end

        MakeDraggable(c1)

        local c2 = vgui.Create("DPanel", parent)

        c2:SetPos(divX + 1, 0); c2:SetSize(colW, 9999)

        c2.Paint = function() end

        MakeDraggable(c2)

        local y1 = {padTop}

        local y2 = {padTop}

        return c1, y1, c2, y2

    end

    -- ════════════════════════════════════════════════════════════════════════

    -- TAB CONTENT RENDERER

    -- ════════════════════════════════════════════════════════════════════════

        local function LoadSearchContent(query)

        scroll:Clear()

        local inner = vgui.Create("DPanel", scroll)

        inner:SetPos(0, 0); inner:SetSize(CON_W, FH - HEAD_H)

        inner.Paint = function() end

        MakeDraggable(inner)

        local c1, y1, c2, y2 = Columns(inner)

        local q = string.lower(string.Trim(query or ""))

        local allFeatures = {

            -- Aimbot & Rage

            { cat = "Ragebot", name = "Aimbot Master Toggle", cfg = "aimbot_enabled", bind = "bind_aimbot" },

            { cat = "Ragebot", name = "Remove Spread (Beta)", cfg = "nospread_enabled" },

            { cat = "Ragebot", name = "Silent Aim", cfg = "aimbot_silent" },

            { cat = "Ragebot", name = "Auto-Shoot", cfg = "aimbot_auto_shoot" },

            { cat = "Ragebot", name = "Double Tap Burst", cfg = "doubletap_enabled", bind = "bind_doubletap" },

            { cat = "Ragebot", name = "Recoil Control (RCS)", cfg = "aimbot_rcs" },

                        { cat = "Ragebot", name = "Air-Stop (Halt Air Move)", cfg = "airstop_enabled", bind = "bind_airstop" },

            { cat = "Ragebot", name = "Hit Chance", type = "slider", cfg = "aimbot_hitchance", min = 0, max = 100, dec = 0, suf = "%" },

            { cat = "Ragebot", name = "Hit Chance Override", cfg = "hitchance_override_active", bind = "bind_hitchance_override" },

            { cat = "Ragebot", name = "Triggerbot Master Toggle", cfg = "triggerbot_enabled", bind = "bind_triggerbot" },

            { cat = "Ragebot", name = "Triggerbot Delay", type = "slider", cfg = "triggerbot_delay", min = 0, max = 250, dec = 0, suf = " ms" },

            { cat = "Ragebot", name = "Triggerbot Head Only", cfg = "triggerbot_head_only" },

            

            { cat = "Movement", name = "Slidewalk (Moonwalk)", cfg = "slidewalk_enabled" },

            { cat = "Misc", name = "Panic Key (Clean Unload)", bind = "bind_panic" },

            { cat = "Ragebot", name = "Head Priority", cfg = "aimbot_head_priority" },

            { cat = "Ragebot", name = "Multipoint Hitscan", cfg = "aimbot_multipoint" },

            { cat = "Ragebot", name = "Multipoint Scale", type = "slider", cfg = "aimbot_multipoint_scale", min = 0.1, max = 1.0, dec = 2, suf = "x" },

            { cat = "Ragebot", name = "Aimbot FOV", type = "slider", cfg = "aimbot_fov", min = 1, max = 180, dec = 0, suf = "°" },

            { cat = "Ragebot", name = "Min Damage", type = "slider", cfg = "aimbot_min_damage", min = 1, max = 100, dec = 0, suf = " HP" },

            { cat = "Ragebot", name = "Min Damage Override", cfg = "min_damage_override_active", bind = "bind_min_damage_override" },

            -- Anti-Aim

            { cat = "Anti-Aim", name = "Anti-Aim Master Toggle", cfg = "antiaim_enabled", bind = "bind_antiaim" },

            { cat = "Anti-Aim", name = "Fake Duck", cfg = "fakeduck_enabled", bind = "bind_fakeduck" },

            { cat = "Anti-Aim", name = "Manual Direction Arrows", cfg = "manual_aa_arrows", col = "col_manual_arrows" },

            { cat = "Anti-Aim", name = "Desync Ghost Model", cfg = "desync_ghost_enabled", col = "col_desync_ghost" },

            -- Visuals & ESP

            { cat = "Visuals", name = "Master ESP Wallhack", cfg = "esp_enabled", bind = "bind_esp" },

            { cat = "Visuals", name = "2D Boxes", cfg = "esp_boxes", col = "col_esp_boxes" },

            { cat = "Visuals", name = "Player Names", cfg = "esp_names" },

            { cat = "Visuals", name = "Health Bar", cfg = "esp_health" },

            { cat = "Visuals", name = "3D Skeletons", cfg = "esp_skeletons", col = "col_esp_skeletons" },

            { cat = "Visuals", name = "Snaplines", cfg = "esp_snaplines", col = "col_esp_snaplines" },

            { cat = "Visuals", name = "Offscreen Arrows", cfg = "offscreen_esp_enabled", col = "col_offscreen_esp" },

            { cat = "Visuals", name = "2D Radar", cfg = "radar_enabled", bind = "bind_radar" },

            { cat = "Visuals", name = "Night Mode", cfg = "nightmode_enabled", bind = "bind_nightmode", col = "col_nightmode" },

            { cat = "Visuals", name = "Skybox Modulation", cfg = "skybox_mod_enabled", col = "col_skybox" },

            { cat = "Visuals", name = "Fullbright", cfg = "fullbright_enabled" },

            { cat = "Visuals", name = "World Fog", cfg = "fog_enabled", col = "col_fog" },

            { cat = "Visuals", name = "Ammo Bar ESP", cfg = "esp_ammo", col = "col_esp_ammo" },

            { cat = "Visuals", name = "Prop Transparency", cfg = "prop_transparency_enabled", col = nil },

            { cat = "Visuals", name = "Custom Skybox", cfg = "custom_skybox_enabled" },

            { cat = "Visuals", name = "Grenade Blast Warning", cfg = "grenade_warning_enabled", col = "col_grenade_warning" },

            { cat = "Visuals", name = "Spectator List", cfg = "spectator_list_enabled" },

            { cat = "Visuals", name = "Laser Bullet Tracers", cfg = "bullet_tracers_enabled", col = "col_bullet_tracers" },

            { cat = "Visuals", name = "3D Bullet Impacts", cfg = "bullet_impacts_enabled", col = "col_bullet_impacts" },

            { cat = "Visuals", name = "Grenade Pred (Approx)", cfg = "grenade_pred_enabled", col = "col_grenade_pred" },

            { cat = "Visuals", name = "Thirdperson View", cfg = "thirdperson_enabled", bind = "bind_thirdperson" },

            { cat = "Visuals", name = "Thirdperson Distance", type = "slider", cfg = "thirdperson_dist", min = 30, max = 300, dec = 0, suf = " u" },

            { cat = "Visuals", name = "FOV Override", type = "slider", cfg = "fov_changer", min = 75, max = 130, dec = 0, suf = "°" },

            { cat = "Visuals", name = "Draw FOV Ring", cfg = "draw_fov_ring", col = "col_fov_ring" },

            { cat = "Visuals", name = "Aspect Ratio", cfg = "aspect_ratio_enabled" },

            { cat = "Visuals", name = "Viewmodel FOV", type = "slider", cfg = "viewmodel_fov", min = 50, max = 120, dec = 0, suf = "°" },

            { cat = "Visuals", name = "Viewmodel Offset X", type = "slider", cfg = "viewmodel_x", min = -15, max = 15, dec = 1, suf = "" },

            { cat = "Visuals", name = "Viewmodel Offset Y", type = "slider", cfg = "viewmodel_y", min = -15, max = 15, dec = 1, suf = "" },

            { cat = "Visuals", name = "Viewmodel Offset Z", type = "slider", cfg = "viewmodel_z", min = -15, max = 15, dec = 1, suf = "" },

            -- Movement & Misc

            { cat = "Movement", name = "Auto BunnyHop", cfg = "bhop_enabled", bind = "bind_bhop" },

            { cat = "Movement", name = "Auto Strafer", cfg = "autostrafe_enabled", bind = "bind_autostrafe" },

            { cat = "Movement", name = "Edge Jump", cfg = "edgejump_enabled", bind = "bind_edgejump" },

            { cat = "Movement", name = "Crouch Jump", cfg = "crouchjump_enabled", bind = "bind_crouchjump" },

            { cat = "Movement", name = "Peek Assist", cfg = "autopeek_enabled", bind = "bind_autopeek", col = "col_autopeek" },

            { cat = "Movement", name = "Auto Reload", cfg = "autoreload_enabled" },

            { cat = "Misc", name = "Crosshair Hitmarker", cfg = "hitmarker_enabled", col = "col_hitmarker" },

            { cat = "Misc", name = "Floating Damage (-HP)", cfg = "hitmarker_damage_numbers", col = "col_dmg_numbers" },

            { cat = "Misc", name = "Hitsound Audio", cfg = "hitsound_enabled" },

            { cat = "Misc", name = "Kill Effect", cfg = "killeffect_enabled", col = "col_killeffect" },

            { cat = "Misc", name = "HvH Killsay Trash-Talk", cfg = "killsay_enabled" },

            { cat = "Misc", name = "Watermark HUD", cfg = "watermark_enabled" },

            { cat = "Misc", name = "Keybinds HUD", cfg = "keybinds_list_enabled" }

        }

        local matchCount = 0

        Section(c1, "SEARCH RESULTS (COL 1)", y1)

        Section(c2, "SEARCH RESULTS (COL 2)", y2)

        for _, feat in ipairs(allFeatures) do

            local fName = string.lower(feat.name)

            local fCat = string.lower(feat.cat)

            if string.find(fName, q, 1, true) or string.find(fCat, q, 1, true) then

                matchCount = matchCount + 1

                local colPnl = (matchCount % 2 == 1) and c1 or c2

                local colY = (matchCount % 2 == 1) and y1 or y2

                if feat.type == "slider" then

                    Slider(colPnl, "[" .. feat.cat .. "] " .. feat.name, feat.cfg, feat.min, feat.max, feat.dec, feat.suf, colY)

                else

                    Row(colPnl, "[" .. feat.cat .. "] " .. feat.name, feat.cfg, feat.bind, feat.col, nil, colY)

                end

            end

        end

        if matchCount == 0 then

            local emptyPnl = vgui.Create("DPanel", scroll)

            emptyPnl:SetPos(14, 20); emptyPnl:SetSize(CON_W - 28, 60)

            emptyPnl.Paint = function(self, w, h)

                draw.SimpleText("No matching features found for '" .. query .. "'", "DermaDefaultBold", w/2, h/2, TEXT_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            end

        end

        local maxH = math.max(y1[1], y2[1]) + 20

        inner:SetSize(CON_W, math.max(maxH, FH - HEAD_H))

        c1:SetSize(c1:GetWide(), maxH)

        c2:SetSize(c2:GetWide(), maxH)

        scroll:GetCanvas():SetTall(maxH)

        scroll:InvalidateLayout(true)

    end

LoadTabContent = function(tabId)

        scroll:Clear()

        -- Inner content panel (full width, grows with content)

        local inner = vgui.Create("DPanel", scroll)

        inner:SetPos(0, 0); inner:SetSize(CON_W, FH - HEAD_H)

        inner.Paint = function() end

        MakeDraggable(inner)

        local c1, y1, c2, y2 = Columns(inner)

        if tabId == 1 then

            Section(c1, "AIM", y1)

            Row(c1, "Enabled",             "aimbot_enabled",       "bind_aimbot",   nil, y1)

            Row(c1, "Silent Aim",          "aimbot_silent",        nil,             nil, y1)

            Row(c1, "Auto Fire",           "aimbot_auto_shoot",    nil,             nil, y1)

            Row(c1, "Remove Spread (Beta)",      "nospread_enabled", nil,           nil, y1)

            Row(c1, "Penetrate Walls",     "aimbot_vischeck",      nil,             nil, y1)

            Slider(c1, "Field of View",    "aimbot_fov",           1, 180, 0, "°",  y1)

            Row(c1, "FOV Circle",          "draw_fov_ring",        nil, "col_fov_ring", nil, y1)

            Section(c1, "SELECTION", y1)

            Row(c1, "Target Players",      "aimbot_target_players",nil, nil, y1)
            Row(c1, "Head Priority",       "aimbot_head_priority", nil, nil, y1)
            Slider(c1, "Head Aim Ticks",   "aimbot_lock_ticks",    1, 8, 0, " Ticks", y1)
            Row(c1, "Hitbox: Head",        "aimbot_hitbox_head",   nil, nil, y1)

            Row(c1, "Hitbox: Chest",       "aimbot_hitbox_chest",  nil, nil, y1)

            Row(c1, "Hitbox: Stomach",     "aimbot_hitbox_stomach",nil, nil, y1)

            Row(c1, "Multipoint",          "aimbot_multipoint",    nil, nil, y1)

            Slider(c1, "Multipoint Scale", "aimbot_multipoint_scale", 0.1, 1.0, 2, "x", y1)

            Slider(c1, "Min Damage",       "aimbot_min_damage",    1, 100, 0, " HP", y1)

            Row(c1, "Min Damage Override", "min_damage_override_active", "bind_min_damage_override", nil, y1)

            Slider(c1, "Override Value",   "aimbot_min_damage_override", 1, 100, 0, " HP", y1)

            Row(c1, "Enable Hit Chance",   "hitchance_enabled",    nil, nil, y1)

            Slider(c1, "Hit Chance",       "aimbot_hitchance",     0, 100, 0, "%",   y1)

            Row(c1, "HC Override",         "hitchance_override_active", "bind_hitchance_override", nil, y1)

            Slider(c1, "HC Override Val",  "aimbot_hitchance_override", 0, 100, 0, "%", y1)

            Section(c2, "ACCURACY & STOPS", y2)

                        Row(c2, "Air-Stop",            "airstop_enabled",      "bind_airstop",  nil, y2)

            Row(c2, "Recoil Compensation", "aimbot_rcs",           nil,             nil, y2)

            Row(c2, "Peek Assist",         "autopeek_enabled",     "bind_autopeek", "col_autopeek", nil, y2)

            Section(c2, "TRIGGERBOT", y2)

            Row(c2, "Enable Triggerbot",   "triggerbot_enabled",   "bind_triggerbot", nil, y2)

            Slider(c2, "Trigger Delay",    "triggerbot_delay",     0, 250, 0, " ms", y2)

            Row(c2, "Head Only",           "triggerbot_head_only", nil, nil, y2)

            Section(c2, "BURST & FIRE", y2)

            Row(c2, "Double Tap",          "doubletap_enabled",    "bind_doubletap",nil, y2)

            Combo(c2, "Shoot Mode",        {

                { label = "Rapid Pulse",  data = 2 },

                { label = "Hold",         data = 1 }

            }, "aimbot_shoot_mode", nil, y2)

            Row(c2, "Target NPCs",         "aimbot_target_npcs",   nil, nil, y2)

            Row(c2, "Team Check",          "aimbot_team_check",    nil, nil, y2)

        elseif tabId == 2 then

            Section(c1, "ANTI-AIM", y1)

            Row(c1, "Enabled",             "antiaim_enabled",       "bind_antiaim", nil, y1)

            Combo(c1, "Pitch",             {

                { label = "None (Look Dir)", data = 0 },

                { label = "Down (-89°)",     data = 1 },

                { label = "Up  (+89°)",      data = 2 },

                { label = "Jitter Pitch",    data = 3 },

                { label = "Random Jitter",   data = 4 },

            }, "antiaim_pitch", function() LoadTabContent(2) end, y1)

            local pMode = tonumber(Garrylose.Config.antiaim_pitch) or 1

            if pMode == 3 or pMode == 4 then

                Slider(c1, "Pitch Jitter Angle", "antiaim_pitch_jitter_angle", 1, 89, 0, "°", y1)

            end

            Combo(c1, "Yaw",               {

                { label = "Backward (180°)", data = 1 },

                { label = "Spinbot",         data = 2 },

                { label = "Jitter",          data = 3 },

                { label = "Random Jitter",   data = 4 },

            }, "antiaim_yaw", function() LoadTabContent(2) end, y1)

            local yawMode = tonumber(Garrylose.Config.antiaim_yaw) or 1

            if yawMode == 2 then

                Slider(c1, "Spinbot Speed",    "antiaim_spin_speed",    50, 2500, 0, " °/s", y1)

            end

            if yawMode == 3 or yawMode == 4 then

                Slider(c1, "Jitter Angle",     "antiaim_jitter_angle",  1, 360, 0, "°", y1)

                Combo(c1, "Jitter Side",       {

                    { label = "Backward (+180°)", data = 1 },

                    { label = "Forward (0°)",     data = 2 },

                }, "antiaim_jitter_side", nil, y1)

            end

            Row(c1, "Direction Arrows (HUD)","manual_aa_arrows",    nil, "col_manual_arrows", nil, y1)

            Section(c2, "MANUAL OVERRIDES", y2)

            Row(c2, "Manual Left",  nil, "bind_manual_left",  nil, y2)

            Row(c2, "Manual Right", nil, "bind_manual_right", nil, y2)

            Row(c2, "Manual Back  (180°)", nil, "bind_manual_back",  nil, y2)

            Section(c2, "DESYNC VISUALS", y2)

            Row(c2, "Desync Ghost (Real)", "desync_ghost_enabled", nil, "col_desync_ghost", nil, y2)

            Combo(c2, "Ghost Material", {

                { label = "Flat Glow (Chams)", data = 1 },

                { label = "Wireframe Mesh",    data = 2 }

            }, "desync_ghost_mat", nil, y2)

            Section(c2, "STATUS", y2)

            local infoPnl = vgui.Create("DPanel", c2)

            infoPnl:SetPos(0, y2[1]); infoPnl:SetSize(c2:GetWide(), 100)

            infoPnl.Paint = function(self, w, h)

                draw.RoundedBox(4, 14, 0, w - 28, h, C_INPUT)

                surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(14, 0, w - 28, h)

                draw.SimpleText("ANTI-AIM ENGINE",        "DermaDefaultBold", 26, 14, ACCENT,   TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("View Drift Fix: Active", "DefaultFixed",     26, 34, TEXT,      TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Movement Fix: 2D Delta Vector", "DefaultFixed", 26, 50, TEXT,  TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                local curSpeed = math.Round(tonumber(Garrylose.Config.antiaim_spin_speed) or 450)

                draw.SimpleText("Spin Speed: " .. curSpeed .. " deg/s", "DefaultFixed", 26, 66, TEXT_MUT,  TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Silent Masking: ON",     "DefaultFixed",     26, 82, TEXT_MUT,  TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            end

            MakeDraggable(infoPnl)

            y2[1] = y2[1] + 108

        elseif tabId == 3 then

            Section(c1, "ESP (OVERLAY)", y1)

            Row(c1, "Enable ESP",          "esp_enabled",           "bind_esp",          nil,                 nil, y1)

            Row(c1, "2D Boxes",            "esp_boxes",             nil,                 "col_esp_boxes",     nil, y1)

            Row(c1, "Player Names",        "esp_names",             nil,                 "col_esp_names",     nil, y1)

            Row(c1, "Health Bar",          "esp_health",            nil,                 "col_esp_health",    nil, y1)

            Row(c1, "Ammo Bar",            "esp_ammo",              nil,                 "col_esp_ammo",      nil, y1)

            Row(c1, "Skeleton ESP",        "esp_skeleton",          nil,                 "col_esp_skeleton",  nil, y1)

            Row(c1, "Player Trails",       "esp_trail",             nil,                 "col_esp_trail", nil, y1)
            Row(c1, "Jump Circles",        "jump_circles",          nil,                 "col_jump_circles", nil, y1)
            Row(c1, "Box Fill",            "esp_box_fill",          nil,                 "col_esp_box_fill", nil, y1)
            
            Section(c1, "WORLD & CHAMS", y1)
            Row(c1, "World Modulation",    "worldmod",              nil,                 "col_worldmod", nil, y1)
            Row(c1, "Custom Fog",          "fog_enabled",           nil,                 "col_fog", nil, y1)
            Slider(c1, "Fog Start",        "fog_start",             0, 5000, 0, " u", y1)
            Slider(c1, "Fog End",          "fog_end",               0, 10000, 0, " u", y1)
            Row(c1, "Player Chams",        "chams_player",          nil,                 "col_chams_player", nil, y1)
            Row(c1, "NPC Chams",           "chams_npc",             nil,                 "col_chams_npc", nil, y1)
            Row(c1, "Self Chams",          "chams_self",            nil,                 "col_chams_self", nil, y1)
            Row(c1, "Hands Chams",         "chams_hands",           nil,                 "col_chams_hands", nil, y1)

            Row(c1, "Weapon Info",         "esp_weapon_info",       nil,                 "col_esp_weapon",    nil, y1)

            Row(c1, "Glow Bloom Outline",  "glow_esp_enabled",      nil,                 "col_glow_esp",      nil, y1)

            Row(c1, "Offscreen Arrows",    "offscreen_esp_enabled", nil,                 "col_offscreen_esp", nil, y1)

            Row(c1, "Snaplines",           "esp_snaplines",         nil,                 "col_esp_snaplines", nil, y1)

            Row(c1, "Grenade Warning",     "grenade_warning_enabled", nil,               "col_grenade_warning", nil, y1)

            Row(c1, "Spectator List",      "spectator_list_enabled", nil,                nil,                 nil, y1)

            Section(c1, "VIEWMODEL OFFSETS", y1)

            Slider(c1, "Viewmodel FOV", "viewmodel_fov",        50, 120, 0, "°",     y1)

            Slider(c1, "Offset X (L/R)","viewmodel_x",          -15, 15, 1, "",      y1)

            Slider(c1, "Offset Y (F/B)","viewmodel_y",          -15, 15, 1, "",      y1)

            Slider(c1, "Offset Z (U/D)","viewmodel_z",          -15, 15, 1, "",      y1)

            Section(c1, "VIEWMODEL ANGLES", y1)
            Slider(c1, "View Pitch",    "viewmodel_pitch",       -180, 180, 0, "°",   y1)
            Slider(c1, "View Yaw",      "viewmodel_yaw",         -180, 180, 0, "°",   y1)
            Slider(c1, "View Roll",     "viewmodel_roll",        -180, 180, 0, "°",   y1)

            Section(c2, "WORLD & PROPS", y2)

            Row(c2, "Night Mode",          "nightmode_enabled",    "bind_nightmode",    "col_nightmode",     nil, y2)

            Slider(c2, "Night Darkness",   "nightmode_darkness",   0.1, 0.9, 2, "x",    y2)

            Row(c2, "Skybox Modulation",   "skybox_mod_enabled",   nil,                 "col_skybox",        nil, y2)

            Row(c2, "Custom Skybox",       "custom_skybox_enabled",nil,                 nil,                 nil, y2)

            Combo(c2, "Sky Theme",         {

                { label = "Deep Space Galaxy",  data = 1 },

                { label = "Midnight Starry",    data = 2 },

                { label = "Sunset Crimson",     data = 3 },

                { label = "Cyberpunk Violet",   data = 4 },

                { label = "Void Black",         data = 5 }

            }, "custom_skybox_type", nil, y2)

            Row(c2, "Prop Transparency",   "prop_transparency_enabled", nil,            nil,                     nil, y2)

            Combo(c2, "Prop Style",        {

                { label = "Translucent Alpha", data = 1 },

                { label = "Wireframe Mesh",    data = 2 }

            }, "prop_transparency_mode", nil, y2)

            Slider(c2, "Prop Alpha",       "prop_alpha",           10, 255, 0, "",      y2)

            Row(c2, "Fullbright",          "fullbright_enabled",   nil,                 nil,                 nil, y2)

            Row(c2, "World Fog",           "fog_enabled",          nil,                 "col_fog",           nil, y2)

            Slider(c2, "Fog Density",      "fog_density",          500, 5000, 0, " u",  y2)

            Section(c2, "BULLET VISUALS", y2)

            Row(c2, "Laser Bullet Tracers","bullet_tracers_enabled",nil,                 "col_bullet_tracers", nil, y2)

            Row(c2, "3D Bullet Impacts",   "bullet_impacts_enabled",nil,                 "col_bullet_impacts",nil, y2)

            Section(c2, "RADAR (MINIMAP)", y2)

            Row(c2, "Enable Radar",        "radar_enabled",         "bind_radar",       nil, y2)

            Combo(c2, "Target Filter",     {

                { label = "Players & NPCs", data = 1 },

                { label = "Only Players",   data = 2 },

                { label = "Only NPCs",      data = 3 },

            }, "radar_target_mode", nil, y2)

            Row(c2, "Player Blips Color",  nil,                     nil,                "col_radar_players", nil, y2)

            Row(c2, "NPC Blips Color",     nil,                     nil,                "col_radar_npcs",    nil, y2)

            Slider(c2, "Radar Range",      "radar_range",           500, 6000, 0, " u", y2)

            Slider(c2, "Radar Size",       "radar_size",            100, 240, 0, " px", y2)

            Section(c2, "CAMERA & VIEW", y2)

            Row(c2, "Thirdperson View", "thirdperson_enabled",  "bind_thirdperson",  nil,                nil, y2)

            Slider(c2, "TP Distance",   "thirdperson_dist",     30, 300, 0, " u",    y2)

            Slider(c2, "FOV Override",  "fov_changer",          75, 130, 0, "°",     y2)

            Row(c2, "Draw FOV Ring",    "draw_fov_ring",        nil,                 "col_fov_ring",     nil, y2)

            Section(c2, "SCREEN RATIO", y2)

            Row(c2, "Aspect Ratio",     "aspect_ratio_enabled", nil,                 nil,                nil, y2)

            Slider(c2, "Ratio Value",   "aspect_ratio_val",     0.8, 2.5, 2, "x",    y2)

        elseif tabId == 4 then

            Section(c1, "MOVEMENT", y1)

            Row(c1, "Auto BunnyHop",    "bhop_enabled",          "bind_bhop",        nil, y1)

            Row(c1, "Auto Strafer",     "autostrafe_enabled",    "bind_autostrafe",  nil, y1)

            Combo(c1, "Strafer Mode",   {

                { label = "Mouse Delta", data = 1 },

                { label = "Directional",data = 2 },

            }, "autostrafe_mode", nil, y1)

            Row(c1, "Edge Jump",        "edgejump_enabled",      "bind_edgejump",    nil, y1)

            

            Row(c1, "Slidewalk (Moonwalk)","slidewalk_enabled",  nil,                nil, y1)

            Row(c1, "Fake Duck",        "fakeduck_enabled",      "bind_fakeduck",    nil, y1)

            Row(c1, "Crouch Jump",      "crouchjump_enabled",    "bind_crouchjump",  nil, y1)

            Row(c1, "Peek Assist",      "autopeek_enabled",      "bind_autopeek",    "col_autopeek", nil, y1)

            Row(c1, "Auto Reload",      "autoreload_enabled",    nil,                nil, y1)

            Section(c2, "HIT FEEDBACK", y2)

            Row(c2, "Crosshair Hitmarker", "hitmarker_enabled",        nil, "col_hitmarker",   nil, y2)

            Row(c2, "Floating Damage",     "hitmarker_damage_numbers", nil, "col_dmg_numbers", nil, y2)

            Row(c2, "Hitsound Audio",      "hitsound_enabled",         nil, nil,               nil, y2)

            Combo(c2, "Hitsound Preset",{

                { label = "Bell",          data = 1 },

                { label = "Metallic",      data = 2 },

                { label = "Click",         data = 3 },

                { label = "Balloon Pop",   data = 4 },

                { label = "Custom File",   data = 5 },

            }, "hitsound_type", nil, y2)

            Section(c2, "HVH SPECIALS", y2)

            Row(c2, "Kill Effect",             "killeffect_enabled", nil, "col_killeffect", nil, y2)

            Combo(c2, "Effect Type", {

                { label = "Tesla Lightning",   data = 1 },

                { label = "Plasma Explosion",  data = 2 },

                { label = "Blood Burst",       data = 3 },

                { label = "Energy Wave",       data = 4 },

            }, "killeffect_type", nil, y2)

            Row(c2, "HvH Killsay Trash-Talk", "killsay_enabled", nil, nil, y2)

            Section(c2, "DISPLAY HUD", y2)

            Row(c2, "Watermark HUD",    "watermark_enabled",     nil, nil, y2)

            Row(c2, "Keybinds HUD",     "keybinds_list_enabled", nil, nil, y2)
            
            Row(c2, "Auto Reload",      "auto_reload",           nil, nil, y2)
            Row(c2, "Flashlight Spam",  "flash_spam",            nil, nil, y2)
            Row(c2, "Chat Spammer",     "chat_spam",             nil, nil, y2)

            Section(c2, "FREECAM", y2)
            Row(c2, "Freecam", "freecam_enabled", "bind_freecam", nil, y2)
            Slider(c2, "Freecam Speed", "freecam_speed",         1, 100, 0, "x", y2)
            
            Section(c2, "SPECIAL", y2)
            Row(c2, "Nothing", "nothing_enabled", "bind_nothing", nil, y2)
            
            Section(c2, "SYSTEM", y2)

            -- Menu bind

            local mbLbl = vgui.Create("DPanel", c2)

            mbLbl:SetPos(0, y2[1]); mbLbl:SetSize(c2:GetWide(), 18)

            mbLbl.Paint = function(self, w, h)

                draw.SimpleText("Menu Keybind", "DermaDefault", 14, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            end

            MakeDraggable(mbLbl)

            y2[1] = y2[1] + 20

            local mbBind = vgui.Create("DBinder", c2)

            mbBind:SetPos(14, y2[1]); mbBind:SetSize(c2:GetWide() - 28, 22)

            mbBind:SetSelectedNumber(Garrylose.Config.bind_menu or KEY_INSERT)

            mbBind.OnChange = function(self, n) Garrylose.Config.bind_menu = n end

            mbBind.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsHovered() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                local k = GetKeyName(self:GetSelectedNumber())

                draw.SimpleText(self.Trapping and "[ ... ]" or "[ "..k.." ]", "DermaDefaultBold", w/2, h/2, self.Trapping and ACCENT or TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            end

            y2[1] = y2[1] + 28

            Row(c2, "Panic Unload Key", nil, "bind_panic", nil, y2)

            Btn(c2, "Panic Unload Now", C_RED, function()

                if Garrylose.PanicUnload then Garrylose.PanicUnload() end

            end, y2)

            Btn(c2, "Reset to Default", C_RED, function()

                Garrylose.Config.aimbot_enabled=true; Garrylose.Config.aimbot_fov=90

                Garrylose.Config.aimbot_silent=true;  Garrylose.Config.aimbot_rcs=true

                Garrylose.Config.esp_enabled=true;    Garrylose.Config.bhop_enabled=true

                Garrylose.Config.hitsound_enabled=true; Garrylose.Config.hitmarker_enabled=true

                Garrylose.Config.aspect_ratio_enabled=false

                notification.AddLegacy("Garrylose: reset to defaults!", NOTIFY_HINT, 3)

                LoadTabContent(4)

            end, y2)

        elseif tabId == 5 then

            Section(c1, "PROFILES", y1)

            local cfgIn = vgui.Create("DTextEntry", c1)

            cfgIn:SetPos(14, y1[1]); cfgIn:SetSize(c1:GetWide() - 28, 24)

            cfgIn:SetValue("default"); cfgIn:SetTextColor(TEXT)

            cfgIn.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                self:DrawTextEntryText(TEXT, ACCENT, TEXT)

            end

            y1[1] = y1[1] + 30

            local cfgList = vgui.Create("DListView", c1)

            cfgList:SetPos(14, y1[1]); cfgList:SetSize(c1:GetWide() - 28, 280)

            cfgList:SetMultiSelect(false)

            local col_ = cfgList:AddColumn("Config Files")

            col_.Header:SetTextColor(TEXT_MUT)

            cfgList.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)

            end

            local function RefreshList()

                cfgList:Clear()

                local files = file.Find("garrylose_configs/*.json", "DATA")

                for _, fn in ipairs(files or {}) do

                    local ln = cfgList:AddLine(fn)

                    ln.Paint = function(self, lw, lh)

                        if self:IsSelected() then

                            draw.RoundedBox(2, 0, 0, lw, lh, ACCENT_DIM)

                            surface.SetDrawColor(ACCENT); surface.DrawOutlinedRect(0, 0, lw, lh)

                        elseif self:IsHovered() then

                            draw.RoundedBox(2, 0, 0, lw, lh, ITEM_BG)

                        end

                    end

                    for _, cell in pairs(ln.Columns) do cell:SetTextColor(TEXT) end

                end

            end

            cfgList.OnRowSelected = function(lst, index, pnl)
                local cfgName = pnl:GetValue(1)
                cfgIn:SetValue(string.Replace(cfgName, ".json", ""))
            end

            RefreshList(); y1[1] = y1[1] + 288

            Section(c2, "ACTIONS", y2)

            Btn(c2, "Save Config",   ACCENT,   function() Garrylose.SaveConfig(cfgIn:GetValue()); RefreshList() end, y2)

            Btn(c2, "Load Config",   C_GREEN,  function()

                local sel = cfgList:GetSelectedLine()

                Garrylose.LoadConfig(sel and cfgList:GetLine(sel):GetValue(1) or cfgIn:GetValue())

            end, y2)

            Btn(c2, "Delete Config", C_RED,    function()

                local sel = cfgList:GetSelectedLine()

                if sel then Garrylose.DeleteConfig(cfgList:GetLine(sel):GetValue(1)); RefreshList() end

            end, y2)

        elseif tabId == 6 then

            EnsureDefaultScripts()

            Section(c1, "SAVED SCRIPTS (ПКМ: Меню)", y1)

            local scriptList = vgui.Create("DListView", c1)

            scriptList:SetPos(14, y1[1]); scriptList:SetSize(c1:GetWide() - 28, 160)

            scriptList:SetMultiSelect(false)

            local col1 = scriptList:AddColumn("Script Name")

            local col2 = scriptList:AddColumn("Auto-Load")

            col1:SetFixedWidth(145)

            col2:SetFixedWidth(65)

            col1.Header:SetTextColor(TEXT_MUT)

            col2.Header:SetTextColor(TEXT_MUT)

            scriptList.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)

            end

            local function RefreshScriptList()

                scriptList:Clear()

                EnsureDefaultScripts()

                local files = file.Find("garrylose_scripts/*.txt", "DATA") or {}

                for _, fn in ipairs(files) do

                    local cleanName = string.StripExtension(fn)

                    local isAuto = Garrylose.IsScriptAutoLoad(fn)

                    local autoText = isAuto and "[ON]" or "[OFF]"

                    local ln = scriptList:AddLine(cleanName, autoText)

                    ln.FileName = fn

                    ln.IsAuto = isAuto

                    ln.Paint = function(self, lw, lh)

                        if self:IsSelected() then

                            draw.RoundedBox(2, 0, 0, lw, lh, ACCENT_DIM)

                            surface.SetDrawColor(ACCENT); surface.DrawOutlinedRect(0, 0, lw, lh)

                        elseif self:IsHovered() then

                            draw.RoundedBox(2, 0, 0, lw, lh, ITEM_BG)

                        end

                    end

                    if ln.Columns[1] then ln.Columns[1]:SetTextColor(TEXT) end

                    if ln.Columns[2] then ln.Columns[2]:SetTextColor(isAuto and C_GREEN or TEXT_MUT) end

                end

            end

            RefreshScriptList()

            y1[1] = y1[1] + 168

            -- ПКМ Context Menu Handler

            scriptList.OnRowRightClick = function(panel, rowIndex, row)

                local fn = row.FileName or (row:GetValue(1) .. ".txt")

                local cleanName = row:GetValue(1)

                local isAuto = Garrylose.IsScriptAutoLoad(fn)

                local menu = DermaMenu()

                if isAuto then

                    menu:AddOption("Убрать из авто-загрузки", function()

                        Garrylose.SetScriptAutoLoad(fn, false)

                        notification.AddLegacy("Garrylose: '" .. cleanName .. "' убран из авто-загрузки", NOTIFY_GENERIC, 3)

                        RefreshScriptList()

                    end):SetIcon("icon16/cross.png")

                else

                    menu:AddOption("Добавить в авто-загрузку", function()

                        Garrylose.SetScriptAutoLoad(fn, true)

                        notification.AddLegacy("Garrylose: '" .. cleanName .. "' добавлен в авто-загрузку", NOTIFY_HINT, 3)

                        RefreshScriptList()

                    end):SetIcon("icon16/tick.png")

                end

                menu:AddSpacer()

                menu:AddOption("Запустить скрипт (Execute)", function()

                    local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                    if code and code ~= "" then

                        RunString(code, "Garrylose_" .. fn)

                        notification.AddLegacy("[Garrylose] Executed: " .. cleanName, NOTIFY_GENERIC, 3)

                        LoadTabContent(6)

                    end

                end):SetIcon("icon16/control_play.png")

                menu:AddOption("Загрузить в редактор", function()

                    local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                    if code then

                        if editor and IsValid(editor) then editor:SetValue(code) end

                        if nameIn and IsValid(nameIn) then nameIn:SetValue(cleanName) end

                    end

                end):SetIcon("icon16/page_edit.png")

                menu:AddSpacer()

                menu:AddOption("Удалить файл", function()

                    file.Delete("garrylose_scripts/" .. fn)

                    Garrylose.SetScriptAutoLoad(fn, false)

                    notification.AddLegacy("[Garrylose] Deleted: " .. cleanName, NOTIFY_CLEANUP, 3)

                    RefreshScriptList()

                end):SetIcon("icon16/delete.png")

                menu:Open()

            end

            Btn(c1, "Run Selected", C_GREEN, function()

                local sel = scriptList:GetSelectedLine()

                if sel then

                    local ln = scriptList:GetLine(sel)

                    local fn = ln.FileName or (ln:GetValue(1) .. ".txt")

                    local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                    if code and code ~= "" then

                        RunString(code, "Garrylose_" .. fn)

                        notification.AddLegacy("[Garrylose] Executed " .. ln:GetValue(1), NOTIFY_GENERIC, 3)

                        LoadTabContent(6)

                    end

                end

            end, y1)

            Btn(c1, "Delete Script File", C_RED, function()

                local sel = scriptList:GetSelectedLine()

                if sel then

                    local ln = scriptList:GetLine(sel)

                    local fn = ln.FileName or (ln:GetValue(1) .. ".txt")

                    file.Delete("garrylose_scripts/" .. fn)

                    Garrylose.SetScriptAutoLoad(fn, false)

                    notification.AddLegacy("[Garrylose] Deleted " .. ln:GetValue(1), NOTIFY_CLEANUP, 3)

                    RefreshScriptList()

                end

            end, y1)

            Section(c1, "ACTIVE PLUGINS", y1)

            local hasPlugins = false

            for id, plugin in pairs(Garrylose.Plugins) do

                hasPlugins = true

                Row(c1, plugin.name or id, nil, nil, nil, function()

                    plugin.enabled = not plugin.enabled

                end, y1)

            end

            if not hasPlugins then

                local emptyLbl = vgui.Create("DPanel", c1)

                emptyLbl:SetPos(14, y1[1]); emptyLbl:SetSize(c1:GetWide() - 28, 22)

                emptyLbl.Paint = function(self, w, h)

                    draw.SimpleText("No active custom plugins", "DefaultFixed", 0, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                end

                MakeDraggable(emptyLbl)

                y1[1] = y1[1] + 26

            end

            Btn(c1, "Unload All Plugins", C_RED, function()

                Garrylose.Plugins = {}

                notification.AddLegacy("[Garrylose] All custom plugins unloaded!", NOTIFY_CLEANUP, 3)

                LoadTabContent(6)

            end, y1)

            Section(c2, "SCRIPT NAME", y2)

            local nameIn = vgui.Create("DTextEntry", c2)

            nameIn:SetPos(14, y2[1]); nameIn:SetSize(c2:GetWide() - 28, 22)

            nameIn:SetValue("my_script"); nameIn:SetTextColor(TEXT)

            nameIn.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                self:DrawTextEntryText(TEXT, ACCENT, TEXT)

            end

            y2[1] = y2[1] + 28

            Section(c2, "LUA CODE EDITOR", y2)

            local editor = vgui.Create("DTextEntry", c2)

            editor:SetPos(14, y2[1]); editor:SetSize(c2:GetWide() - 28, 175)

            editor:SetMultiline(true); editor:SetTextColor(TEXT)

            editor:SetValue(defaultRainbowCode)

            editor.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                self:DrawTextEntryText(TEXT, ACCENT, TEXT)

            end

            y2[1] = y2[1] + 182

            -- Left click row loads into editor

            scriptList.OnRowSelected = function(panel, rowIndex, row)

                local fn = row.FileName or (row:GetValue(1) .. ".txt")

                local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                if code then

                    editor:SetValue(code)

                    nameIn:SetValue(row:GetValue(1))

                end

            end

            Btn(c2, "Execute (Run Now)", ACCENT, function()

                local code = editor:GetValue()

                if code ~= "" then

                    RunString(code, "GarryloseIDE")

                    notification.AddLegacy("[Garrylose] Script executed!", NOTIFY_GENERIC, 3)

                    LoadTabContent(6)

                end

            end, y2)

            Btn(c2, "Save Script to List", C_GREEN, function()

                file.CreateDir("garrylose_scripts")

                local rawName = string.Trim(nameIn:GetValue())

                if rawName == "" then rawName = "script_" .. os.time() end

                rawName = string.StripExtension(rawName)

                local fileName = rawName .. ".txt"

                file.Write("garrylose_scripts/" .. fileName, editor:GetValue())

                notification.AddLegacy("[Garrylose] Saved: " .. rawName, NOTIFY_HINT, 3)

                RefreshScriptList()

            end, y2)

        elseif tabId == 7 then

            Section(c1, "UI THEME & STYLE", y1)

            Combo(c1, "Color Mode", {

                { label = "Dark Theme (Default)", data = 1 },

                { label = "Light Theme (White)",   data = 2 },

            }, "ui_style", function() Garrylose.OpenMenu() end, y1)

            Combo(c1, "Accent Preset", {

                { label = "Cyan Blue (Neverlose)", data = 1 },

                { label = "Crimson Red",           data = 2 },

                { label = "Purple Violet",         data = 3 },

                { label = "Emerald Green",         data = 4 },

                { label = "Gold Orange",           data = 5 },

                { label = "Hot Pink",              data = 6 },

            }, "menu_theme", function() Garrylose.OpenMenu() end, y1)

            -- 1-Click Quick Theme Accent Chips

            local themeChips = {

                { id = 1, col = Color(0, 180, 255) },   -- Cyan

                { id = 2, col = Color(245, 55, 75) },   -- Red

                { id = 3, col = Color(175, 75, 255) },  -- Purple

                { id = 4, col = Color(40, 215, 120) },  -- Green

                { id = 5, col = Color(255, 165, 0) },   -- Orange

                { id = 6, col = Color(255, 60, 160) },  -- Pink

            }

            local chipPnl = vgui.Create("DPanel", c1)

            chipPnl:SetPos(14, y1[1]); chipPnl:SetSize(c1:GetWide() - 28, 28)

            chipPnl.Paint = function() end

            local cW = math.floor((c1:GetWide() - 28 - (5 * 6)) / 6)

            for idx, tc in ipairs(themeChips) do

                local tb = vgui.Create("DButton", chipPnl)

                tb:SetPos((idx - 1) * (cW + 6), 0)

                tb:SetSize(cW, 28)

                tb:SetText("")

                tb.Paint = function(self, w, h)

                    local isCur = (Garrylose.Config.menu_theme == tc.id)

                    draw.RoundedBox(4, 0, 0, w, h, tc.col)

                    surface.SetDrawColor(isCur and color_white or (self:IsHovered() and color_white or BORDER))

                    surface.DrawOutlinedRect(0, 0, w, h)

                    if isCur then

                        draw.RoundedBox(2, 4, h - 4, w - 8, 2, color_white)

                    end

                end

                tb.DoClick = function()

                    Garrylose.Config.menu_theme = tc.id

                    timer.Simple(0, function() Garrylose.OpenMenu() end)

                end

            end

            y1[1] = y1[1] + 36

            Section(c2, "SYSTEM STATUS", y2)

            local infoPnl2 = vgui.Create("DPanel", c2)

            infoPnl2:SetPos(14, y2[1]); infoPnl2:SetSize(c2:GetWide() - 28, 140)

            infoPnl2.Paint = function(self, w, h)

                draw.RoundedBox(4, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)

                draw.SimpleText("GARRYLOSE SYSTEM", "DermaDefaultBold", 12, 14, ACCENT,   TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Build: v1.0.0 Release", "DefaultFixed", 12, 36, TEXT,     TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Theme: " .. Garrylose.GetActiveTheme().name, "DefaultFixed", 12, 56, TEXT,     TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                local ac=Garrylose.GetActiveTheme().accent

                draw.SimpleText(string.format("Accent RGB: [%d, %d, %d]", ac.r, ac.g, ac.b), "DefaultFixed", 12, 76, ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Window Dragging: Global (Any Blank Area)", "DefaultFixed", 12, 96, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Config Auto-Save: Enabled", "DefaultFixed", 12, 116, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            end

            MakeDraggable(infoPnl2)

            y2[1] = y2[1] + 148

        end

        -- Fit inner panel height

        local maxH = math.max(y1[1], y2[1]) + 20

        inner:SetSize(CON_W, math.max(maxH, FH - HEAD_H))

        c1:SetSize(c1:GetWide(), maxH)

        c2:SetSize(c2:GetWide(), maxH)

        scroll:GetCanvas():SetTall(maxH)

        scroll:InvalidateLayout(true)

    end

    searchEntry.OnValueChange = function(self, val)

        if val and string.Trim(val) ~= "" then

            activeTab = "SEARCH"

            LoadSearchContent(val)

            header:InvalidateLayout(true)

        else

            activeTab = Garrylose.CurrentMenuTab or 1

            LoadTabContent(activeTab)

            header:InvalidateLayout(true)

        end

    end

    LoadTabContent(activeTab)

end

-- Console Commands & Aliases

concommand.Add("garrylose_menu", Garrylose.ToggleMenu)

concommand.Add("garrylose", Garrylose.ToggleMenu)

concommand.Add("hvh_menu", Garrylose.ToggleMenu)

concommand.Add("menu", Garrylose.ToggleMenu)

concommand.Add("+garrylose_menu", Garrylose.OpenMenu)

concommand.Add("-garrylose_menu", function()

    if IsValid(Garrylose.MenuFrame) then

        Garrylose.MenuFrame:Remove()

        Garrylose.MenuFrame = nil

    end

end)

-- Startup / Join notification informing player how to open menu

local function Garrylose_ShowWelcome()

    chat.AddText(Color(0, 180, 255), "[GARRYLOSE] ", Color(240, 245, 255), "Addon v1.0.0 loaded! Press ", Color(0, 220, 255), "[INSERT]", Color(240, 245, 255), " or type ", Color(0, 220, 255), "!menu", Color(240, 245, 255), " / ", Color(0, 220, 255), "garrylose_menu", Color(240, 245, 255), " in console to open menu.")

end

hook.Add("InitPostEntity", "Garrylose_InitPostEntityNotify", function()

    timer.Simple(2, Garrylose_ShowWelcome)

end)

timer.Simple(1, Garrylose_ShowWelcome)

-- Spinbot Model Synchronization

hook.Add("UpdateAnimation", "Garrylose_Spinbot_SyncAnimation", function(ply, velocity, maxSeqGroundSpeed)
    if ply ~= LocalPlayer() then return end
    if not Garrylose.Config.antiaim_enabled or not Garrylose.Config.thirdperson_enabled then return end

    -- ONLY synchronize lower body for Spinbot (antiaim_yaw == 2) in 3rd person.
    if Garrylose.Config.antiaim_yaw ~= 2 then return end

    if not Garrylose.LastSentFakeAngles then return end

    local fakeYaw = Garrylose.LastSentFakeAngles.y

    local fakePitch = Garrylose.LastSentFakeAngles.p

    -- Align entire lower body and render angles with spinbot

    ply:SetRenderAngles(Angle(0, fakeYaw, 0))

    -- Zero out relative yaw difference so legs and torso rotate smoothly together in spinbot

    ply:SetPoseParameter("head_yaw", 0)

    ply:SetPoseParameter("body_yaw", 0)

    ply:SetPoseParameter("aim_yaw", 0)

    ply:SetPoseParameter("head_pitch", fakePitch)

    ply:SetPoseParameter("aim_pitch", fakePitch)

end)

hook.Add("PrePlayerDraw", "Garrylose_Spinbot_PrePlayerDraw", function(ply)
    if ply == LocalPlayer() and Garrylose.Config.thirdperson_enabled and Garrylose.Config.antiaim_enabled and Garrylose.Config.antiaim_yaw == 2 and Garrylose.LastSentFakeAngles then
        ply:SetRenderAngles(Angle(0, Garrylose.LastSentFakeAngles.y, 0))
    end
end)

-- WORLD VISUALS, FULLBRIGHT & NIGHT MODE ENGINE

-- Real-time 3D World & Prop Color Modulation for Instant Dramatic Night Effect

local function ApplyNightWorldModulation()

    if Garrylose.Config.nightmode_enabled then

        local darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50

        local nightCol = Garrylose.Config.col_nightmode or Color(20, 30, 60, 255)

        local factor = math.Clamp(1.0 - (darkness * 0.85), 0.04, 1.0)

        local r = ((nightCol.r / 255) * factor) * 0.7

        local g = ((nightCol.g / 255) * factor) * 0.7

        local b = ((nightCol.b / 255) * factor) * 0.95

        render.SetColorModulation(r, g, b)

        render.SetAmbientLight(r * 0.5, g * 0.5, b * 0.7)

    end

    if Garrylose.Config.fullbright_enabled then

        render.SetLightingMode(1)

    end

end

local function ResetNightWorldModulation()

    render.SetColorModulation(1, 1, 1)

    render.SetAmbientLight(1, 1, 1)

    render.SetLightingMode(0)

end

hook.Add("PreDrawOpaqueRenderables", "Garrylose_World_PreOpaque", function()

    ApplyNightWorldModulation()

end)

hook.Add("PostDrawOpaqueRenderables", "Garrylose_World_PostOpaque", function()

    ResetNightWorldModulation()

end)

hook.Add("PreDrawTranslucentRenderables", "Garrylose_World_PreTranslucent", function()

    ApplyNightWorldModulation()

end)

-- PROP / WORLD TRANSPARENCY & CUSTOM SKYBOX ENGINE

local modifiedTransparentProps = {}

function Garrylose.ResetAllTransparentProps()

    for ent, _ in pairs(modifiedTransparentProps) do

        if IsValid(ent) then

            ent:SetRenderMode(RENDERMODE_NORMAL)

            ent:SetColor(Color(255, 255, 255, 255))

        end

    end

    modifiedTransparentProps = {}

end

local lastPropTransState = false

local lastPropAlphaVal = 110

local nextPropScanTime = 0

hook.Add("Think", "Garrylose_PropTransparency_Engine", function()

    local curT = CurTime()

    local isEnabled = Garrylose.Config.prop_transparency_enabled

    local targetAlpha = math.Clamp(tonumber(Garrylose.Config.prop_alpha) or 110, 10, 255)

    if isEnabled then

        if curT >= nextPropScanTime or (lastPropAlphaVal ~= targetAlpha) then

            nextPropScanTime = curT + 0.15

            lastPropAlphaVal = targetAlpha

            local props = ents.FindByClass("prop_physics*")

            table.Add(props, ents.FindByClass("prop_dynamic*"))

            table.Add(props, ents.FindByClass("prop_ragdoll*"))

            for _, ent in ipairs(props) do

                if IsValid(ent) then

                    local curCol = ent:GetColor()

                    if ent:GetRenderMode() ~= RENDERMODE_TRANSCOLOR or curCol.a ~= targetAlpha then

                        ent:SetRenderMode(RENDERMODE_TRANSCOLOR)

                        ent:SetColor(Color(255, 255, 255, targetAlpha))

                        modifiedTransparentProps[ent] = true

                    end

                end

            end

        end

    elseif lastPropTransState then

        Garrylose.ResetAllTransparentProps()

    end

    lastPropTransState = isEnabled

end)

hook.Add("PostDraw2DSkyBox", "Garrylose_CustomSkybox_Render", function()

    if not Garrylose.Config.custom_skybox_enabled then return end

    local skyType = tonumber(Garrylose.Config.custom_skybox_type) or 1

    local skyColors = {

        [1] = Color(10, 12, 30),   -- Deep Space / Galaxy

        [2] = Color(5, 5, 15),     -- Midnight Starry

        [3] = Color(70, 20, 30),   -- Sunset Crimson

        [4] = Color(40, 10, 65),   -- Cyberpunk Violet

        [5] = Color(0, 0, 0),      -- Void Black

    }

    local c = skyColors[skyType] or Color(10, 12, 30)

    render.Clear(c.r, c.g, c.b, 255, true, true)

end)

hook.Add("PostDrawTranslucentRenderables", "Garrylose_World_PostTranslucent", function()

    ResetNightWorldModulation()

end)

hook.Add("PreDrawHUD", "Garrylose_World_EnsureHUDReset", function()

    ResetNightWorldModulation()

end)

hook.Add("RenderScreenspaceEffects", "Garrylose_WorldModulation_Effects", function()

    if not Garrylose.Config.nightmode_enabled and not Garrylose.Config.fullbright_enabled then return end

    local darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50

    local isNight = Garrylose.Config.nightmode_enabled

    local isFullbright = Garrylose.Config.fullbright_enabled

    local col = Garrylose.Config.col_nightmode or Color(20, 30, 55, 255)

    local cr = (col.r / 255)

    local cg = (col.g / 255)

    local cb = (col.b / 255)

    local addr = isNight and (cr * darkness * 0.12) or 0

    local addg = isNight and (cg * darkness * 0.12) or 0

    local addb = isNight and (cb * darkness * 0.22) or 0

    local brightness = 0

    local contrast = 1.0

    local colorScale = 1.0

    if isNight then

        brightness = brightness - (darkness * 0.55)

        contrast = contrast + (darkness * 0.40)

        colorScale = math.Clamp(1.0 - (darkness * 0.45), 0.1, 1.0)

    end

    if isFullbright and not isNight then

        brightness = brightness + 0.15

        contrast = contrast + 0.10

        colorScale = colorScale + 0.05

    end

    local colorModify = {

        ["$pp_colour_addr"] = addr,

        ["$pp_colour_addg"] = addg,

        ["$pp_colour_addb"] = addb,

        ["$pp_colour_brightness"] = brightness,

        ["$pp_colour_contrast"] = contrast,

        ["$pp_colour_colour"] = colorScale,

        ["$pp_colour_mulr"] = 0,

        ["$pp_colour_mulg"] = 0,

        ["$pp_colour_mulb"] = 0

    }

    DrawColorModify(colorModify)

end)

-- Custom Fog Modulation

hook.Add("SetupWorldFog", "Garrylose_WorldFog_Modulation", function()

    if Garrylose.Config.fog_enabled then

        local fogCol = Garrylose.Config.col_fog or Color(20, 25, 40)

        local density = tonumber(Garrylose.Config.fog_density) or 2200

        render.FogMode(MATERIAL_FOG_LINEAR)

        render.FogStart(100)

        render.FogEnd(density)

        render.FogMaxDensity(0.9)

        render.FogColor(fogCol.r, fogCol.g, fogCol.b)

        return true

    end

end)

hook.Add("SetupSkyboxFog", "Garrylose_SkyboxFog_Modulation", function(scale)

    if Garrylose.Config.fog_enabled then

        local fogCol = Garrylose.Config.col_fog or Color(20, 25, 40)

        local density = (tonumber(Garrylose.Config.fog_density) or 2200) * scale

        render.FogMode(MATERIAL_FOG_LINEAR)

        render.FogStart(50 * scale)

        render.FogEnd(density)

        render.FogMaxDensity(0.9)

        render.FogColor(fogCol.r, fogCol.g, fogCol.b)

        return true

    end

end)

-- Skybox Modulation

hook.Add("PostDraw2DSkyBox", "Garrylose_Skybox_Modulation", function()

    if Garrylose.Config.skybox_mod_enabled then

        local skyCol = Garrylose.Config.col_skybox or Color(12, 16, 28, 255)

        render.Clear(skyCol.r, skyCol.g, skyCol.b, 255, true, false)

    elseif Garrylose.Config.nightmode_enabled then

        local darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50

        local nightSky = Garrylose.Config.col_nightmode or Color(10, 15, 30, 255)

        local factor = math.Clamp(1.0 - (darkness * 0.85), 0.05, 1.0)

        render.Clear(nightSky.r * factor, nightSky.g * factor, nightSky.b * factor, 255, true, false)

    end

end)

-- LASER BULLET TRACERS, 3D IMPACTS & DESYNC GHOST ENGINE

hook.Add("PostDrawTranslucentRenderables", "Garrylose_TracersAndImpacts_Render", function(bDepth, bSkybox)

    if bSkybox then return end

    local curT = CurTime()

    -- 1. Laser Bullet Tracers (Multi-Line Glow Beams - 100% Reliable Render)

    if Garrylose.Config.bullet_tracers_enabled and Garrylose.BulletTracers then

        local c = Garrylose.Config.col_bullet_tracers or Color(0, 220, 255, 255)

        for i = #Garrylose.BulletTracers, 1, -1 do

            local trItem = Garrylose.BulletTracers[i]

            local age = curT - trItem.time

            if age > trItem.duration then

                table.remove(Garrylose.BulletTracers, i)

            else

                local alpha = math.Clamp(1 - (age / trItem.duration), 0, 1)

                local beamCol = Color(c.r, c.g, c.b, math.floor(255 * alpha))

                local coreCol = Color(255, 255, 255, math.floor(230 * alpha))

                -- Multi-pass volumetric laser line

                render.DrawLine(trItem.startPos, trItem.hitPos, beamCol, true)

                render.DrawLine(trItem.startPos + Vector(0, 0, 0.6), trItem.hitPos + Vector(0, 0, 0.6), coreCol, true)

                render.DrawLine(trItem.startPos - Vector(0, 0, 0.6), trItem.hitPos - Vector(0, 0, 0.6), beamCol, true)

                render.DrawLine(trItem.startPos + Vector(0.6, 0, 0), trItem.hitPos + Vector(0.6, 0, 0), beamCol, true)

                render.DrawLine(trItem.startPos - Vector(0.6, 0, 0), trItem.hitPos - Vector(0.6, 0, 0), beamCol, true)

                -- End impact spark box

                render.DrawWireframeBox(trItem.hitPos, Angle(0, 0, 0), Vector(-1.5, -1.5, -1.5), Vector(1.5, 1.5, 1.5), beamCol, true)

            end

        end

    end

    -- 4. Grenade Warning & Blast Radius Indicator Engine

    if Garrylose.Config.grenade_warning_enabled then

        local warnCol = Garrylose.Config.col_grenade_warning or Color(255, 50, 50, 220)

        local ply = LocalPlayer()

        local myPos = IsValid(ply) and ply:GetPos() or Vector(0,0,0)

        local explosives = {}

        for _, ent in ipairs(ents.FindByClass("npc_grenade_frag")) do table.insert(explosives, { ent = ent, rad = 280, name = "GRENADE" }) end

        for _, ent in ipairs(ents.FindByClass("grenade_hand")) do table.insert(explosives, { ent = ent, rad = 280, name = "GRENADE" }) end

        for _, ent in ipairs(ents.FindByClass("item_ammo_smg1_grenade")) do table.insert(explosives, { ent = ent, rad = 260, name = "SMG GRENADE" }) end

        for _, ent in ipairs(ents.FindByClass("item_ammo_ar2_altfire")) do table.insert(explosives, { ent = ent, rad = 260, name = "COMBINE BALL" }) end

        for _, ent in ipairs(ents.FindByClass("prop_combine_ball")) do table.insert(explosives, { ent = ent, rad = 260, name = "ENERGY BALL" }) end

        for _, ent in ipairs(ents.FindByClass("prop_physics*")) do

            if IsValid(ent) and string.find(string.lower(ent:GetModel() or ""), "oildrum001_explosive") then

                table.insert(explosives, { ent = ent, rad = 350, name = "EXPLOSIVE BARREL" })

            end

        end

        render.SetColorMaterial()

        for _, item in ipairs(explosives) do

            local ent = item.ent

            if IsValid(ent) then

                local ePos = ent:GetPos()

                local dist = myPos:Distance(ePos)

                if dist < 2000 then

                    local pulse = (math.sin(CurTime() * 8) + 1) * 0.5

                    local c = Color(warnCol.r, warnCol.g, warnCol.b, math.floor(180 + pulse * 75))

                    -- 3D Wireframe Warning Box around explosive

                    render.DrawWireframeBox(ePos, Angle(0,0,0), Vector(-6,-6,-6), Vector(6,6,6), c, true)

                    -- 3D Ground Blast Radius Circle

                    local trFloor = util.TraceLine({

                        start = ePos,

                        endpos = ePos - Vector(0, 0, 500),

                        filter = ent,

                        mask = MASK_SOLID_BRUSHONLY

                    })

                    local groundPos = trFloor.Hit and trFloor.HitPos or ePos

                    local rad = item.rad

                    local segs = 32

                    local step = (math.pi * 2) / segs

                    local prevPt = nil

                    for i = 0, segs do

                        local ang = i * step

                        local pt = groundPos + Vector(math.cos(ang) * rad, math.sin(ang) * rad, 1)

                        if prevPt then

                            render.DrawLine(prevPt, pt, c, true)

                            render.DrawLine(prevPt + Vector(0,0,1), pt + Vector(0,0,1), Color(255, 255, 255, 120), true)

                        end

                        prevPt = pt

                    end

                end

            end

        end

    end

    -- 2. 3D Bullet Impacts (Dual Wireframe Hit Boxes)

    if Garrylose.Config.bullet_impacts_enabled and Garrylose.BulletImpacts then

        local c = Garrylose.Config.col_bullet_impacts or Color(0, 180, 255, 255)

        for i = #Garrylose.BulletImpacts, 1, -1 do

            local imp = Garrylose.BulletImpacts[i]

            local age = curT - imp.time

            if age > imp.duration then

                table.remove(Garrylose.BulletImpacts, i)

            else

                local alpha = math.Clamp(1 - (age / imp.duration), 0, 1)

                local impCol = Color(c.r, c.g, c.b, math.floor(255 * alpha))

                local boxVec = Vector(2.2, 2.2, 2.2)

                render.DrawWireframeBox(imp.pos, Angle(0, 0, 0), -boxVec, boxVec, impCol, true)

                render.DrawWireframeBox(imp.pos, Angle(0, 0, 0), -boxVec * 0.5, boxVec * 0.5, Color(255, 255, 255, math.floor(180 * alpha)), true)

            end

        end

    end

end)

-- Glow ESP (Native Halo Engine)

-- DESYNC GHOST CHAMS ENGINE (Zero-Lag Clientside Real-Angle Model in Thirdperson)

Garrylose.GhostEntity = Garrylose.GhostEntity or nil

local ghostMaterialWhite = Material("models/debug/debugwhite")

local ghostMaterialWireframe = Material("models/wireframe")

local function GetGhostEntity(ply)

    if not IsValid(ply) then return nil end

    local mdl = ply:GetModel()

    if not mdl or mdl == "" then return nil end

    if not IsValid(Garrylose.GhostEntity) then

        Garrylose.GhostEntity = ClientsideModel(mdl, RENDERGROUP_TRANSLUCENT)

        if IsValid(Garrylose.GhostEntity) then

            Garrylose.GhostEntity:SetNoDraw(true)

        end

    elseif Garrylose.GhostEntity:GetModel() ~= mdl then

        Garrylose.GhostEntity:SetModel(mdl)

    end

    return Garrylose.GhostEntity

end

hook.Add("PostDrawTranslucentRenderables", "Garrylose_DesyncGhost_Render", function(bDepth, bSkybox)

    if bSkybox then return end

    if not Garrylose.Config.desync_ghost_enabled or not Garrylose.Config.thirdperson_enabled or not Garrylose.Config.antiaim_enabled then

        if IsValid(Garrylose.GhostEntity) then

            Garrylose.GhostEntity:SetNoDraw(true)

        end

        return

    end

    local ply = LocalPlayer()

    if not IsValid(ply) or not ply:Alive() then return end

    local ghost = GetGhostEntity(ply)

    if not IsValid(ghost) then return end

    local realAng = Garrylose.RealViewAngles or ply:EyeAngles()

    local ghostCol = Garrylose.Config.col_desync_ghost or Color(0, 230, 255, 140)

    local matMode = tonumber(Garrylose.Config.desync_ghost_mat) or 1

    -- Position & Animation Synchronization

    ghost:SetPos(ply:GetPos())

    ghost:SetAngles(Angle(0, realAng.y, 0))

    ghost:SetSequence(ply:GetSequence())

    ghost:SetCycle(ply:GetCycle())

    ghost:SetPoseParameter("move_x", ply:GetPoseParameter("move_x") or 0)

    ghost:SetPoseParameter("move_y", ply:GetPoseParameter("move_y") or 0)

    ghost:SetPoseParameter("head_pitch", math.Clamp(realAng.p, -89, 89))

    -- Render Translucent Ghost Chams

    render.SuppressEngineLighting(true)

    render.SetColorModulation(ghostCol.r / 255, ghostCol.g / 255, ghostCol.b / 255)

    render.SetBlend((ghostCol.a or 140) / 255)

    if matMode == 2 then
        render.MaterialOverride(ghostMaterialWireframe)
    else
        render.MaterialOverride(ghostMaterialWhite)
    end
    
    local ok, err = pcall(function() ghost:DrawModel() end)

    render.MaterialOverride(nil)
    render.SetBlend(1)
    render.SetColorModulation(1, 1, 1)
    render.SuppressEngineLighting(false)

end)

hook.Add("ShutDown", "Garrylose_Ghost_Cleanup", function()

    if IsValid(Garrylose.GhostEntity) then

        Garrylose.GhostEntity:Remove()

        Garrylose.GhostEntity = nil

    end

end)

hook.Add("PreDrawHalos", "Garrylose_Glow_ESP", function()

    if not Garrylose.Config.glow_esp_enabled then return end

    local targets = {}

    local col = Garrylose.Config.col_glow_esp or Color(0, 210, 255, 255)

    for _, ent in ipairs(Garrylose.CachedTargets or {}) do

        if IsValid(ent) and ent:Health() > 0 and ent ~= LocalPlayer() then

            table.insert(targets, ent)

        end

    end

    if #targets > 0 then

        halo.Add(targets, col, 2, 2, 2, true, true)

    end

end)

-- HvH Killsay Engine (Universal Chat Command Dispatch + Local SP Chat Output)

local killsayPhrases = {

    "1 1 1 >> garrylose.cc #1 gmod hvh",

    "missed shot due to spread? never with garrylose.cc",

    "bapped by garrylose.cc neverlose edition",

    "buy garrylose.cc to stop resolving air",

    "get good, get garrylose.cc",

    "owned by garrylose.cc subtick exploit"

}

local lastKillsayTime = 0

Garrylose.TriggerKillsay = function()

    if not Garrylose.Config.killsay_enabled then return end

    if (CurTime() - lastKillsayTime) < 0.6 then return end -- Cooldown prevents multi-pellet duplicate spam

    lastKillsayTime = CurTime()

    local msg = killsayPhrases[math.random(#killsayPhrases)]

    RunConsoleCommand("say", msg)

    chat.AddText(Color(0, 180, 255), LocalPlayer():Nick() .. ": ", Color(255, 255, 255), msg)

end

hook.Add("OnNPCKilled", "Garrylose_Killsay_NPC", function(npc, attacker, inflictor)

    if attacker == LocalPlayer() or inflictor == LocalPlayer() then

        Garrylose.TriggerKillsay()

    end

end)

-- 3D Auto-Peek Ring & Crosshair Marker

hook.Add("PostDrawTranslucentRenderables", "Garrylose_AutoPeek_RenderVisualizer", function(bDepth, bSkybox)

    if bSkybox then return end

    if not Garrylose.Config.autopeek_enabled or not Garrylose.AutoPeekPos then return end

    local center = Garrylose.AutoPeekPos

    local isReturning = (Garrylose.AutoPeekState == "RETURNING")

    local baseCol = Garrylose.Config.col_autopeek or Color(0, 215, 255, 220)

    local ringCol = isReturning and Color(50, 255, 120, 240) or baseCol

    local radius = 18

    local segments = 24

    render.SetColorMaterial()

    local lastPos = center + Vector(radius, 0, 2)

    for i = 1, segments do

        local rad = math.rad((i / segments) * 360)

        local nextPos = center + Vector(math.cos(rad) * radius, math.sin(rad) * radius, 2)

        render.DrawLine(lastPos, nextPos, ringCol, true)

        lastPos = nextPos

    end

    render.DrawLine(center + Vector(-6, 0, 2), center + Vector(6, 0, 2), ringCol, true)

    render.DrawLine(center + Vector(0, -6, 2), center + Vector(0, 6, 2), ringCol, true)

end)

-- Slidewalk Animation System (Smooth 3rd person sliding / moonwalking)


-- Slidewalk Animation System (Smooth 3rd person sliding / moonwalking)
hook.Add("CalcMainActivity", "Garrylose_Slidewalk_Anim", function(ply, velocity)
    if ply == LocalPlayer() and Garrylose.Config.slidewalk_enabled then
        if ply:OnGround() and velocity:Length2D() > 10 then
            return ACT_HL2MP_IDLE, -1
        end
    end
end)

hook.Add("UpdateAnimation", "Garrylose_Slidewalk_UpdateAnim", function(ply, velocity, maxSeqGroundSpeed)
    if ply ~= LocalPlayer() then return end
    if Garrylose.Config.slidewalk_enabled and ply:OnGround() and velocity:Length2D() > 10 then
        ply:SetPoseParameter("move_x", 0)
        ply:SetPoseParameter("move_y", 0)
        ply:SetPoseParameter("move_yaw", 0)
        ply:SetPoseParameter("move_scale", 0)
        ply:SetPlaybackRate(0)
        return true
    end
end)


-- =========================================================================
-- GARRYLOSE MEGA EXPANSION (Imported & Enhanced Features)
-- =========================================================================

-- 1. Jump Circles
Garrylose.JumpCircles = Garrylose.JumpCircles or {}
local lastGround = true
hook.Add("Think", "Garrylose_JumpCircles_Logic", function()
    if not Garrylose.Config.jump_circles then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local onGround = ply:OnGround()
    if onGround and not lastGround then
        table.insert(Garrylose.JumpCircles, { pos = ply:GetPos(), time = CurTime(), radius = 0 })
    end
    lastGround = onGround
end)

hook.Add("PostDrawTranslucentRenderables", "Garrylose_JumpCircles_Draw", function(bDepth, bSky)
    if bSky or not Garrylose.Config.jump_circles then return end
    local c = Garrylose.Config.col_jump_circles or Color(0,255,255)
    for i = #Garrylose.JumpCircles, 1, -1 do
        local circ = Garrylose.JumpCircles[i]
        local age = CurTime() - circ.time
        if age > 1 then table.remove(Garrylose.JumpCircles, i) continue end
        circ.radius = circ.radius + FrameTime() * 150
        local alpha = math.Clamp(255 - (age * 255), 0, 255)
        
        render.SetColorMaterial()
        local segments = 32
        local lastPos = circ.pos + Vector(circ.radius, 0, 1)
        for j = 1, segments do
            local rad = math.rad((j / segments) * 360)
            local nextPos = circ.pos + Vector(math.cos(rad) * circ.radius, math.sin(rad) * circ.radius, 1)
            render.DrawLine(lastPos, nextPos, Color(c.r, c.g, c.b, alpha), true)
            lastPos = nextPos
        end
    end
end)

-- 2. World Modulation
local worldMats = {}
local worldModState = false
local lastWorldCol = Color(0,0,0)
hook.Add("Think", "Garrylose_WorldMod", function()
    local enabled = Garrylose.Config.worldmod
    local col = Garrylose.Config.col_worldmod or Color(50,50,50)
    
    if enabled then
        if not worldModState or col ~= lastWorldCol then
            if not worldModState then
                for _, matName in ipairs(game.GetWorld():GetMaterials()) do
                    local mat = Material(matName)
                    if mat and not mat:IsError() then
                        worldMats[matName] = mat:GetVector("$color") or Vector(1,1,1)
                    end
                end
            end
            local vec = Vector(col.r/255, col.g/255, col.b/255)
            for matName, _ in pairs(worldMats) do
                local mat = Material(matName)
                if mat then mat:SetVector("$color", vec) end
            end
            worldModState = true
            lastWorldCol = col
        end
    else
        if worldModState then
            for matName, origVec in pairs(worldMats) do
                local mat = Material(matName)
                if mat then mat:SetVector("$color", origVec) end
            end
            worldModState = false
            worldMats = {}
        end
    end
end)

-- 3. Custom Fog
hook.Add("SetupWorldFog", "Garrylose_Fog", function()
    if not Garrylose.Config.fog_enabled then return end
    render.FogMode(MATERIAL_FOG_LINEAR)
    render.FogStart(tonumber(Garrylose.Config.fog_start) or 0)
    render.FogEnd(tonumber(Garrylose.Config.fog_end) or 2000)
    render.FogMaxDensity(tonumber(Garrylose.Config.fog_density) or 1)
    local c = Garrylose.Config.col_fog or Color(100,100,100)
    render.FogColor(c.r, c.g, c.b)
    return true
end)
hook.Add("SetupSkyboxFog", "Garrylose_FogSky", function(scale)
    if not Garrylose.Config.fog_enabled then return end
    render.FogMode(MATERIAL_FOG_LINEAR)
    render.FogStart((tonumber(Garrylose.Config.fog_start) or 0) * scale)
    render.FogEnd((tonumber(Garrylose.Config.fog_end) or 2000) * scale)
    render.FogMaxDensity(tonumber(Garrylose.Config.fog_density) or 1)
    local c = Garrylose.Config.col_fog or Color(100,100,100)
    render.FogColor(c.r, c.g, c.b)
    return true
end)

-- 4. Chams (Players, Self, NPCs, Hands - Professional DepthRange & ModelMaterialOverride Engine)
local matWhite = Material("models/debug/debugwhite")

-- Global safety cleanup
hook.Add("PreDrawOpaqueRenderables", "Garrylose_SafetyReset_PreOpaque", function()
    render.MaterialOverride(nil)
    render.ModelMaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end)

-- Helper to draw an entity with DepthRange chams (zero map leaks, 100% visible through walls)
local function DrawDepthChamEntity(ent, col)
    if not IsValid(ent) or ent:IsDormant() then return end
    render.SuppressEngineLighting(true)
    render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
    render.SetBlend((col.a or 255) / 255)
    render.MaterialOverride(matWhite)

    render.DepthRange(0, 0.01)
    ent:DrawModel()
    local wep = ent.GetActiveWeapon and ent:GetActiveWeapon()
    if IsValid(wep) then wep:DrawModel() end
    render.DepthRange(0, 1)

    render.MaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end

local function IsValidNPCTarget(ent)
    if not IsValid(ent) then return false end
    if ent:IsDormant() or ent:GetNoDraw() then return false end
    
    local c = ent:GetClass()
    if string.find(c, "bullseye") or string.find(c, "maker") or string.find(c, "template") or string.find(c, "spotlight") or string.find(c, "weapon") then
        return false
    end
    
    if ent:IsNPC() or ent:IsNextBot() or string.StartWith(c, "npc_") or string.StartWith(c, "monster_") then
        return true
    end
    
    return false
end

-- NPC & Player XQZ Chams in PostDrawOpaqueRenderables
hook.Add("PostDrawOpaqueRenderables", "Garrylose_OpaqueChams", function(bDepth, bSkybox)
    if bSkybox or bDepth then return end
    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    -- 1. NPC & NextBot Chams
    if Garrylose.Config.chams_npc then
        local col = Garrylose.Config.col_chams_npc or Color(255, 255, 0, 255)
        for _, ent in ipairs(ents.GetAll()) do
            if IsValidNPCTarget(ent) then
                DrawDepthChamEntity(ent, col)
            end
        end
    end

    -- 2. Player Chams (Other Players through walls)
    if Garrylose.Config.chams_player then
        local col = Garrylose.Config.col_chams_player or Color(0, 255, 0, 255)
        for _, ply in ipairs(player.GetAll()) do
            if ply ~= lp and IsValid(ply) and ply:Alive() and not ply:IsDormant() then
                DrawDepthChamEntity(ply, col)
            end
        end
    end
end)

-- 3. Self Chams in Thirdperson & Freecam
hook.Add("PrePlayerDraw", "Garrylose_PlayerChams", function(ply, flags)
    if not IsValid(ply) then return end
    if ply == LocalPlayer() and Garrylose.Config.chams_self and (Garrylose.Config.thirdperson_enabled or Garrylose.Config.freecam_enabled) then
        local col = Garrylose.Config.col_chams_self or Color(255, 0, 0, 255)
        render.SuppressEngineLighting(true)
        render.MaterialOverride(matWhite)
        render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
        render.SetBlend((col.a or 255) / 255)
    end
end)

hook.Add("PostPlayerDraw", "Garrylose_PlayerChams_Post", function(ply, flags)
    if ply == LocalPlayer() then
        render.MaterialOverride(nil)
        render.SetColorModulation(1, 1, 1)
        render.SetBlend(1)
        render.SuppressEngineLighting(false)
    end
end)

-- 4. Hand Chams using ModelMaterialOverride (Never leaks to weapons or world)
hook.Add("PreDrawPlayerHands", "Garrylose_HandsChams_Apply", function(hands, vm, ply, wep)
    if Garrylose.Config.chams_hands then
        local col = Garrylose.Config.col_chams_hands or Color(0, 0, 255, 255)
        render.SuppressEngineLighting(true)
        render.ModelMaterialOverride(matWhite)
        render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
        render.SetBlend((col.a or 255) / 255)
    end
end)

hook.Add("PostDrawPlayerHands", "Garrylose_HandsChams_Reset", function(hands, vm, ply, wep)
    render.ModelMaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end)

hook.Add("PostDrawViewModel", "Garrylose_ViewModel_SafetyPost", function(vm, ply, wep)
    render.ModelMaterialOverride(nil)
    render.MaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end)

-- Function: Nothing
-- 1.
-- 2.
-- 4.
-- 125.
Garrylose.NothingKeyHeld = false
hook.Add("Think", "Garrylose_Nothing_Logic", function()
    local key = Garrylose.Config.bind_nothing
    if key and key > 0 and input.IsKeyDown(key) then
        if not Garrylose.NothingKeyHeld then
            Garrylose.NothingKeyHeld = true
            Garrylose.Config.nothing_enabled = not Garrylose.Config.nothing_enabled
            -- 1.
            -- 2.
            -- 4.
            -- 125.
        end
    else
        Garrylose.NothingKeyHeld = false
    end

    if Garrylose.Config.nothing_enabled then
        -- 1.
        -- 2.
        -- 4.
        -- 125.
    end
end)

-- 5. Chat Spammer
Garrylose.NextChatSpam = 0
hook.Add("Think", "Garrylose_ChatSpammer", function()
    if Garrylose.Config.chat_spam and CurTime() > Garrylose.NextChatSpam then
        local txt = Garrylose.Config.chat_spam_text or "Garrylose.cc owns me"
        if txt ~= "" then
            RunConsoleCommand("say", txt)
        end
        Garrylose.NextChatSpam = CurTime() + (tonumber(Garrylose.Config.chat_spam_delay) or 0.5)
    end
end)


-- 7. Player Movement Trails
local trail_pos = {}
hook.Add("Tick", "Garrylose_MovementTrail_Record", function()
    if not Garrylose.Config.esp_trail then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local max_len = math.min(tonumber(Garrylose.Config.esp_trail_len) or 150, 200)
    table.insert(trail_pos, 1, {pos = ply:GetPos(), time = CurTime()})

    while #trail_pos > max_len do
        table.remove(trail_pos)
    end
end)

local TRAIL_MAT = Material("trails/laser")
hook.Add("PostDrawTranslucentRenderables", "Garrylose_MovementTrail_Render", function(bDepth, bSky)
    if bSky or bDepth or not Garrylose.Config.esp_trail then return end
    
    local n = #trail_pos
    if n < 2 then return end

    local c = Garrylose.Config.col_esp_trail or Color(255, 255, 255)
    local sz = tonumber(Garrylose.Config.esp_trail_size) or 8
    local min_sz = sz * 0.2
    local lifetime = tonumber(Garrylose.Config.esp_trail_fade) or 3.0

    render.SetMaterial(TRAIL_MAT)
    
    for i = 1, n - 1 do
        local p1 = trail_pos[i]
        local p2 = trail_pos[i + 1]
        
        local age = CurTime() - p1.time
        local alpha = 255 - (age / lifetime) * 255
        
        if alpha <= 0 then continue end
        
        local frac = (n - i) / n
        local dyn_sz = min_sz + (sz - min_sz) * frac
        
        render.DrawBeam(p1.pos, p2.pos, dyn_sz, 0, 1, Color(c.r, c.g, c.b, alpha))
    end
end)
