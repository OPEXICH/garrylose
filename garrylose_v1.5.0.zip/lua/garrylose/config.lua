local IsValidFirearm = Garrylose.IsValidFirearm
local IsGrenadeWeapon = Garrylose.IsGrenadeWeapon

Garrylose.Config = Garrylose.Config or {}
Garrylose.Plugins = Garrylose.Plugins or {}
Garrylose.RealViewAngles = Garrylose.RealViewAngles or Angle(0, 0, 0)
Garrylose.CurrentTarget = nil
Garrylose.ShotState = false
Garrylose.ManualShotState = false

if not file.Exists("GLcfg", "DATA") then
    file.CreateDir("GLcfg")
end
if not file.Exists("GLsounds", "DATA") then
    file.CreateDir("GLsounds")
end

if file.Exists("garrylose_configs", "DATA") then
    local oldCfgs = file.Find("garrylose_configs/*.json", "DATA") or {}
    for _, fn in ipairs(oldCfgs) do
        if not file.Exists("GLcfg/" .. fn, "DATA") then
            local content = file.Read("garrylose_configs/" .. fn, "DATA")
            if content then file.Write("GLcfg/" .. fn, content) end
        end
    end
end

Garrylose.Config = {

    aimbot_enabled = true,
    aimbot_fov = 90,
    aimbot_silent = true,
    aimbot_rcs = true,
    aimbot_vischeck = true,

    aimbot_hitbox_head = true,
    aimbot_hitbox_chest = true,
    aimbot_hitbox_stomach = true,
    aimbot_hitbox_arms = true,
    aimbot_hitbox_legs = true,
    aimbot_head_priority = true,
    aimbot_lock_ticks = 0,
    nospread_enabled = true,

    aimbot_multipoint = true,
    aimbot_multipoint_scale = 0.8,
    aimbot_extrapolation = true,
    aimbot_extrapolation_ticks = 3,
    aimbot_target_players = true,
    aimbot_team_check = false,
    aimbot_target_npcs = true,
    aimbot_auto_shoot = true,
    aimbot_shoot_mode = 2,
    hitchance_enabled = false,
    aimbot_hitchance = 0,
    aimbot_hitchance_override = 0,
    bind_hitchance_override = KEY_NONE,
    hitchance_override_active = false,
    airstop_enabled = false,
    bind_airstop = KEY_NONE,
    triggerbot_enabled = false,
    bind_triggerbot = KEY_NONE,
    triggerbot_delay = 0,
    triggerbot_head_only = false,
    bind_aimbot = KEY_NONE,

    antiaim_enabled = false,
    antiaim_pitch = 1,
    antiaim_yaw = 1,
    antiaim_jitter_angle = 90,
    antiaim_pitch_jitter_angle = 45,
    antiaim_jitter_side = 1,
    antiaim_spin_speed = 450,
    manual_aa_state = 0,
    manual_aa_arrows = true,
    bind_manual_left = KEY_NONE,
    bind_manual_right = KEY_NONE,
    bind_manual_back = KEY_NONE,
    bind_antiaim = KEY_NONE,
    ui_style = 1,

    glow_esp_enabled = false,
    col_glow_esp = Color(0, 210, 255, 255),
    desync_ghost_enabled = false,
    desync_ghost_mat = 1,
    col_desync_ghost = Color(0, 230, 255, 140),

    bullet_tracers_enabled = true,
    col_bullet_tracers = Color(0, 220, 255, 255),
    bullet_impacts_enabled = true,
    col_bullet_impacts = Color(0, 180, 255, 255),

    esp_skeleton = true,
    col_esp_skeleton = Color(255, 255, 255, 220),

    offscreen_esp_enabled = true,
    offscreen_esp_radius = 240,
    offscreen_esp_size = 14,
    col_offscreen_esp = Color(255, 60, 90, 255),

    esp_weapon_info = true,
    col_esp_weapon = Color(240, 245, 255, 255),
    esp_ammo = true,
    col_esp_ammo = Color(255, 180, 40, 255),

    prop_transparency_enabled = false,
    prop_transparency_mode = 1,
    prop_alpha = 110,
    col_prop_transparency = Color(255, 255, 255, 110),

    custom_skybox_enabled = false,
    custom_skybox_type = 1,

    grenade_warning_enabled = true,
    col_grenade_warning = Color(255, 50, 50, 220),
    grenade_pred_enabled = true,
    col_grenade_pred = Color(0, 220, 255, 255),
    spectator_list_enabled = false,

    killsay_enabled = false,
    nightmode_enabled = false,
    nightmode_darkness = 0.50,
    col_nightmode = Color(20, 30, 55, 255),
    bind_nightmode = KEY_NONE,
    skybox_mod_enabled = false,
    col_skybox = Color(12, 16, 28, 255),
    fullbright_enabled = false,
    fog_enabled = false,
    fog_density = 2200,
    col_fog = Color(20, 25, 40, 255),
    thirdperson_enabled = false,
    thirdperson_dist = 100,
    bind_thirdperson = KEY_NONE,
    aspect_ratio_enabled = false,
    aspect_ratio_val = 1.33,

    esp_enabled = true,
    esp_boxes = true,
    col_esp_boxes = Color(0, 210, 255, 255),
    esp_names = true,
    col_esp_names = Color(240, 245, 255, 255),
    esp_health = true,
    col_esp_health = Color(0, 230, 180, 255),
    esp_snaplines = true,
    col_esp_snaplines = Color(0, 210, 255, 200),
    col_fov_ring = Color(0, 190, 255, 120),
    col_hitmarker = Color(255, 255, 255, 255),
    col_dmg_numbers = Color(255, 255, 255, 255),
    bind_esp = KEY_NONE,

    col_esp_trail = Color(0, 255, 255, 255),
    col_jump_circles = Color(0, 255, 255, 255),
    col_esp_box_fill = Color(0, 255, 255, 30),
    col_worldmod = Color(255, 255, 255, 255),
    col_chams_player = Color(0, 255, 0, 255),
    col_chams_npc = Color(255, 255, 0, 255),
    col_chams_self = Color(255, 0, 0, 255),
    col_chams_hands = Color(0, 0, 255, 255),
    freecam_speed = 10,
    viewmodel_pitch = 0,
    viewmodel_yaw = 0,
    viewmodel_roll = 0,
    chams_npc = false,
    nothing_enabled = false,
    bind_nothing = KEY_NONE,

    col_esp_box = Color(0, 210, 255, 255),
    col_manual_arrows = Color(0, 215, 255, 255),

    aimbot_min_damage = 1,
    aimbot_min_damage_override = 1,
    bind_min_damage_override = KEY_NONE,
    min_damage_override_active = false,

    hitsound_enabled = true,
    hitsound_type = 1,
    hitsound_volume = 100,
    hitmarker_enabled = true,
    hitmarker_damage_numbers = true,

    bhop_enabled = true,
    bind_bhop = KEY_NONE,
    autostrafe_enabled = true,
    autostrafe_mode = 1,
    bind_autostrafe = KEY_NONE,
    autopeek_enabled = false,
    bind_autopeek = KEY_NONE,
    col_autopeek = Color(0, 215, 255, 220),
    autopeek_return_mode = 3,
    edgejump_enabled = false,
    bind_edgejump = KEY_NONE,
    jumpbug_enabled = true,
    jumpbug_mode = 1,
    bind_jumpbug = KEY_NONE,
    edgebug_enabled = false,
    bind_edgebug = KEY_NONE,
    fakeduck_enabled = false,
    bind_fakeduck = KEY_NONE,
    crouchjump_enabled = false,
    crouchjump_mode = 1,
    bind_crouchjump = KEY_NONE,
    slidewalk_enabled = false,
    bind_panic = KEY_NONE,
    autoreload_enabled = true,
    keybinds_list_enabled = true,
    viewmodel_fov = 68,
    viewmodel_x = 0,
    viewmodel_y = 0,
    viewmodel_z = 0,

    killeffect_enabled = true,
    killeffect_type = 1,
    col_killeffect = Color(0, 215, 255, 255),
    watermark_enabled = true,
    keybinds_x = 25,
    keybinds_y = 300,
    fov_changer = 100,
    bind_menu = KEY_INSERT,
    menu_theme = 1,
    language = "en"
}

function Garrylose.SaveConfig(name)

    if not name or string.Trim(name) == "" then name = "default" end

    name = string.lower(string.Trim(name))

    if not string.EndsWith(name, ".json") then name = name .. ".json" end

    Garrylose.Config.aimbot_hitbox = tonumber(Garrylose.Config.aimbot_hitbox) or 1

    Garrylose.Config.aimbot_lock_ticks = tonumber(Garrylose.Config.aimbot_lock_ticks) or 2

    Garrylose.Config.aimbot_shoot_mode = tonumber(Garrylose.Config.aimbot_shoot_mode) or 2

    Garrylose.Config.hitsound_type = tonumber(Garrylose.Config.hitsound_type) or 1

    Garrylose.Config.hitsound_volume = tonumber(Garrylose.Config.hitsound_volume) or 100

    Garrylose.Config.autostrafe_mode = tonumber(Garrylose.Config.autostrafe_mode) or 1

    Garrylose.Config.crouchjump_mode = tonumber(Garrylose.Config.crouchjump_mode) or 1

    Garrylose.Config.autopeek_return_mode = tonumber(Garrylose.Config.autopeek_return_mode) or 3

    Garrylose.Config.antiaim_pitch = tonumber(Garrylose.Config.antiaim_pitch) or 1

    Garrylose.Config.antiaim_yaw = tonumber(Garrylose.Config.antiaim_yaw) or 1

    Garrylose.Config.antiaim_spin_speed = tonumber(Garrylose.Config.antiaim_spin_speed) or 450

    Garrylose.Config.aimbot_fov = tonumber(Garrylose.Config.aimbot_fov) or 90

    Garrylose.Config.thirdperson_dist = tonumber(Garrylose.Config.thirdperson_dist) or 100

    Garrylose.Config.aspect_ratio_val = tonumber(Garrylose.Config.aspect_ratio_val) or 1.33

    Garrylose.Config.ui_style = tonumber(Garrylose.Config.ui_style) or 1

    Garrylose.Config.nightmode_darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50

    Garrylose.Config.fog_density = tonumber(Garrylose.Config.fog_density) or 2200

    Garrylose.Config.fov_changer = tonumber(Garrylose.Config.fov_changer) or 100

    Garrylose.Config.custom_accent_r = tonumber(Garrylose.Config.custom_accent_r) or 0

    Garrylose.Config.custom_accent_g = tonumber(Garrylose.Config.custom_accent_g) or 180

    Garrylose.Config.custom_accent_b = tonumber(Garrylose.Config.custom_accent_b) or 255

    Garrylose.Config.viewmodel_fov = tonumber(Garrylose.Config.viewmodel_fov) or 68

    Garrylose.Config.viewmodel_x = tonumber(Garrylose.Config.viewmodel_x) or 0

    Garrylose.Config.viewmodel_y = tonumber(Garrylose.Config.viewmodel_y) or 0

    Garrylose.Config.viewmodel_z = tonumber(Garrylose.Config.viewmodel_z) or 0

    Garrylose.Config.desync_ghost_mat = tonumber(Garrylose.Config.desync_ghost_mat) or 1

    Garrylose.Config.prop_transparency_mode = tonumber(Garrylose.Config.prop_transparency_mode) or 1

    Garrylose.Config.prop_alpha = tonumber(Garrylose.Config.prop_alpha) or 110

    Garrylose.Config.custom_skybox_type = tonumber(Garrylose.Config.custom_skybox_type) or 1

    Garrylose.Config.killeffect_type = tonumber(Garrylose.Config.killeffect_type) or 1

    local json = util.TableToJSON(Garrylose.Config, true)

    if json then

        if not file.Exists("GLcfg", "DATA") then file.CreateDir("GLcfg") end

        file.Write("GLcfg/" .. name, json)

        notification.AddLegacy("Garrylose: Config '" .. name .. "' saved to GLcfg!", NOTIFY_HINT, 3)

    end

end

function Garrylose.LoadConfig(name)

    if not name or string.Trim(name) == "" then name = "default" end

    name = string.lower(string.Trim(name))

    if not string.EndsWith(name, ".json") then name = name .. ".json" end

    local cfgPath = "GLcfg/" .. name
    if not file.Exists(cfgPath, "DATA") and file.Exists("garrylose_configs/" .. name, "DATA") then
        cfgPath = "garrylose_configs/" .. name
    end

    if file.Exists(cfgPath, "DATA") then

        local json = file.Read(cfgPath, "DATA")

        local tbl = util.JSONToTable(json)

        if tbl then

            for k, v in pairs(tbl) do

                if type(v) == "table" and v.r and v.g and v.b then

                    Garrylose.Config[k] = Color(v.r, v.g, v.b, v.a or 255)

                else

                    Garrylose.Config[k] = v

                end

            end

            if tbl.col_esp_box and tbl.col_esp_box.r then Garrylose.Config.col_esp_box = Color(tbl.col_esp_box.r, tbl.col_esp_box.g, tbl.col_esp_box.b, tbl.col_esp_box.a or 255) end

            if tbl.col_esp_snaplines and tbl.col_esp_snaplines.r then Garrylose.Config.col_esp_snaplines = Color(tbl.col_esp_snaplines.r, tbl.col_esp_snaplines.g, tbl.col_esp_snaplines.b, tbl.col_esp_snaplines.a or 255) end

            if tbl.col_manual_arrows and tbl.col_manual_arrows.r then Garrylose.Config.col_manual_arrows = Color(tbl.col_manual_arrows.r, tbl.col_manual_arrows.g, tbl.col_manual_arrows.b, tbl.col_manual_arrows.a or 255) end

            if tbl.col_fov_ring and tbl.col_fov_ring.r then Garrylose.Config.col_fov_ring = Color(tbl.col_fov_ring.r, tbl.col_fov_ring.g, tbl.col_fov_ring.b, tbl.col_fov_ring.a or 120) end

            if tbl.col_autopeek and tbl.col_autopeek.r then Garrylose.Config.col_autopeek = Color(tbl.col_autopeek.r, tbl.col_autopeek.g, tbl.col_autopeek.b, tbl.col_autopeek.a or 220) end

            if tbl.col_killeffect and tbl.col_killeffect.r then Garrylose.Config.col_killeffect = Color(tbl.col_killeffect.r, tbl.col_killeffect.g, tbl.col_killeffect.b, tbl.col_killeffect.a or 255) end

            Garrylose.Config.aimbot_hitbox = tonumber(Garrylose.Config.aimbot_hitbox) or 1

            Garrylose.Config.aimbot_lock_ticks = tonumber(Garrylose.Config.aimbot_lock_ticks) or 2

            Garrylose.Config.aimbot_shoot_mode = tonumber(Garrylose.Config.aimbot_shoot_mode) or 2

            Garrylose.Config.antiaim_pitch = tonumber(Garrylose.Config.antiaim_pitch) or 1

            Garrylose.Config.antiaim_yaw = tonumber(Garrylose.Config.antiaim_yaw) or 1

            Garrylose.Config.antiaim_spin_speed = tonumber(Garrylose.Config.antiaim_spin_speed) or 450

            notification.AddLegacy("Garrylose: Config '" .. name .. "' loaded!", NOTIFY_GENERIC, 3)

            hook.Run("Garrylose_ConfigLoaded", name)

            if Garrylose.OpenMenu and IsValid(Garrylose.MenuFrame) then

                Garrylose.OpenMenu()

            end

        end

    else

        notification.AddLegacy("Garrylose: Config '" .. name .. "' not found in GLcfg!", NOTIFY_ERROR, 3)

    end

end

function Garrylose.DeleteConfig(name)

    if not name or string.Trim(name) == "" then return end

    name = string.lower(string.Trim(name))

    if not string.EndsWith(name, ".json") then name = name .. ".json" end

    if file.Exists("GLcfg/" .. name, "DATA") then

        file.Delete("GLcfg/" .. name)

        notification.AddLegacy("Garrylose: Config '" .. name .. "' deleted!", NOTIFY_CLEANUP, 3)

        if Garrylose.OpenMenu and IsValid(Garrylose.MenuFrame) then

            Garrylose.OpenMenu()

        end

    end

end

local nonFirearms = {
    ["weapon_physgun"] = true,
    ["gmod_tool"] = true,
    ["gmod_camera"] = true,
    ["weapon_physcannon"] = true,
    ["weapon_medkit"] = true,
    ["none"] = true,
    ["weapon_crowbar"] = true,
    ["weapon_stunstick"] = true,
    ["weapon_fists"] = true,
    ["weapon_frag"] = true,
    ["weapon_slam"] = true,
}

function Garrylose.IsValidFirearm(wep)
    if not IsValid(wep) then return false end
    local class = string.lower(wep:GetClass() or "")
    if nonFirearms[class] then return false end

    if string.find(class, "knife") or string.find(class, "sword") or string.find(class, "fist") or
       string.find(class, "melee") or string.find(class, "bayonet") or string.find(class, "karambit") or
       string.find(class, "axe") or string.find(class, "bat") or string.find(class, "hammer") or
       string.find(class, "machete") or string.find(class, "grenade") or string.find(class, "frag") or
       string.find(class, "c4") or string.find(class, "bomb") or string.find(class, "ied") or
       string.find(class, "hands") then
        return false
    end

    if wep.IsMelee or wep.IsKnife or wep.Melee then return false end
    return true
end

hook.Add("InitPostEntity", "Garrylose_AutoLoadDefaultCFG", function()

    if file.Exists("GLcfg/default.json", "DATA") then

        Garrylose.LoadConfig("default.json")

    elseif file.Exists("garrylose_configs/default.json", "DATA") then

        Garrylose.LoadConfig("default.json")

    end

end)

local keyStates = {}

function Garrylose.ToggleMenu()

    if IsValid(Garrylose.MenuFrame) then

        Garrylose.MenuFrame:Remove()

        Garrylose.MenuFrame = nil

    else

        if Garrylose.OpenMenu then

            Garrylose.OpenMenu()

        end

    end

end

local function GetActiveBindsList()

    return {

        { config = "bind_aimbot", action = function() Garrylose.Config.aimbot_enabled = not Garrylose.Config.aimbot_enabled end, name = "Aimbot", targetVar = "aimbot_enabled" },

        { config = "bind_antiaim", action = function() Garrylose.Config.antiaim_enabled = not Garrylose.Config.antiaim_enabled end, name = "Anti-Aim", targetVar = "antiaim_enabled" },

        { config = "bind_thirdperson", action = function() Garrylose.Config.thirdperson_enabled = not Garrylose.Config.thirdperson_enabled end, name = "Thirdperson", targetVar = "thirdperson_enabled" },

        { config = "bind_radar", action = function() Garrylose.Config.radar_enabled = not Garrylose.Config.radar_enabled end, name = "Radar", targetVar = "radar_enabled" },

        { config = "bind_esp", action = function() Garrylose.Config.esp_enabled = not Garrylose.Config.esp_enabled end, name = "ESP", targetVar = "esp_enabled" },

        { config = "bind_bhop", action = function() Garrylose.Config.bhop_enabled = not Garrylose.Config.bhop_enabled end, name = "Bhop", targetVar = "bhop_enabled" },

        { config = "bind_autostrafe", action = function() Garrylose.Config.autostrafe_enabled = not Garrylose.Config.autostrafe_enabled end, name = "Auto-Strafe", targetVar = "autostrafe_enabled" },

        { config = "bind_edgejump", action = function() Garrylose.Config.edgejump_enabled = not Garrylose.Config.edgejump_enabled end, name = "Edge-Jump", targetVar = "edgejump_enabled" },

        { config = "bind_fakeduck", action = function() Garrylose.Config.fakeduck_enabled = not Garrylose.Config.fakeduck_enabled end, name = "Fake-Duck", targetVar = "fakeduck_enabled" },

        { config = "bind_crouchjump", action = function() Garrylose.Config.crouchjump_enabled = not Garrylose.Config.crouchjump_enabled end, name = "Crouch-Jump", targetVar = "crouchjump_enabled" },

        { config = "bind_min_damage_override", action = function() Garrylose.Config.min_damage_override_active = not Garrylose.Config.min_damage_override_active end, name = "Min-Damage", targetVar = "min_damage_override_active" },

        { config = "bind_hitchance_override",  action = function() Garrylose.Config.hitchance_override_active = not Garrylose.Config.hitchance_override_active end,   name = "HC-Override", targetVar = "hitchance_override_active" },

        { config = "bind_triggerbot",         action = function() Garrylose.Config.triggerbot_enabled = not Garrylose.Config.triggerbot_enabled end,                 name = "Triggerbot", targetVar = "triggerbot_enabled" },

        { config = "bind_airstop",            action = function() Garrylose.Config.airstop_enabled = not Garrylose.Config.airstop_enabled end,                       name = "Air-Stop",   targetVar = "airstop_enabled" },

        { config = "bind_panic",              action = function() if Garrylose.PanicUnload then Garrylose.PanicUnload() end end,                                      name = "Panic-Unload" },

        { config = "bind_manual_left", action = function() 

            Garrylose.Config.manual_aa_state = (Garrylose.Config.manual_aa_state == 1) and 0 or 1

            local stateName = (Garrylose.Config.manual_aa_state == 1) and "LEFT" or "OFF"

            notification.AddLegacy("Garrylose: Manual AA [" .. stateName .. "]", NOTIFY_GENERIC, 2)

        end, name = nil },

        { config = "bind_manual_right", action = function() 

            Garrylose.Config.manual_aa_state = (Garrylose.Config.manual_aa_state == 2) and 0 or 2

            local stateName = (Garrylose.Config.manual_aa_state == 2) and "RIGHT" or "OFF"

            notification.AddLegacy("Garrylose: Manual AA [" .. stateName .. "]", NOTIFY_GENERIC, 2)

        end, name = nil },

        { config = "bind_manual_back", action = function() 

            Garrylose.Config.manual_aa_state = (Garrylose.Config.manual_aa_state == 3) and 0 or 3

            local stateName = (Garrylose.Config.manual_aa_state == 3) and "BACK" or "OFF"

            notification.AddLegacy("Garrylose: Manual AA [" .. stateName .. "]", NOTIFY_GENERIC, 2)

        end, name = nil },

        { config = "bind_autopeek", action = function() 

            Garrylose.Config.autopeek_enabled = not Garrylose.Config.autopeek_enabled

            if Garrylose.Config.autopeek_enabled then

                local lp = LocalPlayer()

                if IsValid(lp) then

                    Garrylose.AutoPeekPos = lp:GetPos()

                    Garrylose.AutoPeekState = "IDLE"

                end

            else

                Garrylose.AutoPeekPos = nil

                Garrylose.AutoPeekState = nil

            end

        end, name = "Peek-Assist", targetVar = "autopeek_enabled" },

    }

end

local function IsKeyCurrentlyPressed(code)

    if not code or code == KEY_NONE or code == 0 then return false end

    if code < 107 then

        return input.IsKeyDown(code)

    else

        return input.IsMouseDown(code)

    end

end

local function TriggerBind(b)

    b.action()

    if b.name and b.targetVar then

        local state = Garrylose.Config[b.targetVar]

        notification.AddLegacy("Garrylose: " .. b.name .. " " .. (state and "[ON]" or "[OFF]"), NOTIFY_GENERIC, 2)

    end

end

hook.Add("Think", "Garrylose_UniversalKeybind_Think", function()

    if gui.IsConsoleVisible() or gui.IsGameUIVisible() then return end

    local menuKey = Garrylose.Config.bind_menu or KEY_INSERT

    if menuKey and menuKey ~= KEY_NONE and menuKey ~= 0 then

        local isMenuDown = IsKeyCurrentlyPressed(menuKey)

        if isMenuDown then

            if not keyStates["bind_menu"] then

                keyStates["bind_menu"] = true

                Garrylose.ToggleMenu()

            end

        else

            keyStates["bind_menu"] = false

        end

    end

    if vgui.CursorVisible() then return end

    local binds = GetActiveBindsList()

    for _, b in ipairs(binds) do

        local key = Garrylose.Config[b.config]

        if key and key ~= KEY_NONE and key ~= 0 then

            local isDown = IsKeyCurrentlyPressed(key)

            if isDown then

                if not keyStates[b.config] then

                    keyStates[b.config] = true

                    TriggerBind(b)

                end

            else

                keyStates[b.config] = false

            end

        end

    end

end)

file.CreateDir("garrylose_scripts")

local defaultRainbowCode = [[Garrylose.RegisterPlugin("rainbow_bar", {

    name = "Rainbow Bottom Bar",

    enabled = true,

    onHUDPaint = function()

        local w, h = ScrW(), ScrH()

        local barH = 4

        local t = CurTime() * 100

        local segs = 32

        local segW = math.ceil(w / segs)

        for i = 0, segs do

            local hue = (t + (i * (360 / segs))) % 360

            surface.SetDrawColor(HSVToColor(hue, 1, 1))

            surface.DrawRect(i * segW, h - barH, segW, barH)

        end

    end

})]]

local defaultCyberCrossCode = [[Garrylose.RegisterPlugin("cyber_crosshair", {

    name = "Cyber Ring Crosshair",

    enabled = true,

    onHUDPaint = function()

        local cx, cy = ScrW() / 2, ScrH() / 2

        local t = CurTime() * 3

        local col = HSVToColor((CurTime() * 90) % 360, 0.9, 1.0)

        draw.RoundedBox(2, cx - 2, cy - 2, 4, 4, col)

        for i = 1, 4 do

            local ang = t + ((i - 1) * (math.pi / 2))

            local x = cx + math.cos(ang) * 15

            local y = cy + math.sin(ang) * 15

            draw.RoundedBox(2, x - 2, y - 2, 4, 4, col)

        end

    end

})]]

local defaultKeystrokesCode = [[Garrylose.RegisterPlugin("keystrokes_hud", {

    name = "Keystrokes Movement HUD",

    enabled = true,

    onHUDPaint = function()

        local scrW, scrH = ScrW(), ScrH()

        local startX = scrW - 130

        local startY = scrH - 170

        local keySize = 32

        local sp = 4

        local keys = {

            { name = "W",  key = KEY_W,       x = startX + keySize + sp, y = startY },

            { name = "A",  key = KEY_A,       x = startX,                y = startY + keySize + sp },

            { name = "S",  key = KEY_S,       x = startX + keySize + sp, y = startY + keySize + sp },

            { name = "D",  key = KEY_D,       x = startX + (keySize + sp) * 2, y = startY + keySize + sp },

            { name = "JUMP", key = KEY_SPACE, x = startX,                y = startY + (keySize + sp) * 2, w = (keySize * 3) + (sp * 2), h = 20 },

        }

        local rainbow = HSVToColor((CurTime() * 90) % 360, 0.85, 1.0)

        local bgOff = Color(12, 16, 24, 210)

        local bgOn  = Color(rainbow.r, rainbow.g, rainbow.b, 170)

        for _, k in ipairs(keys) do

            local isDown = input.IsKeyDown(k.key)

            local kw = k.w or keySize

            local kh = k.h or keySize

            draw.RoundedBox(4, k.x, k.y, kw, kh, isDown and bgOn or bgOff)

            surface.SetDrawColor(isDown and rainbow or Color(40, 50, 70, 200))

            surface.DrawOutlinedRect(k.x, k.y, kw, kh)

            draw.SimpleText(k.name, "DefaultFixed", k.x + kw / 2, k.y + kh / 2, isDown and color_white or Color(170, 185, 210), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        end

    end

})]]

function Garrylose.GetAutoLoadScripts()

    if file.Exists("garrylose_autoload.json", "DATA") then

        local data = file.Read("garrylose_autoload.json", "DATA")

        local tbl = util.JSONToTable(data or "")

        if type(tbl) == "table" then return tbl end

    end

    return {}

end

function Garrylose.SetScriptAutoLoad(fn, state)

    local tbl = Garrylose.GetAutoLoadScripts()

    tbl[fn] = state and true or nil

    file.Write("garrylose_autoload.json", util.TableToJSON(tbl, true))

end

function Garrylose.IsScriptAutoLoad(fn)

    local tbl = Garrylose.GetAutoLoadScripts()

    return tbl[fn] == true

end

local function EnsureDefaultScripts()

    file.CreateDir("garrylose_scripts")

    if not file.Exists("garrylose_scripts/rainbow_bar.txt", "DATA") then

        file.Write("garrylose_scripts/rainbow_bar.txt", defaultRainbowCode)

    end

    if not file.Exists("garrylose_scripts/cyber_cross.txt", "DATA") then

        file.Write("garrylose_scripts/cyber_cross.txt", defaultCyberCrossCode)

    end

    if not file.Exists("garrylose_scripts/keystrokes_hud.txt", "DATA") then

        file.Write("garrylose_scripts/keystrokes_hud.txt", defaultKeystrokesCode)

    end

end

EnsureDefaultScripts()

hook.Add("InitPostEntity", "Garrylose_LoadSavedUserScript", function()

    EnsureDefaultScripts()

    local scriptFiles = file.Find("garrylose_scripts/*.txt", "DATA")

    for _, sf in ipairs(scriptFiles or {}) do

        if Garrylose.IsScriptAutoLoad(sf) then

            local code = file.Read("garrylose_scripts/" .. sf, "DATA")

            if code and code ~= "" then

                RunString(code, "Garrylose_" .. sf)

                print("[Garrylose] Auto-loaded script: " .. sf)

            end

        end

    end

end)

Garrylose.CachedTargets = Garrylose.CachedTargets or {}

Garrylose.KeyStates = keyStates
Garrylose.GetActiveBindsList = GetActiveBindsList
Garrylose.IsKeyCurrentlyPressed = IsKeyCurrentlyPressed
Garrylose.TriggerBind = TriggerBind
Garrylose.EnsureDefaultScripts = EnsureDefaultScripts
Garrylose.DefaultRainbowCode = defaultRainbowCode
