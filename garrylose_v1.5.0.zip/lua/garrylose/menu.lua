local GetKeyName = Garrylose.GetKeyName
local EnsureDefaultScripts = Garrylose.EnsureDefaultScripts
local defaultRainbowCode = Garrylose.DefaultRainbowCode


function Garrylose.OpenColorPicker(title, configKey, onColorChanged)

    if IsValid(Garrylose.ColorPickerFrame) then

        Garrylose.ColorPickerFrame:Remove()

    end

    local C_MAIN_BG     = Color(11, 14, 20, 252)

    local C_CARD_BG     = Color(18, 24, 34, 250)

    local C_CARD_BORDER = Color(28, 38, 56, 255)

    local C_ACCENT      = Garrylose.GetActiveTheme().accent

    local C_TEXT        = Color(230, 240, 255, 255)

    local C_TEXT_MUTED  = Color(125, 145, 170, 255)

    local cp = vgui.Create("DFrame")

    Garrylose.ColorPickerFrame = cp

    cp:SetTitle("")

    cp:SetSize(290, 330)

    cp:Center()

    cp:MakePopup()

    cp:ShowCloseButton(false)

    cp:SetDraggable(true)

    local initialCol = Garrylose.Config[configKey] or Color(0, 210, 255, 255)

    local curR = initialCol.r or 0

    local curG = initialCol.g or 210

    local curB = initialCol.b or 255

    local curA = initialCol.a or 255

    cp.Paint = function(self, w, h)

        draw.RoundedBox(8, 0, 0, w, h, C_MAIN_BG)

        surface.SetDrawColor(C_CARD_BORDER)

        surface.DrawOutlinedRect(0, 0, w, h)


        draw.RoundedBoxEx(8, 0, 0, w, 28, Color(22, 30, 44, 255), true, true, false, false)

        surface.SetDrawColor(C_ACCENT)

        surface.DrawLine(0, 28, w, 28)

        draw.SimpleText(string.upper(title or "COLOR PICKER"), "DermaDefaultBold", 12, 14, C_TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)


        local previewCol = Color(curR, curG, curB, curA)

        draw.RoundedBox(4, 15, 36, w - 30, 24, previewCol)

        surface.SetDrawColor(C_CARD_BORDER)

        surface.DrawOutlinedRect(15, 36, w - 30, 24)

        local lum = curR * 0.299 + curG * 0.587 + curB * 0.114

        draw.SimpleText(string.format("RGBA: %d, %d, %d, %d", curR, curG, curB, curA), "DefaultFixed", w / 2, 48, lum > 150 and Color(10,10,10) or Color(250,250,250), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    end

    local closeBtn = vgui.Create("DButton", cp)

    closeBtn:SetSize(24, 24)

    closeBtn:SetPos(290 - 30, 2)

    closeBtn:SetText("X")

    closeBtn:SetFont("DermaDefaultBold")

    closeBtn:SetTextColor(C_TEXT_MUTED)

    closeBtn.Paint = function() end

    closeBtn.DoClick = function() cp:Close() end

    local chipsPnl = vgui.Create("DPanel", cp)

    chipsPnl:SetPos(15, 68)

    chipsPnl:SetSize(260, 24)

    chipsPnl.Paint = function() end

    local presets = {

        Color(0, 210, 255),

        Color(245, 55, 75),

        Color(40, 215, 120),

        Color(175, 75, 255),

        Color(255, 165, 0),

        Color(255, 60, 160),

        Color(255, 255, 255),

        Color(255, 225, 50),

    }

    local mixer

    local function ApplyColor()

        local newCol = Color(curR, curG, curB, curA)

        Garrylose.Config[configKey] = newCol

        if onColorChanged then onColorChanged(newCol) end

    end

    local chipW = (260 - (7 * 4)) / 8

    for idx, col in ipairs(presets) do

        local cBtn = vgui.Create("DButton", chipsPnl)

        cBtn:SetPos((idx - 1) * (chipW + 4), 2)

        cBtn:SetSize(chipW, 20)

        cBtn:SetText("")

        cBtn.Paint = function(self, bw, bh)

            draw.RoundedBox(3, 0, 0, bw, bh, col)

            surface.SetDrawColor(C_CARD_BORDER)

            surface.DrawOutlinedRect(0, 0, bw, bh)

        end

        cBtn.DoClick = function()

            curR = col.r

            curG = col.g

            curB = col.b

            if IsValid(mixer) then mixer:SetColor(Color(curR, curG, curB, curA)) end

            ApplyColor()

        end

    end


    mixer = vgui.Create("DColorMixer", cp)

    mixer:SetPos(15, 98)

    mixer:SetSize(260, 175)

    mixer:SetPalette(false)

    mixer:SetAlphaBar(true)

    mixer:SetWangs(true)

    mixer:SetColor(initialCol)

    mixer.ValueChanged = function(self, col)

        curR = col.r

        curG = col.g

        curB = col.b

        curA = col.a

        ApplyColor()

    end


    local applyBtn = vgui.Create("DButton", cp)

    applyBtn:SetPos(15, 285)

    applyBtn:SetSize(260, 28)

    applyBtn:SetText("CONFIRM COLOR")

    applyBtn:SetFont("DermaDefaultBold")

    applyBtn:SetTextColor(Color(250, 250, 250))

    applyBtn.Paint = function(self, bw, bh)

        draw.RoundedBox(4, 0, 0, bw, bh, self:IsHovered() and C_ACCENT or Color(22, 30, 44))

        surface.SetDrawColor(C_ACCENT)

        surface.DrawOutlinedRect(0, 0, bw, bh)

    end

    applyBtn.DoClick = function()

        ApplyColor()

        cp:Close()

    end

end

local function GetKeyName(key)

    return Garrylose.GetKeyName(key)

end

function Garrylose.OpenMenu()

    if IsValid(Garrylose.MenuFrame) then

        Garrylose.MenuFrame:Remove()

    end

    local curTheme   = Garrylose.GetActiveTheme()

    local isLight = (Garrylose.Config.ui_style == 2)

    local BG         = isLight and Color(245, 247, 252, 255) or Color(18,  20,  27,  255)

    local SIDE_BG    = isLight and Color(235, 238, 245, 255) or Color(14,  16,  22,  255)

    local ITEM_BG    = isLight and Color(255, 255, 255, 255) or Color(22,  25,  34,  255)

    local ITEM_HOVER = isLight and Color(225, 230, 242, 255) or Color(28,  32,  44,  255)

    local BORDER     = isLight and Color(205, 212, 225, 255) or Color(35,  40,  58,  255)

    local HEADER_BG  = isLight and Color(240, 243, 250, 255) or Color(20,  23,  32,  255)

    local ACCENT     = curTheme.accent

    local ACCENT_DIM = curTheme.dim

    local ACCENT_HOV = curTheme.hov

    local TEXT       = isLight and Color(25,  30,  45,  255) or Color(220, 225, 240, 255)

    local TEXT_MUT   = isLight and Color(115, 125, 145, 255) or Color(110, 120, 145, 255)

    local TEXT_DARK  = isLight and Color(155, 165, 185, 255) or Color(60,  68,  90,  255)

    local C_GREEN    = Color(50,  210, 120, 255)

    local C_RED      = Color(230, 60,  80,  255)

    local C_INPUT    = isLight and Color(255, 255, 255, 255) or Color(12,  14,  20,  255)

    local scrW, scrH = ScrW(), ScrH()

    local FW     = math.min(900, scrW - 60)

    local FH     = math.min(600, scrH - 60)

    local SIDE_W = 165

    local CON_W  = FW - SIDE_W

    local HEAD_H = 40

    local frame = vgui.Create("DFrame")

    Garrylose.MenuFrame = frame

    frame:SetTitle(""); frame:SetSize(FW, FH); frame:Center()

    frame:MakePopup(); frame:ShowCloseButton(false); frame:SetDraggable(false)

    frame.Paint = function(self, w, h)

        draw.RoundedBox(6, 0, 0, w, h, BG)

        surface.SetDrawColor(BORDER)

        surface.DrawOutlinedRect(0, 0, w, h)

        surface.SetDrawColor(ACCENT)

        surface.DrawLine(1, 0, w - 1, 0)

    end

    local isDragging = false

    local dragOffset = { x = 0, y = 0 }

    local function MakeDraggable(pnl)

        if not IsValid(pnl) then return end

        pnl:SetMouseInputEnabled(true)

        pnl.OnMousePressed = function(self, mouseCode)

            if mouseCode == MOUSE_LEFT then

                isDragging = true

                local mx, my = gui.MousePos()

                local fx, fy = frame:GetPos()

                dragOffset.x = mx - fx

                dragOffset.y = my - fy

                self:MouseCapture(true)

            end

        end

        pnl.OnMouseReleased = function(self, mouseCode)

            if mouseCode == MOUSE_LEFT and isDragging then

                isDragging = false

                self:MouseCapture(false)

            end

        end

        pnl.OnCursorMoved = function(self, mx, my)

            if isDragging and input.IsMouseDown(MOUSE_LEFT) then

                local curMx, curMy = gui.MousePos()

                local newX = math.Clamp(curMx - dragOffset.x, 0, ScrW() - frame:GetWide())

                local newY = math.Clamp(curMy - dragOffset.y, 0, ScrH() - frame:GetTall())

                frame:SetPos(newX, newY)

            elseif isDragging and not input.IsMouseDown(MOUSE_LEFT) then

                isDragging = false

                self:MouseCapture(false)

            end

        end

    end

    frame.Think = function(self)

        if isDragging and not input.IsMouseDown(MOUSE_LEFT) then

            isDragging = false

        end

    end

    MakeDraggable(frame)

    local sidebar = vgui.Create("DPanel", frame)

    sidebar:SetPos(0, 0); sidebar:SetSize(SIDE_W, FH)

    sidebar.Paint = function(self, w, h)

        draw.RoundedBoxEx(6, 0, 0, w, h, SIDE_BG, true, false, true, false)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(w - 1, 0, w - 1, h)

    end

    MakeDraggable(sidebar)


    local logo = vgui.Create("DPanel", sidebar)

    logo:SetPos(0, 0); logo:SetSize(SIDE_W, 50)

    logo.Paint = function(self, w, h)

        draw.SimpleText("GARRYLOSE", "DermaDefaultBold", 14, 18, ACCENT,   TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        draw.SimpleText(".CC",       "DermaDefault",     14 + surface.GetTextSize("GARRYLOSE") + 2, 18, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(10, h - 1, w - 10, h - 1)

    end

    MakeDraggable(logo)


    local function SideLabel(parent, txt, y)

        local lbl = vgui.Create("DPanel", parent)

        lbl:SetPos(0, y); lbl:SetSize(SIDE_W, 20)

        lbl.Paint = function(self, w, h)

            draw.SimpleText(string.upper(txt), "DefaultFixed", 14, 10, TEXT_DARK, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

        MakeDraggable(lbl)

        return lbl

    end

    local activeTab = Garrylose.CurrentMenuTab or 1

    local tabs = {

        { name = "Rage",        desc = "Ragebot & Auto-Fire", icon = "aim"  },

        { name = "Anti-Aim",    desc = "Desync & Angles",   icon = "aa"   },

        { name = "Visuals",     desc = "ESP & Camera",      icon = "vis"  },

        { name = "Misc",        desc = "Movement & System", icon = "misc" },

        { name = "Configs",     desc = "Profile Manager",   icon = "cfg"  },

        { name = "Lua Scripts", desc = "IDE & Plugins",     icon = "lua"  },

        { name = "Options",     desc = "Theme & Settings",  icon = "opt"  },

    }

    local LoadTabContent

    local navBtns = {}

    local function DrawTabIcon(icon, cx, cy, col)

        surface.SetDrawColor(col)

        if icon == "aim" then


            surface.DrawLine(cx, cy - 6, cx, cy - 2)

            surface.DrawLine(cx, cy + 2, cx, cy + 6)

            surface.DrawLine(cx - 6, cy, cx - 2, cy)

            surface.DrawLine(cx + 2, cy, cx + 6, cy)

            surface.DrawOutlinedRect(cx - 4, cy - 4, 9, 9)

            draw.RoundedBox(0, cx - 1, cy - 1, 3, 3, col)

        elseif icon == "aa" then


            surface.DrawLine(cx - 5, cy - 5, cx + 5, cy - 5)

            surface.DrawLine(cx - 5, cy - 5, cx - 5, cy + 1)

            surface.DrawLine(cx + 5, cy - 5, cx + 5, cy + 1)

            surface.DrawLine(cx - 5, cy + 1, cx, cy + 6)

            surface.DrawLine(cx + 5, cy + 1, cx, cy + 6)

            surface.DrawLine(cx - 2, cy - 1, cx + 2, cy - 1)

            surface.DrawLine(cx + 2, cy - 1, cx, cy - 3)

            surface.DrawLine(cx + 2, cy - 1, cx, cy + 1)

        elseif icon == "vis" then


            surface.DrawLine(cx - 6, cy, cx - 2, cy - 4)

            surface.DrawLine(cx - 2, cy - 4, cx + 2, cy - 4)

            surface.DrawLine(cx + 2, cy - 4, cx + 6, cy)

            surface.DrawLine(cx - 6, cy, cx - 2, cy + 4)

            surface.DrawLine(cx - 2, cy + 4, cx + 2, cy + 4)

            surface.DrawLine(cx + 2, cy + 4, cx + 6, cy)

            draw.RoundedBox(2, cx - 2, cy - 2, 5, 5, col)

        elseif icon == "misc" then


            surface.DrawLine(cx + 1, cy - 6, cx - 3, cy)

            surface.DrawLine(cx - 3, cy, cx + 2, cy)

            surface.DrawLine(cx + 2, cy, cx - 2, cy + 6)

            surface.DrawLine(cx - 2, cy + 6, cx + 3, cy - 1)

            surface.DrawLine(cx + 3, cy - 1, cx - 1, cy - 1)

            surface.DrawLine(cx - 1, cy - 1, cx + 1, cy - 6)

        elseif icon == "cfg" then


            surface.DrawOutlinedRect(cx - 5, cy - 5, 11, 11)

            surface.DrawRect(cx - 3, cy - 5, 7, 4)

            surface.DrawOutlinedRect(cx - 4, cy + 1, 9, 4)

            surface.DrawLine(cx - 2, cy + 3, cx + 3, cy + 3)

        elseif icon == "lua" then


            surface.DrawLine(cx - 2, cy - 5, cx - 6, cy)

            surface.DrawLine(cx - 6, cy, cx - 2, cy + 5)

            surface.DrawLine(cx + 1, cy - 6, cx - 1, cy + 6)

            surface.DrawLine(cx + 2, cy - 5, cx + 6, cy)

            surface.DrawLine(cx + 6, cy, cx + 2, cy + 5)

        elseif icon == "opt" then


            surface.DrawLine(cx - 2, cy - 5, cx + 2, cy - 5)

            surface.DrawLine(cx + 2, cy - 5, cx + 5, cy - 2)

            surface.DrawLine(cx + 5, cy - 2, cx + 5, cy + 2)

            surface.DrawLine(cx + 5, cy + 2, cx + 2, cy + 5)

            surface.DrawLine(cx + 2, cy + 5, cx - 2, cy + 5)

            surface.DrawLine(cx - 2, cy + 5, cx - 5, cy + 2)

            surface.DrawLine(cx - 5, cy + 2, cx - 5, cy - 2)

            surface.DrawLine(cx - 5, cy - 2, cx - 2, cy - 5)

            surface.DrawOutlinedRect(cx - 2, cy - 2, 5, 5)

        end

    end

    SideLabel(sidebar, "Main", 58)

    local function MakeTabBtn(idx, t, yPos)

        local btn = vgui.Create("DButton", sidebar)

        btn:SetPos(0, yPos); btn:SetSize(SIDE_W, 32)

        btn:SetText(""); btn.Index = idx

        btn.Paint = function(self, w, h)

            local act = (activeTab == self.Index)

            local hov = self:IsHovered()

            local ICO_X, ICO_Y = 22, h/2

            if act then

                draw.RoundedBox(0, 0, 0, w, h, ITEM_HOVER)

                draw.RoundedBox(2, 0, 5, 3, h - 10, ACCENT)

                DrawTabIcon(t.icon, ICO_X, ICO_Y, ACCENT)

                draw.SimpleText(t.name, "DermaDefaultBold", 38, h/2, ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            elseif hov then

                draw.RoundedBox(0, 0, 0, w, h, ITEM_BG)

                DrawTabIcon(t.icon, ICO_X, ICO_Y, TEXT)

                draw.SimpleText(t.name, "DermaDefault", 38, h/2, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            else

                DrawTabIcon(t.icon, ICO_X, ICO_Y, TEXT_MUT)

                draw.SimpleText(t.name, "DermaDefault", 38, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            end

        end

        btn.DoClick = function(self)

            activeTab = self.Index

            Garrylose.CurrentMenuTab = activeTab

            LoadTabContent(activeTab)

            for _, b in ipairs(navBtns) do b:InvalidateLayout(true) end

        end

        table.insert(navBtns, btn)

        return btn

    end

    local catBreaks = { [4] = "System" }

    local yOff = 78

    for i, t in ipairs(tabs) do

        if catBreaks[i] then

            SideLabel(sidebar, catBreaks[i], yOff)

            yOff = yOff + 20

        end

        MakeTabBtn(i, t, yOff)

        yOff = yOff + 30

    end


    local foot = vgui.Create("DPanel", sidebar)

    foot:SetPos(0, FH - 44); foot:SetSize(SIDE_W, 44)

    foot.Paint = function(self, w, h)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(10, 0, w - 10, 0)

        draw.RoundedBox(10, 10, 10, 22, 22, ACCENT_DIM)

        surface.SetDrawColor(ACCENT)

        surface.DrawOutlinedRect(10, 10, 22, 22)

        draw.SimpleText("G", "DermaDefaultBold", 21, 21, ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        local nick = IsValid(LocalPlayer()) and LocalPlayer():Nick() or "Player"

        if #nick > 13 then nick = nick:sub(1, 12) .. ".." end

        draw.SimpleText(nick, "DermaDefault", 38, 16, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        draw.SimpleText("v1.5.0", "DefaultFixed", 38, 30, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

    end

    MakeDraggable(foot)

    local header = vgui.Create("DPanel", frame)

    header:SetPos(SIDE_W, 0); header:SetSize(CON_W, HEAD_H)

    header.Paint = function(self, w, h)

        draw.RoundedBoxEx(6, 0, 0, w, h, HEADER_BG, false, true, false, false)

        surface.SetDrawColor(BORDER)

        surface.DrawLine(0, h - 1, w, h - 1)

        if activeTab == "SEARCH" then

            draw.SimpleText("SEARCH", "DermaDefaultBold", 18, h/2, ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            draw.SimpleText("/ Feature Omnibar Search Results", "DermaDefault", 78, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        else

            local cur = tabs[activeTab] or tabs[1]

            draw.SimpleText(cur.name, "DermaDefaultBold", 18, h/2, TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            local offX = 18 + select(1, surface.GetTextSize(cur.name)) + 8

            draw.SimpleText("/ " .. cur.desc, "DermaDefault", offX, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

    end

    MakeDraggable(header)


    local closeBtn = vgui.Create("DButton", header)

    closeBtn:SetPos(CON_W - 36, 6); closeBtn:SetSize(28, 28)

    closeBtn:SetText("✕"); closeBtn:SetFont("DermaDefaultBold"); closeBtn:SetTextColor(TEXT_MUT)

    closeBtn.Paint = function(self, w, h)

        if self:IsHovered() then

            draw.RoundedBox(4, 0, 0, w, h, C_RED)

            self:SetTextColor(color_white)

        else

            draw.RoundedBox(4, 0, 0, w, h, ITEM_BG)

            surface.SetDrawColor(BORDER)

            surface.DrawOutlinedRect(0, 0, w, h)

            self:SetTextColor(TEXT_MUT)

        end

    end

    closeBtn.DoClick = function() frame:Close() end

    local cfgCombo = vgui.Create("DComboBox", header)
    cfgCombo:SetPos(CON_W - 36 - 190 - 130, 7)
    cfgCombo:SetSize(120, 26)
    cfgCombo:SetValue("Select Config...")
    cfgCombo:SetFont("DermaDefault")
    cfgCombo:SetTextColor(TEXT)
    cfgCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, C_INPUT)
        surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)
    end
    local files, _ = file.Find("GLcfg/*.json", "DATA")
    local seen = {}
    for _, f in ipairs(files or {}) do
        seen[f] = true
        cfgCombo:AddChoice(string.Replace(f, ".json", ""), f)
    end
    local legacyFiles, _ = file.Find("garrylose_configs/*.json", "DATA")
    for _, f in ipairs(legacyFiles or {}) do
        if not seen[f] then
            cfgCombo:AddChoice(string.Replace(f, ".json", ""), f)
        end
    end
    cfgCombo.OnSelect = function(self, index, value, data)
        Garrylose.LoadConfig(data)
        notification.AddLegacy("Loaded config: " .. value, NOTIFY_GENERIC, 3)
    end
    hook.Add("Garrylose_ConfigLoaded", "Garrylose_Combo_ConfigSync", function(loadedName)
        if not IsValid(cfgCombo) then return end
        local niceName = string.Replace(loadedName, ".json", "")
        cfgCombo:SetValue(niceName)
    end)


    local searchEntry = vgui.Create("DTextEntry", header)

    searchEntry:SetPos(CON_W - 36 - 190, 7); searchEntry:SetSize(180, 26)

    searchEntry:SetPlaceholderText("🔍 Search features...")

    searchEntry:SetFont("DermaDefault")

    searchEntry:SetTextColor(TEXT)

    searchEntry:SetCursorColor(ACCENT)

    searchEntry.Paint = function(self, w, h)

        draw.RoundedBox(4, 0, 0, w, h, C_INPUT)

        surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

        surface.DrawOutlinedRect(0, 0, w, h)

        self:DrawTextEntryText(TEXT, ACCENT, color_white)

    end

    local scroll = vgui.Create("DScrollPanel", frame)

    scroll:SetPos(SIDE_W, HEAD_H); scroll:SetSize(CON_W, FH - HEAD_H)

    scroll.Paint = function() end

    MakeDraggable(scroll)

    local sbar = scroll:GetVBar()

    sbar:SetWide(4)

    sbar.Paint            = function(self, w, h) draw.RoundedBox(2, 0, 0, w, h, C_INPUT) end

    sbar.btnUp.Paint      = function() end

    sbar.btnDown.Paint    = function() end

    sbar.btnGrip.Paint    = function(self, w, h) draw.RoundedBox(2, 0, 0, w, h, ACCENT) end


    local function Section(parent, txt, yRef)

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(14, yRef[1]); pnl:SetSize(parent:GetWide() - 28, 18)

        pnl.Paint = function(self, w, h)

            draw.SimpleText(string.upper(txt), "DefaultFixed", 0, h/2, TEXT_DARK, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            surface.SetDrawColor(BORDER)

            surface.DrawLine(surface.GetTextSize(string.upper(txt)) + 6, h/2, w, h/2)

        end

        MakeDraggable(pnl)

        yRef[1] = yRef[1] + 24

        return pnl

    end

    local function Row(parent, txt, configKey, bindKey, colorKey, onChange, yRef)


        if type(colorKey) == "function" then

            yRef = onChange; onChange = colorKey; colorKey = nil

        elseif type(colorKey) == "table" and colorKey[1] ~= nil then

            yRef = colorKey; colorKey = nil

        end

        if type(onChange) == "table" then

            yRef = onChange; onChange = nil

        end

        local rowH = 28

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(0, yRef[1]); pnl:SetSize(parent:GetWide(), rowH)

        pnl.Paint = function(self, w, h)

            if self:IsHovered() then surface.SetDrawColor(ITEM_HOVER); surface.DrawRect(0, 0, w, h) end

        end

        pnl:SetMouseInputEnabled(true)


        local rightPad = 14

        if colorKey then rightPad = rightPad + 24 end

        if bindKey  then rightPad = rightPad + 52 end


        local lbl = vgui.Create("DLabel", pnl)

        lbl:SetPos(14, 0); lbl:SetSize(parent:GetWide() - rightPad - 40, rowH)

        lbl:SetText(txt); lbl:SetFont("DermaDefault"); lbl:SetTextColor(TEXT)

        if configKey then

            local PILL_W, PILL_H = 32, 16

            local pillX = parent:GetWide() - rightPad - PILL_W

            local pillBtn = vgui.Create("DButton", pnl)

            pillBtn:SetPos(pillX, (rowH - PILL_H) / 2)

            pillBtn:SetSize(PILL_W, PILL_H); pillBtn:SetText("")

            pillBtn.Paint = function(self, w, h)

                local on = Garrylose.Config[configKey] and true or false

                draw.RoundedBox(h/2, 0, 0, w, h, on and ACCENT or BORDER)

                local kX = on and (w - h + 2) or 2

                draw.RoundedBox(h/2 - 1, kX, 2, h - 4, h - 4, color_white)

            end

            pillBtn.DoClick = function()

                Garrylose.Config[configKey] = not Garrylose.Config[configKey]

                if onChange then onChange(Garrylose.Config[configKey]) end

            end

            lbl:SetMouseInputEnabled(true)

            lbl.DoClick = function() pillBtn:DoClick() end

        elseif colorKey then

            lbl:SetMouseInputEnabled(true)

            lbl.DoClick = function()

                Garrylose.OpenColorPicker(txt, colorKey, function(newCol)

                    if onChange then onChange(newCol) end

                end)

            end

        end


        if bindKey then

            local bb = vgui.Create("DBinder", pnl)

            local bbX = parent:GetWide() - (colorKey and 38 or 14) - 46

            bb:SetPos(bbX, (rowH - 18) / 2)

            bb:SetSize(46, 18); bb:SetSelectedNumber(Garrylose.Config[bindKey] or KEY_NONE)

            bb.OnChange = function(self, num) Garrylose.Config[bindKey] = num end

            bb.Paint = function(self, w, h)

                local isListen = self.Trapping

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsHovered() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                local kn = GetKeyName(self:GetSelectedNumber())

                draw.SimpleText(isListen and "..." or kn, "DefaultFixed", w/2, h/2,

                    isListen and ACCENT or TEXT_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            end

        end

        if colorKey then

            local colBtn = vgui.Create("DButton", pnl)

            colBtn:SetPos(parent:GetWide() - 14 - 18, (rowH - 16) / 2)

            colBtn:SetSize(18, 16); colBtn:SetText("")

            colBtn.Paint = function(self, w, h)

                local c = Garrylose.Config[colorKey] or Color(0, 210, 255)

                draw.RoundedBox(3, 0, 0, w, h, c)

                surface.SetDrawColor(self:IsHovered() and color_white or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

            end

            colBtn.DoClick = function()

                Garrylose.OpenColorPicker(txt, colorKey, function(newCol)

                    if onChange then onChange(newCol) end

                end)

            end

        end

        yRef[1] = yRef[1] + rowH

        return pnl

    end

    local function Slider(parent, txt, configKey, minV, maxV, decs, suffix, yRef)

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(0, yRef[1]); pnl:SetSize(parent:GetWide(), 44)

        local currentVal = tonumber(Garrylose.Config[configKey]) or minV

        pnl.Paint = function(self, w, h)

            draw.SimpleText(txt, "DermaDefault", 14, 10, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

        local valBtn = vgui.Create("DButton", pnl)
        valBtn:SetPos(pnl:GetWide() - 70, 2)
        valBtn:SetSize(56, 18)
        valBtn:SetText("")
        valBtn:SetFont("DefaultFixed")

        local entry = vgui.Create("DTextEntry", pnl)
        entry:SetPos(pnl:GetWide() - 70, 2)
        entry:SetSize(56, 18)
        entry:SetFont("DefaultFixed")
        entry:SetTextColor(TEXT)
        entry:SetVisible(false)
        entry.Paint = function(self, w, h)
            draw.RoundedBox(2, 0, 0, w, h, C_INPUT)
            surface.SetDrawColor(ACCENT)
            surface.DrawOutlinedRect(0, 0, w, h)
            self:DrawTextEntryText(TEXT, ACCENT, TEXT)
        end

        local function formatVal(v)
            return string.format("%." .. (decs or 0) .. "f", v) .. (suffix or "")
        end

        valBtn.Paint = function(self, w, h)
            local v = tonumber(Garrylose.Config[configKey]) or minV
            local col = self:IsHovered() and color_white or ACCENT
            draw.SimpleText(formatVal(v), "DefaultFixed", w - 4, h/2, col, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
        end

        local sl = vgui.Create("DSlider", pnl)

        sl:SetPos(14, 24); sl:SetSize(parent:GetWide() - 28, 16)

        local function syncSliderFromConfig()
            local cur = tonumber(Garrylose.Config[configKey]) or minV
            local frac = math.Clamp((cur - minV) / (maxV - minV), 0, 1)
            sl:SetSlideX(frac)
        end

        syncSliderFromConfig()

        sl.Paint = function(self, w, h)

            draw.RoundedBox(2, 0, 5, w, 4, BORDER)

            local fw = self:GetSlideX() * w

            if fw > 0 then draw.RoundedBox(2, 0, 5, fw, 4, ACCENT) end

        end

        sl.Knob.Paint = function(self, w, h)

            draw.RoundedBox(5, w/2-5, h/2-5, 10, 10, TEXT)

            surface.SetDrawColor(ACCENT); surface.DrawOutlinedRect(w/2-5, h/2-5, 10, 10)

        end

        sl.OnValueChanged = function(self, fx)

            local v = minV + fx * (maxV - minV)

            v = (decs or 0) == 0 and math.Round(v) or math.Round(v, decs)

            Garrylose.Config[configKey] = v

            if configKey == "nightmode_darkness" and v > 0 then

                Garrylose.Config.nightmode_enabled = true

            end

        end

        valBtn.DoClick = function()
            valBtn:SetVisible(false)
            entry:SetVisible(true)
            entry:SetValue(tostring(tonumber(Garrylose.Config[configKey]) or minV))
            entry:RequestFocus()
            entry:SelectAllText()
        end

        local function applyEntryValue()
            local inputNum = tonumber(entry:GetValue())
            if inputNum then
                inputNum = math.Clamp(inputNum, minV, maxV)
                inputNum = (decs or 0) == 0 and math.Round(inputNum) or math.Round(inputNum, decs)
                Garrylose.Config[configKey] = inputNum
                syncSliderFromConfig()
            end
            entry:SetVisible(false)
            valBtn:SetVisible(true)
        end

        entry.OnEnter = applyEntryValue
        entry.OnLoseFocus = applyEntryValue

        yRef[1] = yRef[1] + 50

        return pnl

    end


    local function Combo(parent, txt, opts, configKey, onChange, yRef)

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(0, yRef[1]); pnl:SetSize(parent:GetWide(), 44)

        pnl.Paint = function(self, w, h)

            draw.SimpleText(txt, "DermaDefault", 14, 10, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

        local cb = vgui.Create("DComboBox", pnl)

        cb:SetPos(14, 22); cb:SetSize(parent:GetWide() - 28, 18)

        cb:SetTextColor(TEXT); cb:SetFont("DermaDefault")

        local selIdx = 1

        for i, o in ipairs(opts) do

            cb:AddChoice(o.label, o.data)

            if o.data == Garrylose.Config[configKey] then selIdx = i end

        end

        cb.Initializing = true

        cb:ChooseOptionID(selIdx)

        cb.Initializing = false

        cb.Paint = function(self, w, h)

            draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

            surface.SetDrawColor(self:IsHovered() and ACCENT or BORDER)

            surface.DrawOutlinedRect(0, 0, w, h)

            draw.SimpleText("▾", "DefaultFixed", w - 12, h/2, ACCENT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        end

        cb.OnSelect = function(self, idx, lbl, data)

            if self.Initializing then return end

            Garrylose.Config[configKey] = data

            if onChange then

                timer.Simple(0, function()

                    if isfunction(onChange) then

                        onChange(data)

                    end

                end)

            end

        end

        yRef[1] = yRef[1] + 50

        return pnl

    end


    local function Btn(parent, txt, col, onClick, yRef)

        local b = vgui.Create("DButton", parent)

        b:SetPos(14, yRef[1]); b:SetSize(parent:GetWide() - 28, 26)

        b:SetText(txt); b:SetFont("DermaDefaultBold"); b:SetTextColor(TEXT)

        b.Paint = function(self, w, h)

            local c = col or ACCENT

            if self:IsHovered() then

                draw.RoundedBox(4, 0, 0, w, h, c); self:SetTextColor(color_white)

            else

                draw.RoundedBox(4, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(c); surface.DrawOutlinedRect(0, 0, w, h)

                self:SetTextColor(TEXT)

            end

        end

        b.DoClick = onClick

        yRef[1] = yRef[1] + 32

        return b

    end

    local function Note(parent, txt, yRef)

        local pnl = vgui.Create("DPanel", parent)

        pnl:SetPos(14, yRef[1]); pnl:SetSize(parent:GetWide() - 28, 18)

        pnl.Paint = function(self, w, h)

            draw.SimpleText(txt, "DefaultFixed", 0, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        end

        yRef[1] = yRef[1] + 20

        return pnl

    end

    local function Columns(parent, padTop)

        padTop = padTop or 14

        local totalW = parent:GetWide() - 2

        local colW   = math.floor(totalW / 2) - 1

        local divX   = colW + 1


        local div = vgui.Create("DPanel", parent)

        div:SetPos(divX, 0); div:SetSize(1, 9999)

        div.Paint = function(self, w, h) surface.SetDrawColor(BORDER); surface.DrawRect(0, 0, w, h) end

        MakeDraggable(div)

        local c1 = vgui.Create("DPanel", parent)

        c1:SetPos(0, 0); c1:SetSize(colW, 9999)

        c1.Paint = function() end

        MakeDraggable(c1)

        local c2 = vgui.Create("DPanel", parent)

        c2:SetPos(divX + 1, 0); c2:SetSize(colW, 9999)

        c2.Paint = function() end

        MakeDraggable(c2)

        local y1 = {padTop}

        local y2 = {padTop}

        return c1, y1, c2, y2

    end


        local function LoadSearchContent(query)

        scroll:Clear()

        local inner = vgui.Create("DPanel", scroll)

        inner:SetPos(0, 0); inner:SetSize(CON_W, FH - HEAD_H)

        inner.Paint = function() end

        MakeDraggable(inner)

        local c1, y1, c2, y2 = Columns(inner)

        local q = string.lower(string.Trim(query or ""))

        local allFeatures = {


            { cat = "Ragebot", name = "Aimbot Master Toggle", cfg = "aimbot_enabled", bind = "bind_aimbot" },

            { cat = "Ragebot", name = "Remove Spread (50/50)", cfg = "nospread_enabled" },

            { cat = "Ragebot", name = "Silent Aim", cfg = "aimbot_silent" },

            { cat = "Ragebot", name = "Auto-Shoot", cfg = "aimbot_auto_shoot" },

            { cat = "Ragebot", name = "Recoil Control (RCS)", cfg = "aimbot_rcs" },

            { cat = "Ragebot", name = "Air-Stop (Halt Air Move)", cfg = "airstop_enabled", bind = "bind_airstop" },


            { cat = "Ragebot", name = "Hit Chance", type = "slider", cfg = "aimbot_hitchance", min = 0, max = 100, dec = 0, suf = "%" },

            { cat = "Ragebot", name = "Hit Chance Override", cfg = "hitchance_override_active", bind = "bind_hitchance_override" },

            { cat = "Ragebot", name = "Triggerbot Master Toggle", cfg = "triggerbot_enabled", bind = "bind_triggerbot" },

            { cat = "Ragebot", name = "Triggerbot Delay", type = "slider", cfg = "triggerbot_delay", min = 0, max = 250, dec = 0, suf = " ms" },

            { cat = "Ragebot", name = "Triggerbot Head Only", cfg = "triggerbot_head_only" },

            { cat = "Movement", name = "Slidewalk (Moonwalk)", cfg = "slidewalk_enabled" },

            { cat = "Misc", name = "Panic Key (Clean Unload)", bind = "bind_panic" },

            { cat = "Ragebot", name = "Head Priority", cfg = "aimbot_head_priority" },

            { cat = "Ragebot", name = "Multipoint Hitscan", cfg = "aimbot_multipoint" },

            { cat = "Ragebot", name = "Multipoint Scale", type = "slider", cfg = "aimbot_multipoint_scale", min = 0.1, max = 1.0, dec = 2, suf = "x" },

            { cat = "Ragebot", name = "Extrapolation", cfg = "aimbot_extrapolation" },

            { cat = "Ragebot", name = "Extrapolation Ticks", type = "slider", cfg = "aimbot_extrapolation_ticks", min = 1, max = 8, dec = 0, suf = " ticks" },

            { cat = "Ragebot", name = "Aimbot FOV", type = "slider", cfg = "aimbot_fov", min = 1, max = 180, dec = 0, suf = "°" },

            { cat = "Ragebot", name = "Min Damage", type = "slider", cfg = "aimbot_min_damage", min = 1, max = 100, dec = 0, suf = " HP" },

            { cat = "Ragebot", name = "Min Damage Override", cfg = "min_damage_override_active", bind = "bind_min_damage_override" },


            { cat = "Anti-Aim", name = "Anti-Aim Master Toggle", cfg = "antiaim_enabled", bind = "bind_antiaim" },

            { cat = "Anti-Aim", name = "Fake Duck", cfg = "fakeduck_enabled", bind = "bind_fakeduck" },

            { cat = "Anti-Aim", name = "Manual Direction Arrows", cfg = "manual_aa_arrows", col = "col_manual_arrows" },

            { cat = "Anti-Aim", name = "Desync Ghost Model", cfg = "desync_ghost_enabled", col = "col_desync_ghost" },


            { cat = "Visuals", name = "Master ESP Wallhack", cfg = "esp_enabled", bind = "bind_esp" },

            { cat = "Visuals", name = "2D Boxes", cfg = "esp_boxes", col = "col_esp_boxes" },

            { cat = "Visuals", name = "Player Names", cfg = "esp_names" },

            { cat = "Visuals", name = "Health Bar", cfg = "esp_health" },

            { cat = "Visuals", name = "3D Skeletons", cfg = "esp_skeletons", col = "col_esp_skeletons" },

            { cat = "Visuals", name = "Snaplines", cfg = "esp_snaplines", col = "col_esp_snaplines" },

            { cat = "Visuals", name = "Offscreen Arrows", cfg = "offscreen_esp_enabled", col = "col_offscreen_esp" },

            { cat = "Visuals", name = "2D Radar", cfg = "radar_enabled", bind = "bind_radar" },

            { cat = "Visuals", name = "Night Mode", cfg = "nightmode_enabled", bind = "bind_nightmode", col = "col_nightmode" },

            { cat = "Visuals", name = "Skybox Modulation", cfg = "skybox_mod_enabled", col = "col_skybox" },

            { cat = "Visuals", name = "Fullbright", cfg = "fullbright_enabled" },

            { cat = "Visuals", name = "World Fog", cfg = "fog_enabled", col = "col_fog" },

            { cat = "Visuals", name = "Ammo Bar ESP", cfg = "esp_ammo", col = "col_esp_ammo" },

            { cat = "Visuals", name = "Prop Transparency", cfg = "prop_transparency_enabled", col = nil },

            { cat = "Visuals", name = "Custom Skybox", cfg = "custom_skybox_enabled" },

            { cat = "Visuals", name = "Grenade Blast Warning", cfg = "grenade_warning_enabled", col = "col_grenade_warning" },

            { cat = "Visuals", name = "Spectator List", cfg = "spectator_list_enabled" },

            { cat = "Visuals", name = "Laser Bullet Tracers", cfg = "bullet_tracers_enabled", col = "col_bullet_tracers" },

            { cat = "Visuals", name = "3D Bullet Impacts", cfg = "bullet_impacts_enabled", col = "col_bullet_impacts" },

            { cat = "Visuals", name = "Grenade Prediction", cfg = "grenade_pred_enabled", col = "col_grenade_pred" },

            { cat = "Visuals", name = "Thirdperson View", cfg = "thirdperson_enabled", bind = "bind_thirdperson" },

            { cat = "Visuals", name = "Thirdperson Distance", type = "slider", cfg = "thirdperson_dist", min = 30, max = 300, dec = 0, suf = " u" },

            { cat = "Visuals", name = "FOV Override", type = "slider", cfg = "fov_changer", min = 75, max = 130, dec = 0, suf = "°" },

            { cat = "Visuals", name = "Draw FOV Ring", cfg = "draw_fov_ring", col = "col_fov_ring" },

            { cat = "Visuals", name = "Aspect Ratio", cfg = "aspect_ratio_enabled" },

            { cat = "Visuals", name = "Viewmodel FOV", type = "slider", cfg = "viewmodel_fov", min = 50, max = 120, dec = 0, suf = "°" },

            { cat = "Visuals", name = "Viewmodel Offset X", type = "slider", cfg = "viewmodel_x", min = -15, max = 15, dec = 1, suf = "" },

            { cat = "Visuals", name = "Viewmodel Offset Y", type = "slider", cfg = "viewmodel_y", min = -15, max = 15, dec = 1, suf = "" },

            { cat = "Visuals", name = "Viewmodel Offset Z", type = "slider", cfg = "viewmodel_z", min = -15, max = 15, dec = 1, suf = "" },


            { cat = "Movement", name = "Auto BunnyHop", cfg = "bhop_enabled", bind = "bind_bhop" },

            { cat = "Movement", name = "Auto Strafer", cfg = "autostrafe_enabled", bind = "bind_autostrafe" },

            { cat = "Movement", name = "Edge Jump", cfg = "edgejump_enabled", bind = "bind_edgejump" },

            { cat = "Movement", name = "Jump Bug", cfg = "jumpbug_enabled", bind = "bind_jumpbug" },

            { cat = "Movement", name = "Edge Bug", cfg = "edgebug_enabled", bind = "bind_edgebug" },

            { cat = "Movement", name = "Crouch Jump", cfg = "crouchjump_enabled", bind = "bind_crouchjump" },

            { cat = "Movement", name = "Peek Assist", cfg = "autopeek_enabled", bind = "bind_autopeek", col = "col_autopeek" },

            { cat = "Movement", name = "Auto Reload", cfg = "autoreload_enabled" },

            { cat = "Misc", name = "Crosshair Hitmarker", cfg = "hitmarker_enabled", col = "col_hitmarker" },

            { cat = "Misc", name = "Floating Damage (-HP)", cfg = "hitmarker_damage_numbers", col = "col_dmg_numbers" },

            { cat = "Misc", name = "Hitsound Audio", cfg = "hitsound_enabled" },

            { cat = "Misc", name = "Kill Effect", cfg = "killeffect_enabled", col = "col_killeffect" },

            { cat = "Misc", name = "HvH Killsay Trash-Talk", cfg = "killsay_enabled" },

            { cat = "Misc", name = "Watermark HUD", cfg = "watermark_enabled" },

            { cat = "Misc", name = "Keybinds HUD", cfg = "keybinds_list_enabled" }

        }

        local matchCount = 0

        Section(c1, "SEARCH RESULTS (COL 1)", y1)

        Section(c2, "SEARCH RESULTS (COL 2)", y2)

        for _, feat in ipairs(allFeatures) do

            local fName = string.lower(feat.name)

            local fCat = string.lower(feat.cat)

            if string.find(fName, q, 1, true) or string.find(fCat, q, 1, true) then

                matchCount = matchCount + 1

                local colPnl = (matchCount % 2 == 1) and c1 or c2

                local colY = (matchCount % 2 == 1) and y1 or y2

                if feat.type == "slider" then

                    Slider(colPnl, "[" .. feat.cat .. "] " .. feat.name, feat.cfg, feat.min, feat.max, feat.dec, feat.suf, colY)

                else

                    Row(colPnl, "[" .. feat.cat .. "] " .. feat.name, feat.cfg, feat.bind, feat.col, nil, colY)

                end

            end

        end

        if matchCount == 0 then

            local emptyPnl = vgui.Create("DPanel", scroll)

            emptyPnl:SetPos(14, 20); emptyPnl:SetSize(CON_W - 28, 60)

            emptyPnl.Paint = function(self, w, h)

                draw.SimpleText("No matching features found for '" .. query .. "'", "DermaDefaultBold", w/2, h/2, TEXT_MUT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            end

        end

        local maxH = math.max(y1[1], y2[1]) + 20

        inner:SetSize(CON_W, math.max(maxH, FH - HEAD_H))

        c1:SetSize(c1:GetWide(), maxH)

        c2:SetSize(c2:GetWide(), maxH)

        scroll:GetCanvas():SetTall(maxH)

        scroll:InvalidateLayout(true)

    end

LoadTabContent = function(tabId)

        scroll:Clear()

        local inner = vgui.Create("DPanel", scroll)

        inner:SetPos(0, 0); inner:SetSize(CON_W, FH - HEAD_H)

        inner.Paint = function() end

        MakeDraggable(inner)

        local c1, y1, c2, y2 = Columns(inner)

        if tabId == 1 then

            Section(c1, "AIM", y1)

            Row(c1, "Enabled",             "aimbot_enabled",       "bind_aimbot",   nil, function() LoadTabContent(1) end, y1)

            if Garrylose.Config.aimbot_enabled then

                Row(c1, "Silent Aim",          "aimbot_silent",        nil,             nil, y1)

                Row(c1, "Auto Fire",           "aimbot_auto_shoot",    nil,             nil, y1)

                Row(c1, "Remove Spread (50/50)","nospread_enabled",     nil,             nil, y1)

                Row(c1, "Visible Check",       "aimbot_vischeck",      nil,             nil, y1)

                Slider(c1, "Field of View",    "aimbot_fov",           1, 180, 0, "°",  y1)

                Row(c1, "FOV Circle",          "draw_fov_ring",        nil, "col_fov_ring", nil, y1)

                Section(c1, "SELECTION", y1)

                Row(c1, "Target Players",      "aimbot_target_players",nil, nil, y1)

                Row(c1, "Head Priority",       "aimbot_head_priority", nil, nil, function() LoadTabContent(1) end, y1)

                if Garrylose.Config.aimbot_head_priority then

                    Slider(c1, "Head Aim Ticks",   "aimbot_lock_ticks",    1, 8, 0, " Ticks", y1)

                end

                Row(c1, "Hitbox: Head",        "aimbot_hitbox_head",   nil, nil, y1)

                Row(c1, "Hitbox: Chest",       "aimbot_hitbox_chest",  nil, nil, y1)

                Row(c1, "Hitbox: Stomach",     "aimbot_hitbox_stomach",nil, nil, y1)

                Row(c1, "Multipoint",          "aimbot_multipoint",    nil, nil, function() LoadTabContent(1) end, y1)

                if Garrylose.Config.aimbot_multipoint then

                    Slider(c1, "Multipoint Scale", "aimbot_multipoint_scale", 0.1, 1.0, 2, "x", y1)

                end

                Row(c1, "Extrapolation",       "aimbot_extrapolation", nil, nil, function() LoadTabContent(1) end, y1)

                if Garrylose.Config.aimbot_extrapolation then

                    Slider(c1, "Extrap Ticks",     "aimbot_extrapolation_ticks", 1, 8, 0, " t", y1)

                end

                Slider(c1, "Min Damage",       "aimbot_min_damage",    1, 100, 0, " HP", y1)

                Row(c1, "Min Damage Override", "min_damage_override_active", "bind_min_damage_override", nil, function() LoadTabContent(1) end, y1)

                if Garrylose.Config.min_damage_override_active then

                    Slider(c1, "Override Value",   "aimbot_min_damage_override", 1, 100, 0, " HP", y1)

                end

                Row(c1, "Enable Hit Chance",   "hitchance_enabled",    nil, nil, function() LoadTabContent(1) end, y1)

                if Garrylose.Config.hitchance_enabled then

                    Slider(c1, "Hit Chance",       "aimbot_hitchance",     0, 100, 0, "%",   y1)

                    Row(c1, "HC Override",         "hitchance_override_active", "bind_hitchance_override", nil, function() LoadTabContent(1) end, y1)

                    if Garrylose.Config.hitchance_override_active then

                        Slider(c1, "HC Override Val",  "aimbot_hitchance_override", 0, 100, 0, "%", y1)

                    end

                end

            end

            Section(c2, "ACCURACY & STOPS", y2)

            Row(c2, "Air-Stop",            "airstop_enabled",      "bind_airstop",  nil, y2)


            Row(c2, "Recoil Compensation", "aimbot_rcs",           nil,             nil, y2)

            Row(c2, "Peek Assist",         "autopeek_enabled",     "bind_autopeek", "col_autopeek", function() LoadTabContent(1) end, y2)

            if Garrylose.Config.autopeek_enabled then

                Combo(c2, "Return Trigger", {

                    { label = "On Shot",          data = 1 },

                    { label = "On Movement End",  data = 2 },

                    { label = "Shot & Move End",  data = 3 },

                }, "autopeek_return_mode", nil, y2)

            end

            Section(c2, "TRIGGERBOT", y2)

            Row(c2, "Enable Triggerbot",   "triggerbot_enabled",   "bind_triggerbot", nil, function() LoadTabContent(1) end, y2)

            if Garrylose.Config.triggerbot_enabled then

                Slider(c2, "Trigger Delay",    "triggerbot_delay",     0, 250, 0, " ms", y2)

                Row(c2, "Head Only",           "triggerbot_head_only", nil, nil, y2)

            end

            Section(c2, "BURST & FIRE", y2)

            Combo(c2, "Shoot Mode",        {

                { label = "Rapid Pulse",  data = 2 },

                { label = "Hold",         data = 1 }

            }, "aimbot_shoot_mode", nil, y2)

            Row(c2, "Target NPCs",         "aimbot_target_npcs",   nil, nil, y2)

            Row(c2, "Team Check",          "aimbot_team_check",    nil, nil, y2)

        elseif tabId == 2 then

            Section(c1, "ANTI-AIM", y1)

            Row(c1, "Enabled",             "antiaim_enabled",       "bind_antiaim", nil, function() LoadTabContent(2) end, y1)

            if Garrylose.Config.antiaim_enabled then

                Combo(c1, "Pitch",             {

                    { label = "None (Look Dir)", data = 0 },

                    { label = "Down (-89°)",     data = 1 },

                    { label = "Up  (+89°)",      data = 2 },

                    { label = "Jitter Pitch",    data = 3 },

                    { label = "Random Jitter",   data = 4 },

                }, "antiaim_pitch", function() LoadTabContent(2) end, y1)

                local pMode = tonumber(Garrylose.Config.antiaim_pitch) or 1

                if pMode == 3 or pMode == 4 then

                    Slider(c1, "Pitch Jitter Angle", "antiaim_pitch_jitter_angle", 1, 89, 0, "°", y1)

                end

                Combo(c1, "Yaw",               {

                    { label = "Backward (180°)", data = 1 },

                    { label = "Spinbot",         data = 2 },

                    { label = "Jitter",          data = 3 },

                    { label = "Random Jitter",   data = 4 },

                }, "antiaim_yaw", function() LoadTabContent(2) end, y1)

                local yawMode = tonumber(Garrylose.Config.antiaim_yaw) or 1

                if yawMode == 2 then

                    Slider(c1, "Spinbot Speed",    "antiaim_spin_speed",    50, 2500, 0, " °/s", y1)

                end

                if yawMode == 3 or yawMode == 4 then

                    Slider(c1, "Jitter Angle",     "antiaim_jitter_angle",  1, 360, 0, "°", y1)

                    Combo(c1, "Jitter Side",       {

                        { label = "Backward (+180°)", data = 1 },

                        { label = "Forward (0°)",     data = 2 },

                    }, "antiaim_jitter_side", nil, y1)

                end

                Row(c1, "Direction Arrows (HUD)","manual_aa_arrows",    nil, "col_manual_arrows", nil, y1)

                Section(c2, "MANUAL OVERRIDES", y2)

                Row(c2, "Manual Left",  nil, "bind_manual_left",  nil, y2)

                Row(c2, "Manual Right", nil, "bind_manual_right", nil, y2)

                Row(c2, "Manual Back  (180°)", nil, "bind_manual_back",  nil, y2)

                Section(c2, "DESYNC VISUALS", y2)

                Row(c2, "Desync Ghost (Real)", "desync_ghost_enabled", nil, "col_desync_ghost", function() LoadTabContent(2) end, y2)

                if Garrylose.Config.desync_ghost_enabled then

                    Combo(c2, "Ghost Material", {

                        { label = "Flat Glow (Chams)", data = 1 },

                        { label = "Wireframe Mesh",    data = 2 }

                    }, "desync_ghost_mat", nil, y2)

                end
            end

        elseif tabId == 3 then

            Section(c1, "ESP (OVERLAY)", y1)

            Row(c1, "Enable ESP",          "esp_enabled",           "bind_esp",          nil, function() LoadTabContent(3) end, y1)

            if Garrylose.Config.esp_enabled then

                Row(c1, "2D Boxes",            "esp_boxes",             nil,                 "col_esp_boxes",     nil, y1)

                Row(c1, "Player Names",        "esp_names",             nil,                 "col_esp_names",     nil, y1)

                Row(c1, "Health Bar",          "esp_health",            nil,                 "col_esp_health",    nil, y1)

                Row(c1, "Ammo Bar",            "esp_ammo",              nil,                 "col_esp_ammo",      nil, y1)

                Row(c1, "Skeleton ESP",        "esp_skeleton",          nil,                 "col_esp_skeleton",  nil, y1)

                Row(c1, "Player Trails",       "esp_trail",             nil,                 "col_esp_trail", nil, y1)

                Row(c1, "Jump Circles",        "jump_circles",          nil,                 "col_jump_circles", nil, y1)

                Row(c1, "Box Fill",            "esp_box_fill",          nil,                 "col_esp_box_fill", nil, y1)

                Row(c1, "Weapon Info",         "esp_weapon_info",       nil,                 "col_esp_weapon",    nil, y1)

                Row(c1, "Glow Bloom Outline",  "glow_esp_enabled",      nil,                 "col_glow_esp",      nil, y1)

                Row(c1, "Offscreen Arrows",    "offscreen_esp_enabled", nil,                 "col_offscreen_esp", function() LoadTabContent(3) end, y1)

                if Garrylose.Config.offscreen_esp_enabled then

                    Slider(c1, "Arrow Distance",   "offscreen_esp_radius",  100, 450, 0, " px", y1)

                    Slider(c1, "Arrow Size",       "offscreen_esp_size",    8, 24, 0, " px", y1)

                end

                Row(c1, "Snaplines",           "esp_snaplines",         nil,                 "col_esp_snaplines", nil, y1)

                Row(c1, "Grenade Warning",     "grenade_warning_enabled", nil,               "col_grenade_warning", nil, y1)

                Row(c1, "Grenade Prediction",  "grenade_pred_enabled",  nil,                 "col_grenade_pred", nil, y1)

                Row(c1, "Spectator List",      "spectator_list_enabled", nil,                nil,                 nil, y1)

                Section(c1, "CHAMS", y1)

                Row(c1, "Player Chams",        "chams_player",          nil,                 "col_chams_player", nil, y1)

                Row(c1, "NPC Chams",           "chams_npc",             nil,                 "col_chams_npc", nil, y1)

                Row(c1, "Self Chams",          "chams_self",            nil,                 "col_chams_self", nil, y1)

                Row(c1, "Hands Chams",         "chams_hands",           nil,                 "col_chams_hands", nil, y1)

            end

            Section(c1, "WORLD", y1)

            Row(c1, "World Modulation",    "worldmod",              nil,                 "col_worldmod", nil, y1)

            Row(c1, "Custom Fog",          "fog_enabled",           nil,                 "col_fog", function() LoadTabContent(3) end, y1)

            if Garrylose.Config.fog_enabled then

                Slider(c1, "Fog Start",        "fog_start",             0, 5000, 0, " u", y1)

                Slider(c1, "Fog End",          "fog_end",               0, 10000, 0, " u", y1)

            end

            Section(c1, "VIEWMODEL OFFSETS", y1)

            Slider(c1, "Viewmodel FOV", "viewmodel_fov",        50, 120, 0, "°",     y1)

            Slider(c1, "Offset X (L/R)","viewmodel_x",          -15, 15, 1, "",      y1)

            Slider(c1, "Offset Y (F/B)","viewmodel_y",          -15, 15, 1, "",      y1)

            Slider(c1, "Offset Z (U/D)","viewmodel_z",          -15, 15, 1, "",      y1)

            Section(c1, "VIEWMODEL ANGLES", y1)

            Slider(c1, "View Pitch",    "viewmodel_pitch",       -180, 180, 0, "°",   y1)

            Slider(c1, "View Yaw",      "viewmodel_yaw",         -180, 180, 0, "°",   y1)

            Slider(c1, "View Roll",     "viewmodel_roll",        -180, 180, 0, "°",   y1)

            Section(c2, "WORLD & PROPS", y2)

            Row(c2, "Night Mode",          "nightmode_enabled",    "bind_nightmode",    "col_nightmode", function() LoadTabContent(3) end, y2)

            if Garrylose.Config.nightmode_enabled then

                Slider(c2, "Night Darkness",   "nightmode_darkness",   0.1, 0.9, 2, "x",    y2)

            end

            Row(c2, "Skybox Modulation",   "skybox_mod_enabled",   nil,                 "col_skybox",        nil, y2)

            Row(c2, "Custom Skybox",       "custom_skybox_enabled",nil,                 nil, function() LoadTabContent(3) end, y2)

            if Garrylose.Config.custom_skybox_enabled then

                Combo(c2, "Sky Theme",         {

                    { label = "Deep Space Galaxy",  data = 1 },

                    { label = "Midnight Starry",    data = 2 },

                    { label = "Sunset Crimson",     data = 3 },

                    { label = "Cyberpunk Violet",   data = 4 },

                    { label = "Void Black",         data = 5 }

                }, "custom_skybox_type", nil, y2)

            end

            Row(c2, "Prop Transparency",   "prop_transparency_enabled", nil,            nil, function() LoadTabContent(3) end, y2)

            if Garrylose.Config.prop_transparency_enabled then

                Combo(c2, "Prop Style",        {

                    { label = "Translucent Alpha", data = 1 },

                    { label = "Wireframe Mesh",    data = 2 }

                }, "prop_transparency_mode", nil, y2)

                Slider(c2, "Prop Alpha",       "prop_alpha",           10, 255, 0, "",      y2)

            end

            Row(c2, "Fullbright",          "fullbright_enabled",   nil,                 nil,                 nil, y2)

            Row(c2, "World Fog",           "fog_enabled",          nil,                 "col_fog", function() LoadTabContent(3) end, y2)

            if Garrylose.Config.fog_enabled then

                Slider(c2, "Fog Density",      "fog_density",          500, 5000, 0, " u",  y2)

            end

            Section(c2, "BULLET VISUALS", y2)

            Row(c2, "Laser Bullet Tracers","bullet_tracers_enabled",nil,                 "col_bullet_tracers", nil, y2)

            Row(c2, "3D Bullet Impacts",   "bullet_impacts_enabled",nil,                 "col_bullet_impacts",nil, y2)

            Section(c2, "RADAR (MINIMAP)", y2)

            Row(c2, "Enable Radar",        "radar_enabled",         "bind_radar",       nil, function() LoadTabContent(3) end, y2)

            if Garrylose.Config.radar_enabled then

                Combo(c2, "Target Filter",     {

                    { label = "Players & NPCs", data = 1 },

                    { label = "Only Players",   data = 2 },

                    { label = "Only NPCs",      data = 3 },

                }, "radar_target_mode", nil, y2)

                Row(c2, "Player Blips Color",  nil,                     nil,                "col_radar_players", nil, y2)

                Row(c2, "NPC Blips Color",     nil,                     nil,                "col_radar_npcs",    nil, y2)

                Slider(c2, "Radar Range",      "radar_range",           500, 6000, 0, " u", y2)

                Slider(c2, "Radar Size",       "radar_size",            100, 240, 0, " px", y2)

            end

            Section(c2, "CAMERA & VIEW", y2)

            Row(c2, "Thirdperson View", "thirdperson_enabled",  "bind_thirdperson",  nil, function() LoadTabContent(3) end, y2)

            if Garrylose.Config.thirdperson_enabled then

                Slider(c2, "TP Distance",   "thirdperson_dist",     30, 300, 0, " u",    y2)

            end

            Slider(c2, "FOV Override",  "fov_changer",          75, 130, 0, "°",     y2)

            Row(c2, "Draw FOV Ring",    "draw_fov_ring",        nil,                 "col_fov_ring",     nil, y2)

            Section(c2, "SCREEN RATIO", y2)

            Row(c2, "Aspect Ratio",     "aspect_ratio_enabled", nil,                 nil, function() LoadTabContent(3) end, y2)

            if Garrylose.Config.aspect_ratio_enabled then

                Slider(c2, "Ratio Value",   "aspect_ratio_val",     0.8, 2.5, 2, "x",    y2)

            end

        elseif tabId == 4 then

            Section(c1, "MOVEMENT", y1)

            Row(c1, "Auto BunnyHop",    "bhop_enabled",          "bind_bhop",        nil, y1)

            Row(c1, "Auto Strafer",     "autostrafe_enabled",    "bind_autostrafe",  nil, function() LoadTabContent(4) end, y1)

            if Garrylose.Config.autostrafe_enabled then

                Combo(c1, "Strafer Mode",   {

                    { label = "Mouse Delta", data = 1 },

                    { label = "Directional",data = 2 },

                }, "autostrafe_mode", nil, y1)

            end

            Row(c1, "Edge Jump",        "edgejump_enabled",      "bind_edgejump",    nil, y1)

            Row(c1, "Jump Bug",         "jumpbug_enabled",       "bind_jumpbug",     nil, function() LoadTabContent(4) end, y1)

            if Garrylose.Config.jumpbug_enabled then
                Combo(c1, "Mode", {
                    { label = "No Fall Damage", data = 1 },
                    { label = "Always On", data = 2 }
                }, "jumpbug_mode", nil, y1)
            end

            Row(c1, "Edge Bug",         "edgebug_enabled",       "bind_edgebug",     nil, y1)

            Row(c1, "Slidewalk (Moonwalk)","slidewalk_enabled",  nil,                nil, y1)

            Row(c1, "Fake Duck",        "fakeduck_enabled",      "bind_fakeduck",    nil, y1)

            Row(c1, "Crouch Jump",      "crouchjump_enabled",    "bind_crouchjump",  nil, function() LoadTabContent(4) end, y1)

            if Garrylose.Config.crouchjump_enabled then

                Combo(c1, "Crouch Style", {

                    { label = "Hold (Зажимать)", data = 1 },

                    { label = "Spam (Спамить)",   data = 2 },

                }, "crouchjump_mode", nil, y1)

            end

            Row(c1, "Peek Assist",      "autopeek_enabled",      "bind_autopeek",    "col_autopeek", function() LoadTabContent(4) end, y1)

            if Garrylose.Config.autopeek_enabled then

                Combo(c1, "Return Trigger", {

                    { label = "On Shot",          data = 1 },

                    { label = "On Movement End",  data = 2 },

                    { label = "Shot & Move End",  data = 3 },

                }, "autopeek_return_mode", nil, y1)

            end

            Row(c1, "Auto Reload",      "autoreload_enabled",    nil,                nil, y1)

            Section(c2, "HIT FEEDBACK", y2)

            Row(c2, "Crosshair Hitmarker", "hitmarker_enabled",        nil, "col_hitmarker",   nil, y2)

            Row(c2, "Floating Damage",     "hitmarker_damage_numbers", nil, "col_dmg_numbers", nil, y2)

            Row(c2, "Hitsound Audio",      "hitsound_enabled",         nil, nil, function() LoadTabContent(4) end, y2)

            if Garrylose.Config.hitsound_enabled then

                Combo(c2, "Hitsound Preset", Garrylose.GetHitsoundOptions(), "hitsound_type", function(val)

                    Garrylose.PlayCurrentHitsound()

                end, y2)

                Slider(c2, "Hitsound Volume", "hitsound_volume", 0, 1000, 0, "%", y2)

                Note(c2, "garrysmod/data/GLsounds/", y2)

            end

            Section(c2, "HVH SPECIALS", y2)

            Row(c2, "Kill Effect",             "killeffect_enabled", nil, "col_killeffect", function() LoadTabContent(4) end, y2)

            if Garrylose.Config.killeffect_enabled then

                Combo(c2, "Effect Type", {

                    { label = "Tesla Lightning",   data = 1 },

                    { label = "Plasma Explosion",  data = 2 },

                    { label = "Blood Burst",       data = 3 },

                    { label = "Energy Wave",       data = 4 },

                }, "killeffect_type", nil, y2)

            end

            Row(c2, "HvH Killsay Trash-Talk", "killsay_enabled", nil, nil, y2)

            Section(c2, "DISPLAY HUD", y2)

            Row(c2, "Watermark HUD",    "watermark_enabled",     nil, nil, y2)

            Row(c2, "Keybinds HUD",     "keybinds_list_enabled", nil, nil, y2)
            
            Row(c2, "Auto Reload",      "auto_reload",           nil, nil, y2)

            Row(c2, "Flashlight Spam",  "flash_spam",            nil, nil, y2)

            Row(c2, "Chat Spammer",     "chat_spam",             nil, nil, y2)

            Section(c2, "FREECAM", y2)

            Row(c2, "Freecam", "freecam_enabled", "bind_freecam", nil, function() LoadTabContent(4) end, y2)

            if Garrylose.Config.freecam_enabled then

                Slider(c2, "Freecam Speed", "freecam_speed",         1, 100, 0, "x", y2)

            end

            Section(c2, "SPECIAL", y2)

            Row(c2, "Nothing", "nothing_enabled", "bind_nothing", nil, y2)
            
            Section(c2, "SYSTEM", y2)


            local mbLbl = vgui.Create("DPanel", c2)

            mbLbl:SetPos(0, y2[1]); mbLbl:SetSize(c2:GetWide(), 18)

            mbLbl.Paint = function(self, w, h)

                draw.SimpleText("Menu Keybind", "DermaDefault", 14, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            end

            MakeDraggable(mbLbl)

            y2[1] = y2[1] + 20

            local mbBind = vgui.Create("DBinder", c2)

            mbBind:SetPos(14, y2[1]); mbBind:SetSize(c2:GetWide() - 28, 22)

            mbBind:SetSelectedNumber(Garrylose.Config.bind_menu or KEY_INSERT)

            mbBind.OnChange = function(self, n) Garrylose.Config.bind_menu = n end

            mbBind.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsHovered() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                local k = GetKeyName(self:GetSelectedNumber())

                draw.SimpleText(self.Trapping and "[ ... ]" or "[ "..k.." ]", "DermaDefaultBold", w/2, h/2, self.Trapping and ACCENT or TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

            end

            y2[1] = y2[1] + 28

            Row(c2, "Panic Unload Key", nil, "bind_panic", nil, y2)

            Btn(c2, "Panic Unload Now", C_RED, function()

                if Garrylose.PanicUnload then Garrylose.PanicUnload() end

            end, y2)

            Btn(c2, "Reset to Default", C_RED, function()

                Garrylose.Config.aimbot_enabled=true; Garrylose.Config.aimbot_fov=90

                Garrylose.Config.aimbot_silent=true;  Garrylose.Config.aimbot_rcs=true

                Garrylose.Config.esp_enabled=true;    Garrylose.Config.bhop_enabled=true

                Garrylose.Config.hitsound_enabled=true; Garrylose.Config.hitmarker_enabled=true

                Garrylose.Config.aspect_ratio_enabled=false

                notification.AddLegacy("Garrylose: reset to defaults!", NOTIFY_HINT, 3)

                LoadTabContent(4)

            end, y2)

        elseif tabId == 5 then

            Section(c1, "PROFILES", y1)

            local cfgIn = vgui.Create("DTextEntry", c1)

            cfgIn:SetPos(14, y1[1]); cfgIn:SetSize(c1:GetWide() - 28, 24)

            cfgIn:SetValue("default"); cfgIn:SetTextColor(TEXT)

            cfgIn.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                self:DrawTextEntryText(TEXT, ACCENT, TEXT)

            end

            y1[1] = y1[1] + 30

            local cfgList = vgui.Create("DListView", c1)

            cfgList:SetPos(14, y1[1]); cfgList:SetSize(c1:GetWide() - 28, 280)

            cfgList:SetMultiSelect(false)

            local col_ = cfgList:AddColumn("Config Files")

            col_.Header:SetTextColor(TEXT_MUT)

            cfgList.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)

            end

            local function RefreshList()

                cfgList:Clear()

                local files = file.Find("GLcfg/*.json", "DATA") or {}
                local seen = {}
                for _, fn in ipairs(files) do
                    seen[fn] = true
                    local ln = cfgList:AddLine(fn)
                    ln.Paint = function(self, lw, lh)
                        if self:IsSelected() then
                            draw.RoundedBox(2, 0, 0, lw, lh, ACCENT_DIM)
                            surface.SetDrawColor(ACCENT); surface.DrawOutlinedRect(0, 0, lw, lh)
                        elseif self:IsHovered() then
                            draw.RoundedBox(2, 0, 0, lw, lh, ITEM_BG)
                        end
                    end
                    for _, cell in pairs(ln.Columns) do cell:SetTextColor(TEXT) end
                end

                local legacyFiles = file.Find("garrylose_configs/*.json", "DATA") or {}
                for _, fn in ipairs(legacyFiles) do
                    if not seen[fn] then
                        local ln = cfgList:AddLine(fn)
                        ln.Paint = function(self, lw, lh)
                            if self:IsSelected() then
                                draw.RoundedBox(2, 0, 0, lw, lh, ACCENT_DIM)
                                surface.SetDrawColor(ACCENT); surface.DrawOutlinedRect(0, 0, lw, lh)
                            elseif self:IsHovered() then
                                draw.RoundedBox(2, 0, 0, lw, lh, ITEM_BG)
                            end
                        end
                        for _, cell in pairs(ln.Columns) do cell:SetTextColor(TEXT) end
                    end
                end

            end

            cfgList.OnRowSelected = function(lst, index, pnl)
                local cfgName = pnl:GetValue(1)
                cfgIn:SetValue(string.Replace(cfgName, ".json", ""))
            end

            RefreshList(); y1[1] = y1[1] + 288

            Section(c2, "ACTIONS", y2)

            Btn(c2, "Save Config",   ACCENT,   function() Garrylose.SaveConfig(cfgIn:GetValue()); RefreshList() end, y2)

            Btn(c2, "Load Config",   C_GREEN,  function()

                local sel = cfgList:GetSelectedLine()

                Garrylose.LoadConfig(sel and cfgList:GetLine(sel):GetValue(1) or cfgIn:GetValue())

            end, y2)

            Btn(c2, "Delete Config", C_RED,    function()

                local sel = cfgList:GetSelectedLine()

                if sel then Garrylose.DeleteConfig(cfgList:GetLine(sel):GetValue(1)); RefreshList() end

            end, y2)

            Section(c2, "CONFIGS DIRECTORY", y2)

            Note(c2, "garrysmod/data/GLcfg/", y2)

        elseif tabId == 6 then

            EnsureDefaultScripts()

            Section(c1, "SAVED SCRIPTS (ПКМ: Меню)", y1)

            local scriptList = vgui.Create("DListView", c1)

            scriptList:SetPos(14, y1[1]); scriptList:SetSize(c1:GetWide() - 28, 160)

            scriptList:SetMultiSelect(false)

            local col1 = scriptList:AddColumn("Script Name")

            local col2 = scriptList:AddColumn("Auto-Load")

            col1:SetFixedWidth(145)

            col2:SetFixedWidth(65)

            col1.Header:SetTextColor(TEXT_MUT)

            col2.Header:SetTextColor(TEXT_MUT)

            scriptList.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)

            end

            local function RefreshScriptList()

                scriptList:Clear()

                EnsureDefaultScripts()

                local files = file.Find("garrylose_scripts/*.txt", "DATA") or {}

                for _, fn in ipairs(files) do

                    local cleanName = string.StripExtension(fn)

                    local isAuto = Garrylose.IsScriptAutoLoad(fn)

                    local autoText = isAuto and "[ON]" or "[OFF]"

                    local ln = scriptList:AddLine(cleanName, autoText)

                    ln.FileName = fn

                    ln.IsAuto = isAuto

                    ln.Paint = function(self, lw, lh)

                        if self:IsSelected() then

                            draw.RoundedBox(2, 0, 0, lw, lh, ACCENT_DIM)

                            surface.SetDrawColor(ACCENT); surface.DrawOutlinedRect(0, 0, lw, lh)

                        elseif self:IsHovered() then

                            draw.RoundedBox(2, 0, 0, lw, lh, ITEM_BG)

                        end

                    end

                    if ln.Columns[1] then ln.Columns[1]:SetTextColor(TEXT) end

                    if ln.Columns[2] then ln.Columns[2]:SetTextColor(isAuto and C_GREEN or TEXT_MUT) end

                end

            end

            RefreshScriptList()

            y1[1] = y1[1] + 168


            scriptList.OnRowRightClick = function(panel, rowIndex, row)

                local fn = row.FileName or (row:GetValue(1) .. ".txt")

                local cleanName = row:GetValue(1)

                local isAuto = Garrylose.IsScriptAutoLoad(fn)

                local menu = DermaMenu()

                if isAuto then

                    menu:AddOption("Убрать из авто-загрузки", function()

                        Garrylose.SetScriptAutoLoad(fn, false)

                        notification.AddLegacy("Garrylose: '" .. cleanName .. "' убран из авто-загрузки", NOTIFY_GENERIC, 3)

                        RefreshScriptList()

                    end):SetIcon("icon16/cross.png")

                else

                    menu:AddOption("Добавить в авто-загрузку", function()

                        Garrylose.SetScriptAutoLoad(fn, true)

                        notification.AddLegacy("Garrylose: '" .. cleanName .. "' добавлен в авто-загрузку", NOTIFY_HINT, 3)

                        RefreshScriptList()

                    end):SetIcon("icon16/tick.png")

                end

                menu:AddSpacer()

                menu:AddOption("Запустить скрипт (Execute)", function()

                    local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                    if code and code ~= "" then

                        RunString(code, "Garrylose_" .. fn)

                        notification.AddLegacy("[Garrylose] Executed: " .. cleanName, NOTIFY_GENERIC, 3)

                        LoadTabContent(6)

                    end

                end):SetIcon("icon16/control_play.png")

                menu:AddOption("Загрузить в редактор", function()

                    local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                    if code then

                        if editor and IsValid(editor) then editor:SetValue(code) end

                        if nameIn and IsValid(nameIn) then nameIn:SetValue(cleanName) end

                    end

                end):SetIcon("icon16/page_edit.png")

                menu:AddSpacer()

                menu:AddOption("Удалить файл", function()

                    file.Delete("garrylose_scripts/" .. fn)

                    Garrylose.SetScriptAutoLoad(fn, false)

                    notification.AddLegacy("[Garrylose] Deleted: " .. cleanName, NOTIFY_CLEANUP, 3)

                    RefreshScriptList()

                end):SetIcon("icon16/delete.png")

                menu:Open()

            end

            Btn(c1, "Run Selected", C_GREEN, function()

                local sel = scriptList:GetSelectedLine()

                if sel then

                    local ln = scriptList:GetLine(sel)

                    local fn = ln.FileName or (ln:GetValue(1) .. ".txt")

                    local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                    if code and code ~= "" then

                        RunString(code, "Garrylose_" .. fn)

                        notification.AddLegacy("[Garrylose] Executed " .. ln:GetValue(1), NOTIFY_GENERIC, 3)

                        LoadTabContent(6)

                    end

                end

            end, y1)

            Btn(c1, "Delete Script File", C_RED, function()

                local sel = scriptList:GetSelectedLine()

                if sel then

                    local ln = scriptList:GetLine(sel)

                    local fn = ln.FileName or (ln:GetValue(1) .. ".txt")

                    file.Delete("garrylose_scripts/" .. fn)

                    Garrylose.SetScriptAutoLoad(fn, false)

                    notification.AddLegacy("[Garrylose] Deleted " .. ln:GetValue(1), NOTIFY_CLEANUP, 3)

                    RefreshScriptList()

                end

            end, y1)

            Section(c1, "ACTIVE PLUGINS", y1)

            local hasPlugins = false

            for id, plugin in pairs(Garrylose.Plugins) do

                hasPlugins = true

                Row(c1, plugin.name or id, nil, nil, nil, function()

                    plugin.enabled = not plugin.enabled

                end, y1)

            end

            if not hasPlugins then

                local emptyLbl = vgui.Create("DPanel", c1)

                emptyLbl:SetPos(14, y1[1]); emptyLbl:SetSize(c1:GetWide() - 28, 22)

                emptyLbl.Paint = function(self, w, h)

                    draw.SimpleText("No active custom plugins", "DefaultFixed", 0, h/2, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                end

                MakeDraggable(emptyLbl)

                y1[1] = y1[1] + 26

            end

            Btn(c1, "Unload All Plugins", C_RED, function()

                Garrylose.Plugins = {}

                notification.AddLegacy("[Garrylose] All custom plugins unloaded!", NOTIFY_CLEANUP, 3)

                LoadTabContent(6)

            end, y1)

            Section(c2, "SCRIPT NAME", y2)

            local nameIn = vgui.Create("DTextEntry", c2)

            nameIn:SetPos(14, y2[1]); nameIn:SetSize(c2:GetWide() - 28, 22)

            nameIn:SetValue("my_script"); nameIn:SetTextColor(TEXT)

            nameIn.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                self:DrawTextEntryText(TEXT, ACCENT, TEXT)

            end

            y2[1] = y2[1] + 28

            Section(c2, "LUA CODE EDITOR", y2)

            local editor = vgui.Create("DTextEntry", c2)

            editor:SetPos(14, y2[1]); editor:SetSize(c2:GetWide() - 28, 175)

            editor:SetMultiline(true); editor:SetTextColor(TEXT)

            editor:SetValue(defaultRainbowCode)

            editor.Paint = function(self, w, h)

                draw.RoundedBox(3, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(self:IsEditing() and ACCENT or BORDER)

                surface.DrawOutlinedRect(0, 0, w, h)

                self:DrawTextEntryText(TEXT, ACCENT, TEXT)

            end

            y2[1] = y2[1] + 182


            scriptList.OnRowSelected = function(panel, rowIndex, row)

                local fn = row.FileName or (row:GetValue(1) .. ".txt")

                local code = file.Read("garrylose_scripts/" .. fn, "DATA")

                if code then

                    editor:SetValue(code)

                    nameIn:SetValue(row:GetValue(1))

                end

            end

            Btn(c2, "Execute (Run Now)", ACCENT, function()

                local code = editor:GetValue()

                if code ~= "" then

                    RunString(code, "GarryloseIDE")

                    notification.AddLegacy("[Garrylose] Script executed!", NOTIFY_GENERIC, 3)

                    LoadTabContent(6)

                end

            end, y2)

            Btn(c2, "Save Script to List", C_GREEN, function()

                file.CreateDir("garrylose_scripts")

                local rawName = string.Trim(nameIn:GetValue())

                if rawName == "" then rawName = "script_" .. os.time() end

                rawName = string.StripExtension(rawName)

                local fileName = rawName .. ".txt"

                file.Write("garrylose_scripts/" .. fileName, editor:GetValue())

                notification.AddLegacy("[Garrylose] Saved: " .. rawName, NOTIFY_HINT, 3)

                RefreshScriptList()

            end, y2)

        elseif tabId == 7 then

            Section(c1, "UI THEME & STYLE", y1)

            Combo(c1, "Color Mode", {

                { label = "Dark Theme (Default)", data = 1 },

                { label = "Light Theme (White)",   data = 2 },

            }, "ui_style", function() Garrylose.OpenMenu() end, y1)

            Combo(c1, "Accent Preset", {

                { label = "Cyan Blue (Neverlose)", data = 1 },

                { label = "Crimson Red",           data = 2 },

                { label = "Purple Violet",         data = 3 },

                { label = "Emerald Green",         data = 4 },

                { label = "Gold Orange",           data = 5 },

                { label = "Hot Pink",              data = 6 },

            }, "menu_theme", function() Garrylose.OpenMenu() end, y1)


            local themeChips = {

                { id = 1, col = Color(0, 180, 255) },

                { id = 2, col = Color(245, 55, 75) },

                { id = 3, col = Color(175, 75, 255) },

                { id = 4, col = Color(40, 215, 120) },

                { id = 5, col = Color(255, 165, 0) },

                { id = 6, col = Color(255, 60, 160) },

            }

            local chipPnl = vgui.Create("DPanel", c1)

            chipPnl:SetPos(14, y1[1]); chipPnl:SetSize(c1:GetWide() - 28, 28)

            chipPnl.Paint = function() end

            local cW = math.floor((c1:GetWide() - 28 - (5 * 6)) / 6)

            for idx, tc in ipairs(themeChips) do

                local tb = vgui.Create("DButton", chipPnl)

                tb:SetPos((idx - 1) * (cW + 6), 0)

                tb:SetSize(cW, 28)

                tb:SetText("")

                tb.Paint = function(self, w, h)

                    local isCur = (Garrylose.Config.menu_theme == tc.id)

                    draw.RoundedBox(4, 0, 0, w, h, tc.col)

                    surface.SetDrawColor(isCur and color_white or (self:IsHovered() and color_white or BORDER))

                    surface.DrawOutlinedRect(0, 0, w, h)

                    if isCur then

                        draw.RoundedBox(2, 4, h - 4, w - 8, 2, color_white)

                    end

                end

                tb.DoClick = function()

                    Garrylose.Config.menu_theme = tc.id

                    timer.Simple(0, function() Garrylose.OpenMenu() end)

                end

            end

            y1[1] = y1[1] + 36

            Section(c2, "SYSTEM STATUS", y2)

            local infoPnl2 = vgui.Create("DPanel", c2)

            infoPnl2:SetPos(14, y2[1]); infoPnl2:SetSize(c2:GetWide() - 28, 114)

            infoPnl2.Paint = function(self, w, h)

                draw.RoundedBox(4, 0, 0, w, h, C_INPUT)

                surface.SetDrawColor(BORDER); surface.DrawOutlinedRect(0, 0, w, h)

                draw.SimpleText("GARRYLOSE SYSTEM", "DermaDefaultBold", 12, 14, ACCENT,   TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Build: v1.5.0 Release", "DefaultFixed", 12, 36, TEXT,     TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Theme: " .. Garrylose.GetActiveTheme().name, "DefaultFixed", 12, 56, TEXT,     TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                local ac=Garrylose.GetActiveTheme().accent

                draw.SimpleText(string.format("Accent RGB: [%d, %d, %d]", ac.r, ac.g, ac.b), "DefaultFixed", 12, 76, ACCENT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText("Window Dragging: Global (Any Blank Area)", "DefaultFixed", 12, 96, TEXT_MUT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

            end

            MakeDraggable(infoPnl2)

            y2[1] = y2[1] + 122

        end


        local maxH = math.max(y1[1], y2[1]) + 20

        inner:SetSize(CON_W, math.max(maxH, FH - HEAD_H))

        c1:SetSize(c1:GetWide(), maxH)

        c2:SetSize(c2:GetWide(), maxH)

        scroll:GetCanvas():SetTall(maxH)

        scroll:InvalidateLayout(true)

    end

    searchEntry.OnValueChange = function(self, val)

        if val and string.Trim(val) ~= "" then

            activeTab = "SEARCH"

            LoadSearchContent(val)

            header:InvalidateLayout(true)

        else

            activeTab = Garrylose.CurrentMenuTab or 1

            LoadTabContent(activeTab)

            header:InvalidateLayout(true)

        end

    end

    LoadTabContent(activeTab)

end


concommand.Add("garrylose_menu", Garrylose.ToggleMenu)

concommand.Add("garrylose", Garrylose.ToggleMenu)

concommand.Add("hvh_menu", Garrylose.ToggleMenu)

concommand.Add("menu", Garrylose.ToggleMenu)

concommand.Add("+garrylose_menu", Garrylose.OpenMenu)

concommand.Add("-garrylose_menu", function()

    if IsValid(Garrylose.MenuFrame) then

        Garrylose.MenuFrame:Remove()

        Garrylose.MenuFrame = nil

    end

end)

local function Garrylose_ShowWelcome()

    chat.AddText(Color(0, 180, 255), "[GARRYLOSE] ", Color(240, 245, 255), "Addon v1.5.0 loaded! Press ", Color(0, 220, 255), "[INSERT]", Color(240, 245, 255), " or type ", Color(0, 220, 255), "!menu", Color(240, 245, 255), " / ", Color(0, 220, 255), "garrylose_menu", Color(240, 245, 255), " in console to open menu.")

end

hook.Add("InitPostEntity", "Garrylose_InitPostEntityNotify", function()

    timer.Simple(2, Garrylose_ShowWelcome)

end)

timer.Simple(1, Garrylose_ShowWelcome)
