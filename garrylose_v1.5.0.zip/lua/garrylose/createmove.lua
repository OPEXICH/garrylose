local IsValidFirearm = Garrylose.IsValidFirearm
local IsGrenadeWeapon = Garrylose.IsGrenadeWeapon
local IsKeyCurrentlyPressed = Garrylose.IsKeyCurrentlyPressed


local nextTargetCacheTime = 0

local ignoredNPCs = {

    ["npc_grenade_frag"] = true,

    ["npc_tripmine"] = true,

    ["npc_satchel"] = true,

    ["npc_bullseye"] = true,

    ["npc_heli_bomb"] = true,

    ["npc_handgrenade"] = true,

    ["npc_contactgrenade"] = true,

    ["npc_laserdot"] = true,

    ["npc_spotlight"] = true,

    ["npc_maker"] = true,

    ["npc_template_maker"] = true,

    ["npc_launcher"] = true,

}

local function IsIgnoredEntity(ent, className)

    if not IsValid(ent) then return true end

    local cls = className or string.lower(ent:GetClass() or "")

    if ignoredNPCs[cls] then return true end

    if string.find(cls, "grenade") or string.find(cls, "tripmine") or string.find(cls, "satchel") or string.find(cls, "bullseye") or string.find(cls, "laserdot") or string.find(cls, "maker") then

        return true

    end

    return false

end

Garrylose.ActiveNPCs = Garrylose.ActiveNPCs or {}
hook.Add("OnEntityCreated", "Garrylose_TrackNPCs", function(ent)
    if IsValid(ent) then
        local cls = string.lower(ent:GetClass() or "")
        if ent:IsNPC() or ent:IsNextBot() or string.find(cls, "npc_") or string.find(cls, "nextbot") or ent.Type == "nextbot" then
            if not IsIgnoredEntity(ent, cls) then
                Garrylose.ActiveNPCs[ent] = true
            end
        end
    end
    timer.Simple(0, function()
        if IsValid(ent) and not Garrylose.ActiveNPCs[ent] then
            local cls = string.lower(ent:GetClass() or "")
            if ent:IsNPC() or ent:IsNextBot() or string.find(cls, "npc_") or string.find(cls, "nextbot") or ent.Type == "nextbot" then
                if not IsIgnoredEntity(ent, cls) then
                    Garrylose.ActiveNPCs[ent] = true
                end
            end
        end
    end)
end)

hook.Add("EntityRemoved", "Garrylose_UntrackNPCs", function(ent)
    if Garrylose.ActiveNPCs[ent] then
        Garrylose.ActiveNPCs[ent] = nil
    end
end)

timer.Simple(1, function()
    for _, ent in ipairs(ents.GetAll()) do
        local cls = string.lower(ent:GetClass() or "")
        if ent:IsNPC() or ent:IsNextBot() or string.find(cls, "npc_") or string.find(cls, "nextbot") or ent.Type == "nextbot" then
            if not IsIgnoredEntity(ent, cls) then
                Garrylose.ActiveNPCs[ent] = true
            end
        end
    end
end)

local function UpdateTargetCache()
    if CurTime() < nextTargetCacheTime then return end
    nextTargetCacheTime = CurTime() + 0.1

    table.Empty(Garrylose.CachedTargets)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    if Garrylose.Config.aimbot_target_players or Garrylose.Config.esp_enabled then
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) and p ~= ply and p:Alive() and p:GetMoveType() ~= MOVETYPE_NOCLIP then
                if not Garrylose.Config.aimbot_team_check or (p:Team() ~= ply:Team() or p:Team() == 0 or p:Team() == 1001) then
                    table.insert(Garrylose.CachedTargets, p)
                end
            end
        end
    end

    if Garrylose.Config.aimbot_target_npcs or Garrylose.Config.esp_enabled then
        for ent, _ in pairs(Garrylose.ActiveNPCs) do
            if IsValid(ent) and ent:Health() > 0 then
                table.insert(Garrylose.CachedTargets, ent)
            else
                Garrylose.ActiveNPCs[ent] = nil
            end
        end
    end
end

local function IsValidTarget(ent)

    if not IsValid(ent) or ent == LocalPlayer() then return false end

    if IsIgnoredEntity(ent) then return false end


    if ent:IsPlayer() and Garrylose.Config.aimbot_target_players then

        if not ent:Alive() or ent:GetMoveType() == MOVETYPE_NOCLIP then return false end

        if Garrylose.Config.aimbot_team_check and ent:Team() == LocalPlayer():Team() and ent:Team() ~= 0 and ent:Team() ~= 1001 then

            return false

        end

        return true

    end


    if Garrylose.Config.aimbot_target_npcs then

        if ent:IsNPC() then

            return ent:Health() > 0

        end

        if ent:IsNextBot() then

            return ent:Health() > 0

        end

        local className = string.lower(ent:GetClass() or "")

        if string.find(className, "npc_") or string.find(className, "nextbot") or ent.Type == "nextbot" then

            return ent:Health() > 0

        end

    end

    return false

end

local function IsTargetVisible(ply, target, targetPos)
    if not Garrylose.Config.aimbot_vischeck then return true end
    if not targetPos then return false end

    local shootOrigin = ply:GetShootPos()
    local dist = shootOrigin:Distance(targetPos)

    local trEye = util.TraceLine({
        start = shootOrigin,
        endpos = targetPos,
        filter = {ply, ply:GetActiveWeapon()},
        mask = MASK_SHOT
    })

    if trEye.Entity == target then
        return true
    end

    if IsValid(trEye.Entity) and (trEye.Entity:GetOwner() == target or trEye.Entity:GetParent() == target) then
        return true
    end

    if trEye.Fraction >= 0.95 or not trEye.Hit then
        return true
    end

    if dist < 120 and not trEye.HitWorld then
        return true
    end

    return false
end


local function GetBonePosSafe(ent, boneName, velPredict)
    if not IsValid(ent) then return nil end
    local b = ent:LookupBone(boneName)
    if not b then return nil end

    local matrix = ent:GetBoneMatrix(b)
    if matrix then
        local pos = matrix:GetTranslation()
        if pos and pos:LengthSqr() > 1 then
            return pos + (velPredict or Vector(0,0,0)), matrix:GetAngles()
        end
    end

    local pos, ang = ent:GetBonePosition(b)
    if pos and pos:LengthSqr() > 1 then
        return pos + (velPredict or Vector(0,0,0)), ang
    end

    return nil
end

local function GetExtrapolatedDisplacement(ent, customTicks)
    if not IsValid(ent) then return Vector(0, 0, 0) end
    if not Garrylose.Config.aimbot_extrapolation then return Vector(0, 0, 0) end

    local targetVel = (ent.GetVelocity and ent:GetVelocity()) or Vector(0, 0, 0)
    local targetSpeed = targetVel:Length2D()
    if targetSpeed < 10 and math.abs(targetVel.z) < 10 then
        return Vector(0, 0, 0)
    end

    local tickInterval = engine.TickInterval() or 0.015
    local ticks = tonumber(customTicks) or tonumber(Garrylose.Config.aimbot_extrapolation_ticks) or 3
    ticks = math.Clamp(ticks, 1, 10)

    local totalTime = ticks * tickInterval
    local grav = (GetConVar("sv_gravity") and GetConVar("sv_gravity"):GetFloat()) or 600

    local zOffset = targetVel.z * totalTime
    if not ent:OnGround() then
        zOffset = zOffset - (0.5 * grav * totalTime * totalTime)
    end

    local disp = Vector(targetVel.x * totalTime, targetVel.y * totalTime, zOffset)

    local entPos = ent:GetPos()
    local mins, maxs = ent:GetCollisionBounds()
    if mins and maxs then
        local tr = util.TraceHull({
            start = entPos,
            endpos = entPos + disp,
            mins = mins,
            maxs = maxs,
            filter = ent,
            mask = MASK_PLAYERSOLID
        })
        if tr.Hit then
            return tr.HitPos - entPos
        end
    end

    return disp
end

local function GetAllTargetScanPoints(ply, ent)
    local points = {}
    if not IsValid(ent) then return points end

    if ent.InvalidateBoneCache then ent:InvalidateBoneCache() end
    ent:SetupBones()

    local activeWep = ply:GetActiveWeapon()
    local isProjectile = IsValid(activeWep) and (activeWep:GetClass() == "weapon_crossbow" or activeWep:GetClass() == "weapon_rpg")

    local targetVel = (ent.GetVelocity and ent:GetVelocity()) or Vector(0, 0, 0)
    local targetSpeed = targetVel:Length2D()

    local extrapDisp = Vector(0, 0, 0)
    local velPredict = Vector(0, 0, 0)

    if isProjectile and targetSpeed > 20 then
        local dist = ply:GetShootPos():Distance(ent:WorldSpaceCenter())
        local projSpeed = (activeWep:GetClass() == "weapon_crossbow") and 2000 or 1500
        local flyTime = dist / projSpeed
        local grav = (GetConVar("sv_gravity") and GetConVar("sv_gravity"):GetFloat()) or 600
        local zOffset = targetVel.z * flyTime
        if not ent:OnGround() then
            zOffset = zOffset - (0.5 * grav * flyTime * flyTime)
        end
        velPredict = Vector(targetVel.x * flyTime, targetVel.y * flyTime, zOffset)
    end

    local ang = ent:EyeAngles()
    local right = ang:Right()
    local fwd = ang:Forward()
    local up = Vector(0, 0, 1)
    local scale = math.Clamp(tonumber(Garrylose.Config.aimbot_multipoint_scale) or 0.8, 0.1, 1.0)
    local doMultipoint = Garrylose.Config.aimbot_multipoint or false

    local headPoints = {}
    local bodyPoints = {}
    local limbPoints = {}

    if Garrylose.Config.aimbot_hitbox_head then
        local baseHead = nil
        local hBone = ent:LookupBone("ValveBiped.Bip01_Head1") or ent:LookupBone("head") or ent:LookupBone("ValveBiped.Bip01_Head")
        
        if hBone then
            local matrix = ent:GetBoneMatrix(hBone)
            if matrix then 
                baseHead = matrix:GetTranslation() + velPredict
            else
                local bpos = ent:GetBonePosition(hBone)
                if bpos and bpos ~= Vector(0,0,0) then baseHead = bpos + velPredict end
            end
        end

        if not baseHead then
            local attach = ent:LookupAttachment("eyes") or ent:LookupAttachment("head")
            if attach and attach > 0 then
                local attData = ent:GetAttachment(attach)
                if attData and attData.Pos and attData.Pos ~= Vector(0,0,0) then baseHead = attData.Pos + velPredict end
            end
        end

        if not baseHead then
            baseHead = ent.EyePos and ent:EyePos() or (ent:GetPos() + Vector(0, 0, 60))
            baseHead = baseHead + velPredict
        end

        table.insert(headPoints, baseHead)
        if doMultipoint then
            local r = 1.5 * scale
            table.insert(headPoints, baseHead + right * r)
            table.insert(headPoints, baseHead - right * r)
            table.insert(headPoints, baseHead + fwd * (r * 0.6))
            table.insert(headPoints, baseHead - up * (r * 0.4))
        end
    end

    if Garrylose.Config.aimbot_hitbox_chest then
        local chestPos = GetBonePosSafe(ent, "ValveBiped.Bip01_Spine2", velPredict) or
                         GetBonePosSafe(ent, "spine", velPredict) or
                         GetBonePosSafe(ent, "ValveBiped.Bip01_Spine4", velPredict)
                         
        if not chestPos then chestPos = ent:WorldSpaceCenter() + Vector(0, 0, 4) + velPredict end
        table.insert(bodyPoints, chestPos)

        if doMultipoint then
            local r = 4.5 * scale
            table.insert(bodyPoints, chestPos + up * (r * 1.0))
            table.insert(bodyPoints, chestPos + right * r)
            table.insert(bodyPoints, chestPos - right * r)
        end
    end

    if Garrylose.Config.aimbot_hitbox_stomach then
        local pelvisPos = GetBonePosSafe(ent, "ValveBiped.Bip01_Pelvis", velPredict) or
                          GetBonePosSafe(ent, "ValveBiped.Bip01_Spine", velPredict)
                          
        if not pelvisPos then pelvisPos = ent:WorldSpaceCenter() - Vector(0, 0, 8) + velPredict end
        table.insert(bodyPoints, pelvisPos)

        if doMultipoint then
            local r = 4.0 * scale
            table.insert(bodyPoints, pelvisPos + right * r)
            table.insert(bodyPoints, pelvisPos - right * r)
        end
    end

    if Garrylose.Config.aimbot_hitbox_arms then
        local lArm = GetBonePosSafe(ent, "ValveBiped.Bip01_L_Forearm", velPredict) or GetBonePosSafe(ent, "ValveBiped.Bip01_L_UpperArm", velPredict)
        if lArm then table.insert(limbPoints, lArm) end
        local rArm = GetBonePosSafe(ent, "ValveBiped.Bip01_R_Forearm", velPredict) or GetBonePosSafe(ent, "ValveBiped.Bip01_R_UpperArm", velPredict)
        if rArm then table.insert(limbPoints, rArm) end
    end

    if Garrylose.Config.aimbot_hitbox_legs then
        local lLeg = GetBonePosSafe(ent, "ValveBiped.Bip01_L_Calf", velPredict) or GetBonePosSafe(ent, "ValveBiped.Bip01_L_Thigh", velPredict)
        if lLeg then table.insert(limbPoints, lLeg) end
        local rLeg = GetBonePosSafe(ent, "ValveBiped.Bip01_R_Calf", velPredict) or GetBonePosSafe(ent, "ValveBiped.Bip01_R_Thigh", velPredict)
        if rLeg then table.insert(limbPoints, rLeg) end
    end

    for _, p in ipairs(headPoints) do table.insert(points, {pos = p, isHead = true}) end
    for _, p in ipairs(bodyPoints) do table.insert(points, {pos = p, isHead = false}) end
    for _, p in ipairs(limbPoints) do table.insert(points, {pos = p, isHead = false}) end

    if #points == 0 then
        table.insert(points, { pos = ent:WorldSpaceCenter() + velPredict, isHead = false })
    end

    return points
end

local function GetCS2EstimatedDamage(ply, isHead)

    local wep = ply:GetActiveWeapon()

    if not IsValid(wep) then return 25 end

    local base = 25

    local wClass = string.lower(wep:GetClass() or "")

    if wep.Primary and tonumber(wep.Primary.Damage) and wep.Primary.Damage > 0 then

        base = tonumber(wep.Primary.Damage)

    elseif string.find(wClass, "smg1") then

        base = (GetConVar("sk_plr_dmg_smg1") and GetConVar("sk_plr_dmg_smg1"):GetInt()) or 4

    elseif string.find(wClass, "pistol") then

        base = (GetConVar("sk_plr_dmg_pistol") and GetConVar("sk_plr_dmg_pistol"):GetInt()) or 5

    elseif string.find(wClass, "357") then

        base = (GetConVar("sk_plr_dmg_357") and GetConVar("sk_plr_dmg_357"):GetInt()) or 75

    elseif string.find(wClass, "ar2") then

        base = (GetConVar("sk_plr_dmg_ar2") and GetConVar("sk_plr_dmg_ar2"):GetInt()) or 8

    elseif string.find(wClass, "shotgun") then

        base = 64

    elseif string.find(wClass, "crossbow") then

        base = 100

    elseif string.find(wClass, "awp") then

        base = 115

    elseif string.find(wClass, "scout") or string.find(wClass, "ssg08") then

        base = 75

    elseif string.find(wClass, "deagle") or string.find(wClass, "revolver") then

        base = 54

    elseif string.find(wClass, "ak47") or string.find(wClass, "m4") then

        base = 34

    end

    if isHead then

        return base * 3.5

    else

        return base * 1.0

    end

end


local function GetTargetMultipoints(ply, ent, hitboxType)

    return GetAllTargetScanPoints(ply or LocalPlayer(), ent)

end

local function GetTargetAimPos(ent, hitboxType)

    if not IsValid(ent) then return nil end

    local pts = GetAllTargetScanPoints(LocalPlayer(), ent)

    if pts and pts[1] then

        return (type(pts[1]) == "table" and pts[1].pos) or pts[1]

    end

    return ent:WorldSpaceCenter()

end


local function FixMovement(cmd, realAngles, fakeAngles)

    local fmove = cmd:GetForwardMove()

    local smove = cmd:GetSideMove()

    if fmove == 0 and smove == 0 then return end

    local delta = math.rad(fakeAngles.y - realAngles.y)

    local cosD = math.cos(delta)

    local sinD = math.sin(delta)

    local newFmove = cosD * fmove - sinD * smove

    local newSmove = sinD * fmove + cosD * smove

    cmd:SetForwardMove(math.Clamp(newFmove, -10000, 10000))

    cmd:SetSideMove(math.Clamp(newSmove, -10000, 10000))

end


local function CalculateWeaponHitchance(ply, target, targetAimPos, wep)
    if not IsValid(target) or not targetAimPos then return 100 end
    if Garrylose.Config.nospread_enabled then return 100 end
    if ply:GetShootPos():Distance(targetAimPos) < 100 then return 100 end

    local tickInterval = engine.TickInterval() or 0.015
    local shootPos = ply:GetShootPos()
    if not ply:OnGround() or ply:GetVelocity():Length2D() > 10 then
        shootPos = shootPos + (ply:GetVelocity() * tickInterval)
    end
    local dir = (targetAimPos - shootPos):Angle()

    local spread = 0.005
    local isSniper = false
    if IsValid(wep) then
        local class = string.lower(wep:GetClass() or "")
        isSniper = (class == "weapon_crossbow" or class == "weapon_357" or
                    string.find(class, "sniper") ~= nil or string.find(class, "awp") ~= nil or
                    string.find(class, "scout") ~= nil or string.find(class, "ssg") ~= nil)
        if wep.Primary and tonumber(wep.Primary.Cone) and tonumber(wep.Primary.Cone) > 0 then
            spread = tonumber(wep.Primary.Cone)
        elseif wep.Cone and tonumber(wep.Cone) and tonumber(wep.Cone) > 0 then
            spread = tonumber(wep.Cone)
        end
        if isSniper then spread = 0.001 end
    end

    local vel2D = ply:GetVelocity():Length2D()
    if vel2D > 40 and not isSniper and not Garrylose.Config.aimbot_autostop then
        spread = spread * 1.3
    end

    local hitCount = 0
    local totalSamples = 16

    local targetRadius = 32
    if target:IsPlayer() or target:IsNPC() then
        local mins, maxs = target:GetCollisionBounds()
        if maxs and mins then
            targetRadius = math.max((maxs.x - mins.x) * 1.1, 28)
        end
    end

    local distToTarget = shootPos:Distance(targetAimPos)

    for i = 1, totalSamples do
        local randAngle = math.Rand(0, math.pi * 2)
        local randRadius = math.Rand(0, 1)
        local spreadX = math.cos(randAngle) * randRadius * spread
        local spreadY = math.sin(randAngle) * randRadius * spread
        local spreadDir = dir:Forward() + (dir:Right() * spreadX) + (dir:Up() * spreadY)

        local tr = util.TraceLine({
            start = shootPos,
            endpos = shootPos + (spreadDir * (distToTarget + 64)),
            filter = ply,
            mask = MASK_SHOT
        })

        local rayEnd = shootPos + (spreadDir * distToTarget)
        local distFromRay = rayEnd:Distance(targetAimPos)

        if (tr.Entity == target) or (not tr.HitWorld and distFromRay <= targetRadius) then
            hitCount = hitCount + 1
        end
    end

    return math.Round((hitCount / totalSamples) * 100)
end

hook.Add("CreateMove", "Garrylose_Core_CreateMove", function(cmd)

    local ply = LocalPlayer()

    if not IsValid(ply) or not ply:Alive() then return end

    local fcKey = Garrylose.Config.bind_freecam
    if fcKey and fcKey > 0 and IsKeyCurrentlyPressed(fcKey) then
        if not Garrylose.FreecamKeyHeld then
            Garrylose.FreecamKeyHeld = true
            Garrylose.Config.freecam_enabled = not Garrylose.Config.freecam_enabled
        end
    else
        Garrylose.FreecamKeyHeld = false
    end

    local is_freecam = Garrylose.Config.freecam_enabled
    if is_freecam and not Garrylose.OldFreecam then
        Garrylose.FreecamPos = ply:EyePos()
        Garrylose.FreecamAng = cmd:GetViewAngles()
    end
    Garrylose.OldFreecam = is_freecam

    if is_freecam then
        local speed = (tonumber(Garrylose.Config.freecam_speed) or 10) * (IsKeyCurrentlyPressed(KEY_LSHIFT) and 2 or 1)
        local fwd = Garrylose.FreecamAng:Forward()
        local right = Garrylose.FreecamAng:Right()
        local up = Garrylose.FreecamAng:Up()
        
        local fSpeed, sSpeed, uSpeed = 0, 0, 0
        if IsKeyCurrentlyPressed(KEY_W) then fSpeed = 1 end
        if IsKeyCurrentlyPressed(KEY_S) then fSpeed = -1 end
        if IsKeyCurrentlyPressed(KEY_A) then sSpeed = -1 end
        if IsKeyCurrentlyPressed(KEY_D) then sSpeed = 1 end
        if IsKeyCurrentlyPressed(KEY_SPACE) then uSpeed = 1 end
        if IsKeyCurrentlyPressed(KEY_LCONTROL) then uSpeed = -1 end
        
        Garrylose.FreecamPos = Garrylose.FreecamPos + (fwd * fSpeed * speed)
        Garrylose.FreecamPos = Garrylose.FreecamPos + (right * sSpeed * speed)
        Garrylose.FreecamPos = Garrylose.FreecamPos + (up * uSpeed * speed)
        
        Garrylose.FreecamAng = cmd:GetViewAngles()
        cmd:ClearMovement()
        cmd:ClearButtons()
        return
    end

    if Garrylose.Config.flash_spam then
        cmd:SetImpulse(100)
    end
    
    if Garrylose.Config.auto_reload then
        local wep = ply:GetActiveWeapon()
        if IsValid(wep) and wep:Clip1() == 0 then
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_RELOAD))
        end
    end

    local curT = CurTime()


    if ply:GetMoveType() == MOVETYPE_NOCLIP then

        Garrylose.RealViewAngles = cmd:GetViewAngles()

        return

    end

    local mouseX = cmd:GetMouseX()

    local mouseY = cmd:GetMouseY()

    local sens = GetConVar("sensitivity"):GetFloat() or 3.0

    local mPitch = GetConVar("m_pitch"):GetFloat() or 0.022

    local mYaw = GetConVar("m_yaw"):GetFloat() or 0.022

    if not Garrylose.RealViewAngles or Garrylose.RealViewAngles == Angle(0, 0, 0) then

        Garrylose.RealViewAngles = cmd:GetViewAngles()

    end

    if Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent then

        local newPitch = math.Clamp(Garrylose.RealViewAngles.p + (mouseY * mPitch * sens), -89, 89)

        local newYaw = math.NormalizeAngle(Garrylose.RealViewAngles.y - (mouseX * mYaw * sens))

        Garrylose.RealViewAngles = Angle(newPitch, newYaw, 0)

    else

        Garrylose.RealViewAngles = cmd:GetViewAngles()

    end

    local realAngles = Angle(Garrylose.RealViewAngles.p, Garrylose.RealViewAngles.y, 0)

    if Garrylose.Config.autopeek_enabled then

        if not Garrylose.AutoPeekPos then

            Garrylose.AutoPeekPos = ply:GetPos()

            Garrylose.AutoPeekState = "IDLE"

        end

        local rawFmove = cmd:GetForwardMove()

        local rawSmove = cmd:GetSideMove()

        local isPressingMovement = (rawFmove ~= 0 or rawSmove ~= 0 or cmd:KeyDown(IN_FORWARD) or cmd:KeyDown(IN_BACK) or cmd:KeyDown(IN_MOVELEFT) or cmd:KeyDown(IN_MOVERIGHT))

        local dist2D = (Garrylose.AutoPeekPos - ply:GetPos()):Length2D()

        local returnMode = tonumber(Garrylose.Config.autopeek_return_mode) or 3
        local shotTriggered = cmd:KeyDown(IN_ATTACK) or Garrylose.ShotState or (Garrylose.LastShotTime and (CurTime() - Garrylose.LastShotTime) < 0.15)
        local moveEndTriggered = (dist2D > 20 and not isPressingMovement and Garrylose.AutoPeekState ~= "RETURNING")

        if (returnMode == 1 or returnMode == 3) and shotTriggered then
            Garrylose.AutoPeekState = "RETURNING"
        elseif (returnMode == 2 or returnMode == 3) and moveEndTriggered then
            Garrylose.AutoPeekState = "RETURNING"
        end

    else

        Garrylose.AutoPeekPos = nil

        Garrylose.AutoPeekState = nil

    end

    if Garrylose.Config.fakeduck_enabled and ply:OnGround() then

        Garrylose.FakeDuckTick = (Garrylose.FakeDuckTick or 0) + 1

        if (Garrylose.FakeDuckTick % 8) < 7 then

            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))

        else

            cmd:RemoveKey(IN_DUCK)

        end

    else

        Garrylose.FakeDuckTick = 0

    end

    if Garrylose.Config.edgejump_enabled and ply:OnGround() and ply:GetMoveType() == MOVETYPE_WALK then

        local vel = ply:GetVelocity()

        if vel:Length2D() > 10 then

            local predictPos = ply:GetPos() + (vel * FrameTime() * 1.5)

            local trDown = util.TraceLine({

                start = predictPos + Vector(0, 0, 10),

                endpos = predictPos - Vector(0, 0, 40),

                filter = ply,

                mask = MASK_PLAYERSOLID

            })

            if not trDown.Hit then

                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))

            end

        end

    end

    local pPos = ply:GetPos()
    local vel = ply:GetVelocity()
    local speed2D = vel:Length2D()
    local dt = engine.TickInterval() or 0.015

    local mins, maxs = ply:GetCollisionBounds()
    local trGround = util.TraceHull({
        start = pPos + Vector(0, 0, 2),
        endpos = pPos - Vector(0, 0, 6),
        mins = mins,
        maxs = maxs,
        filter = ply,
        mask = MASK_PLAYERSOLID
    })

    local isTouchingGround = ply:OnGround() or (ply:GetGroundEntity() and IsValid(ply:GetGroundEntity())) or (trGround.Hit and trGround.HitNormal.z >= 0.1)
    local ground = isTouchingGround
    local onIncline = trGround.Hit and (trGround.HitNormal.z < 0.95 and trGround.HitNormal.z >= 0.1)
    local isHoldingDuck = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)

    local isJBKeyPressed = false
    local jbKey = Garrylose.Config.bind_jumpbug
    if jbKey and jbKey ~= KEY_NONE and jbKey ~= 0 then
        isJBKeyPressed = (jbKey >= 107 and input.IsMouseDown(jbKey)) or (jbKey < 107 and input.IsKeyDown(jbKey))
    end

    local isHoldingJump = cmd:KeyDown(IN_JUMP) or input.IsKeyDown(KEY_SPACE)
    local grav = (GetConVar("sv_gravity") and GetConVar("sv_gravity"):GetFloat()) or 600
    local jbMode = tonumber(Garrylose.Config.jumpbug_mode) or 1

    local shouldJB = false
    local jbAction = 0

    if Garrylose.Config.jumpbug_enabled and ply:GetMoveType() == MOVETYPE_WALK and not isTouchingGround and vel.z < -40 then
        local trFloor = util.TraceHull({
            start = pPos,
            endpos = pPos - Vector(0, 0, 8192),
            mins = Vector(-16, -16, 0),
            maxs = Vector(16, 16, 36),
            filter = ply,
            mask = MASK_PLAYERSOLID
        })

        if trFloor.Hit and trFloor.HitNormal.z >= 0.7 then
            local distToFloor = pPos.z - trFloor.HitPos.z
            local impactSpeed = math.sqrt(vel.z * vel.z + 2 * grav * math.max(0, distToFloor))
            local willDamage = (impactSpeed >= 250) or (vel.z <= -200) or (distToFloor > 60)

            local userWantsJB = isJBKeyPressed or isHoldingJump or (jbMode == 2) or willDamage

            if userWantsJB then
                shouldJB = true
                Garrylose.CrouchJumpDisabledByJB = true

                local dropThisTick = math.abs(vel.z) * dt + 0.5 * grav * dt * dt

                local isAtUnduckSnap = (distToFloor >= 33.0 and distToFloor <= (dropThisTick + 38.0))
                local isNearGroundLanding = (distToFloor <= (dropThisTick + 6.0))

                if isAtUnduckSnap or isNearGroundLanding then
                    jbAction = 2
                else
                    jbAction = 1
                end
            else
                Garrylose.CrouchJumpDisabledByJB = false
            end
        else
            Garrylose.CrouchJumpDisabledByJB = false
        end
    else
        Garrylose.CrouchJumpDisabledByJB = false
    end

    if Garrylose.Config.crouchjump_enabled and ply:GetMoveType() == MOVETYPE_WALK and not Garrylose.CrouchJumpDisabledByJB then
        if not isTouchingGround then
            local isNearGround = false
            if vel.z <= 20 then
                local checkDist = math.max(90, math.abs(vel.z) * 0.25 + 36)
                local trPreLand = util.TraceHull({
                    start = pPos,
                    endpos = pPos - Vector(0, 0, checkDist),
                    mins = mins,
                    maxs = maxs,
                    filter = ply,
                    mask = MASK_PLAYERSOLID
                })
                isNearGround = trPreLand.Hit
            end

            if isNearGround then
                Garrylose.DuckBurstTick = 0
                if not isHoldingDuck and not Garrylose.Config.fakeduck_enabled then
                    cmd:RemoveKey(IN_DUCK)
                end
            else
                local cMode = tonumber(Garrylose.Config.crouchjump_mode) or 1
                if cMode == 2 then
                    Garrylose.DuckBurstTick = (Garrylose.DuckBurstTick or 0) + 1
                    if (Garrylose.DuckBurstTick % 4) < 2 then
                        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
                    else
                        if not isHoldingDuck and not Garrylose.Config.fakeduck_enabled then
                            cmd:RemoveKey(IN_DUCK)
                        end
                    end
                else
                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
                end
            end
        else
            Garrylose.DuckBurstTick = 0
            if not isHoldingDuck and not Garrylose.Config.fakeduck_enabled then
                cmd:RemoveKey(IN_DUCK)
            end
        end
    end

    if shouldJB and vel.z < 0 then
        if jbAction == 2 then
            cmd:RemoveKey(IN_DUCK)
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
            Garrylose.JumpBuggedThisTick = true
            Garrylose.JumpBugActive = true
            Garrylose.JumpBugTicks = 0
        elseif jbAction == 1 then
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
            Garrylose.JumpBuggedThisTick = false
        end
    else
        Garrylose.JumpBuggedThisTick = false
    end

    if Garrylose.JumpBugActive then
        Garrylose.JumpBugTicks = (Garrylose.JumpBugTicks or 0) + 1
        cmd:RemoveKey(IN_DUCK)
        cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))

        if vel.z > 50 or Garrylose.JumpBugTicks > 4 then
            Garrylose.JumpBugActive = false
            Garrylose.JumpBugTicks = 0
            Garrylose.JumpBuggedThisTick = false
        end
    end

    local isEBActive = Garrylose.Config.edgebug_enabled
    local ebKey = Garrylose.Config.bind_edgebug
    if isEBActive and ebKey and ebKey ~= KEY_NONE and ebKey ~= 0 then
        isEBActive = (ebKey >= 107 and input.IsMouseDown(ebKey)) or (ebKey < 107 and input.IsKeyDown(ebKey))
    end

    if isEBActive and ply:GetMoveType() == MOVETYPE_WALK and not isTouchingGround and vel.z < -150 and not Garrylose.JumpBuggedThisTick and not Garrylose.JumpBugActive then
        local predictEdge = math.abs(vel.z) * dt * 1.6 + 6
        local trCenter = util.TraceLine({
            start = pPos,
            endpos = pPos - Vector(0, 0, predictEdge),
            filter = ply,
            mask = MASK_PLAYERSOLID
        })

        local trHullEdge = util.TraceHull({
            start = pPos,
            endpos = pPos - Vector(0, 0, predictEdge),
            mins = mins,
            maxs = maxs,
            filter = ply,
            mask = MASK_PLAYERSOLID
        })

        if trHullEdge.Hit and not trCenter.Hit and trHullEdge.HitNormal.z >= 0.5 then
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
            cmd:SetForwardMove(math.Clamp(cmd:GetForwardMove(), -80, 80))
        end
    end

    local isJBLocked = Garrylose.JumpBugActive or Garrylose.JumpBuggedThisTick or shouldJB
    if Garrylose.Config.bhop_enabled and cmd:KeyDown(IN_JUMP) and not isJBLocked then
        if isTouchingGround then
            if not isHoldingDuck and not Garrylose.Config.fakeduck_enabled then
                cmd:RemoveKey(IN_DUCK)
            end
            if Garrylose.BhopWasInAir then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
                Garrylose.BhopWasInAir = false
            else
                cmd:RemoveKey(IN_JUMP)
                Garrylose.BhopWasInAir = true
            end
        else
            cmd:RemoveKey(IN_JUMP)
            Garrylose.BhopWasInAir = true
        end

        if cmd:KeyDown(IN_FORWARD) then
            cmd:SetForwardMove(450)
            cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_FORWARD))
        end
    elseif not isJBLocked then
        Garrylose.BhopWasInAir = true
    end

    local trLadder = util.TraceHull({
        start = ply:GetPos(),
        endpos = ply:GetPos() + Vector(0, 0, 2),
        mins = Vector(-18, -18, 0),
        maxs = Vector(18, 18, 72),
        filter = ply,
        mask = 536870912
    })

    local isOnLadder = (ply:GetMoveType() == MOVETYPE_LADDER) or (ply:GetMoveType() == 9) or (trLadder and trLadder.Hit)

    if Garrylose.Config.autostrafe_enabled and not ground and not isOnLadder and ply:GetMoveType() == MOVETYPE_WALK then
        local mode = tonumber(Garrylose.Config.autostrafe_mode) or 1

        if not onIncline and not cmd:KeyDown(IN_FORWARD) and not cmd:KeyDown(IN_BACK) and speed2D > 15 then
            cmd:SetForwardMove(0)
            cmd:RemoveKey(IN_FORWARD)
            cmd:RemoveKey(IN_BACK)
        end

        if mode == 1 then

            if mouseX > 0 then

                cmd:SetSideMove(10000)

                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVERIGHT))

                cmd:RemoveKey(IN_MOVELEFT)

            elseif mouseX < 0 then

                cmd:SetSideMove(-10000)

                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVELEFT))

                cmd:RemoveKey(IN_MOVERIGHT)

            else

                if cmd:KeyDown(IN_MOVERIGHT) or cmd:GetSideMove() > 0 then

                    cmd:SetSideMove(10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVERIGHT))

                    cmd:RemoveKey(IN_MOVELEFT)

                elseif cmd:KeyDown(IN_MOVELEFT) or cmd:GetSideMove() < 0 then

                    cmd:SetSideMove(-10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVELEFT))

                    cmd:RemoveKey(IN_MOVERIGHT)

                end

            end

        elseif mode == 2 then

            if speed < 30 then

                cmd:SetForwardMove(10000)

            else

                cmd:SetForwardMove(0)

                cmd:RemoveKey(IN_FORWARD)

                cmd:RemoveKey(IN_BACK)

                Garrylose.StrafeSwitch = not Garrylose.StrafeSwitch

                if Garrylose.StrafeSwitch then

                    cmd:SetSideMove(-10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVELEFT))

                    cmd:RemoveKey(IN_MOVERIGHT)

                else

                    cmd:SetSideMove(10000)

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_MOVERIGHT))

                    cmd:RemoveKey(IN_MOVELEFT)

                end

            end

        end

    end

    if Garrylose.Config.autopeek_enabled and Garrylose.AutoPeekPos and Garrylose.AutoPeekState == "RETURNING" then

        local myPos = ply:GetPos()

        local diff = Garrylose.AutoPeekPos - myPos

        local dist2D = diff:Length2D()

        if dist2D > 10 then

            local worldDir = Vector(diff.x / dist2D, diff.y / dist2D, 0)

            local worldWishVel = worldDir * 10000

            local realYaw = math.rad(realAngles.y)

            local realFwd = Vector(math.cos(realYaw), math.sin(realYaw), 0)

            local realRt  = Vector(math.sin(realYaw), -math.cos(realYaw), 0)

            local autoFmove = worldWishVel:Dot(realFwd)

            local autoSmove = worldWishVel:Dot(realRt)

            cmd:SetForwardMove(math.Clamp(autoFmove, -10000, 10000))

            cmd:SetSideMove(math.Clamp(autoSmove, -10000, 10000))

            cmd:RemoveKey(IN_FORWARD)

            cmd:RemoveKey(IN_BACK)

            cmd:RemoveKey(IN_MOVELEFT)

            cmd:RemoveKey(IN_MOVERIGHT)

        else


            Garrylose.AutoPeekState = "IDLE"

            cmd:SetForwardMove(0)

            cmd:SetSideMove(0)

        end

    end

    UpdateTargetCache()

    local overrideKey = Garrylose.Config.bind_min_damage_override

    local isOverrideHeld = false

    if overrideKey and overrideKey ~= KEY_NONE and overrideKey ~= 0 then

        if overrideKey >= 107 then

            isOverrideHeld = input.IsMouseDown(overrideKey)

        else

            isOverrideHeld = input.IsKeyDown(overrideKey)

        end

    end

    local isOverrideActive = isOverrideHeld or Garrylose.Config.min_damage_override_active

    local activeMinDmg = isOverrideActive and (tonumber(Garrylose.Config.aimbot_min_damage_override) or 1) or (tonumber(Garrylose.Config.aimbot_min_damage) or 1)

    local target = nil

    local targetAimPos = nil
    local bestFov = tonumber(Garrylose.Config.aimbot_fov) or 180
    local shootPos = ply:GetShootPos()
    local activeWep = ply:GetActiveWeapon()
    local isFirearm = IsValidFirearm(activeWep)

    if Garrylose.Config.aimbot_enabled and isFirearm then

        local candidates = {}

        if IsValid(Garrylose.CurrentTarget) and IsValidTarget(Garrylose.CurrentTarget) then
            table.insert(candidates, Garrylose.CurrentTarget)
        end

        if Garrylose.Config.aimbot_target_players then
            for _, p in ipairs(player.GetAll()) do
                if IsValid(p) and p ~= Garrylose.CurrentTarget and IsValidTarget(p) then
                    table.insert(candidates, p)
                end
            end
        end

        if Garrylose.Config.aimbot_target_npcs then
            for ent, _ in pairs(Garrylose.ActiveNPCs) do
                if IsValid(ent) and ent ~= Garrylose.CurrentTarget and not ent:IsPlayer() and IsValidTarget(ent) then
                    table.insert(candidates, ent)
                end
            end
        end

        for _, ent in ipairs(candidates) do
            if IsValid(ent) and ent:Health() > 0 then
                local entHp = ent:Health()
                local entPos = ent:WorldSpaceCenter()
                local distToEnt = shootPos:Distance(entPos)
                local roughAngle = (entPos - shootPos):Angle()
                local fovP = math.abs(math.AngleDifference(realAngles.p, roughAngle.p))
                local fovY = math.abs(math.AngleDifference(realAngles.y, roughAngle.y))
                local roughFov = math.sqrt(fovP * fovP + fovY * fovY)

                local maxCheckFov = tonumber(Garrylose.Config.aimbot_fov) or 180
                if maxCheckFov >= 180 or distToEnt < 150 or roughFov <= (maxCheckFov + 35) then

                    local points = GetAllTargetScanPoints(ply, ent)

                    for _, ptData in ipairs(points) do
                        local pt = (type(ptData) == "table" and ptData.pos) or ptData
                        local isHead = (type(ptData) == "table" and ptData.isHead) or false

                        if isvector(pt) then
                            local estDmg = GetCS2EstimatedDamage(ply, isHead)
                            local passesDamage = (activeMinDmg <= 1) or (estDmg >= activeMinDmg) or (entHp <= estDmg)

                            if passesDamage then
                                local angleToTarget = (pt - shootPos):Angle()
                                local pFovP = math.abs(math.AngleDifference(realAngles.p, angleToTarget.p))
                                local pFovY = math.abs(math.AngleDifference(realAngles.y, angleToTarget.y))
                                local totalFov = math.sqrt(pFovP * pFovP + pFovY * pFovY)

                                if totalFov <= Garrylose.Config.aimbot_fov and IsTargetVisible(ply, ent, pt) then
                                    if totalFov < bestFov then
                                        bestFov = totalFov
                                        target = ent
                                        targetAimPos = pt
                                        if isHead and Garrylose.Config.aimbot_head_priority then
                                            break
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end

        Garrylose.CurrentTarget = target
        Garrylose.CurrentTargetPos = targetAimPos
    end

    local aimbotActive = false

    if target and targetAimPos and Garrylose.Config.aimbot_enabled then
        Garrylose.AimbotTargetTicks = (Garrylose.AimbotTargetTicks or 0) + 1
        aimbotActive = true
        
        if Garrylose.Config.aimbot_autostop then
            cmd:SetForwardMove(0)
            cmd:SetSideMove(0)
            cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(bit.bor(IN_FORWARD, IN_BACK, IN_MOVELEFT, IN_MOVERIGHT))))
        end

        local tickInterval = engine.TickInterval() or 0.015
        local shootOrigin = ply:GetShootPos()
        local distToAim = shootOrigin:Distance(targetAimPos)
        if distToAim > 90 and (not ply:OnGround() or ply:GetVelocity():Length2D() > 10) then
            shootOrigin = shootOrigin + (ply:GetVelocity() * tickInterval)
        end
        local aimAngle = (targetAimPos - shootOrigin):Angle()

        if Garrylose.Config.aimbot_rcs then
            local punch = ply:GetPunchAngle() or Angle(0, 0, 0)
            aimAngle = Angle(aimAngle.p - (punch.p * 1.0), aimAngle.y - (punch.y * 1.0), 0)
        end

        aimAngle:Normalize()
        cmd:SetViewAngles(aimAngle)
        FixMovement(cmd, realAngles, aimAngle)

        if not Garrylose.Config.aimbot_silent then
            ply:SetEyeAngles(aimAngle)
            Garrylose.RealViewAngles = aimAngle
        end

        local curT = CurTime()
        local wep = ply:GetActiveWeapon()
        local isFirearm = IsValidFirearm(wep)
        if Garrylose.Config.aimbot_auto_shoot and isFirearm then
            local canShoot = true
            if IsValid(wep) then
                local clip1 = wep:Clip1()
                local maxClip = wep:GetMaxClip1()
                if maxClip > 0 and clip1 == 0 then
                    canShoot = false
                end

                local nextPrimary = wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0
                if curT < nextPrimary then
                    canShoot = false
                end
            else
                canShoot = false
            end

            local minLockTicks = tonumber(Garrylose.Config.aimbot_lock_ticks) or 0
            local isAirborne = (not ply:OnGround()) or (IsValid(target) and target.OnGround and not target:OnGround())
            local isMovingFast = ply:GetVelocity():Length2D() > 60
            local targetVel = IsValid(target) and target:GetVelocity() or Vector(0, 0, 0)
            local isTargetFast = targetVel:Length2D() > 30 or math.abs(targetVel.z) > 30
            if isAirborne or isMovingFast or isTargetFast or Garrylose.Config.aimbot_extrapolation then
                minLockTicks = 0
            end
            if (Garrylose.AimbotTargetTicks or 0) < minLockTicks then
                canShoot = false
            end

                        if canShoot and Garrylose.Config.hitchance_enabled and tonumber(Garrylose.Config.aimbot_hitchance) and tonumber(Garrylose.Config.aimbot_hitchance) > 0 then

                local isHCOverride = false

                local hcKey = Garrylose.Config.bind_hitchance_override

                if hcKey and hcKey ~= KEY_NONE and hcKey ~= 0 then

                    isHCOverride = (hcKey >= 107 and input.IsMouseDown(hcKey)) or (hcKey < 107 and input.IsKeyDown(hcKey))

                end

                isHCOverride = isHCOverride or Garrylose.Config.hitchance_override_active

                local requiredHC = isHCOverride and (tonumber(Garrylose.Config.aimbot_hitchance_override) or 0) or tonumber(Garrylose.Config.aimbot_hitchance)

                if requiredHC > 0 then

                    local sampledHC = CalculateWeaponHitchance(ply, target, targetAimPos, wep)

                    if sampledHC < requiredHC then

                        canShoot = false

                    end

                end

            end

            if canShoot then
                cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                Garrylose.LastShotTarget = target
                Garrylose.LastShotTargetPos = targetAimPos
                Garrylose.LastShotTime = curT

                local nextPrimary = wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0
                local clip1 = wep:Clip1()
                if curT >= nextPrimary and (clip1 > 0 or clip1 == -1) and (Garrylose.AimbotLastShotNextPrimary ~= nextPrimary or (curT - (Garrylose.AimbotLastShotTime or 0) > 0.08)) then
                    Garrylose.AimbotLastShotNextPrimary = nextPrimary
                    Garrylose.AimbotLastShotTime = curT

                    local shootSrc = ply:GetShootPos()
                    local aimDir = (targetAimPos - shootSrc):GetNormalized()
                    local shootTr = util.TraceLine({
                        start = shootSrc,
                        endpos = shootSrc + (aimDir * 50000),
                        filter = ply,
                        mask = MASK_SHOT
                    })
                    local hitP = (shootTr and shootTr.HitPos) or targetAimPos
                    if Garrylose.RecordShot then
                        Garrylose.RecordShot(shootSrc, hitP)
                    end
                end
            else
                cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_ATTACK)))
                Garrylose.AimbotLastShotNextPrimary = nil
            end

        elseif cmd:KeyDown(IN_ATTACK) then

            Garrylose.LastShotTarget = target
            Garrylose.LastShotTargetPos = targetAimPos
            Garrylose.ManualShotState = true
            Garrylose.LastShotTime = curT

        else

            Garrylose.ManualShotState = false

        end

        aimbotActive = true

    else
        Garrylose.AimbotTargetTicks = 0
        Garrylose.ShotState = false
        Garrylose.ManualShotState = false

        if cmd:KeyDown(IN_ATTACK) then

            local wep = ply:GetActiveWeapon()
            local curT = CurTime()
            local nextPrimary = IsValid(wep) and wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0
            local clip1 = IsValid(wep) and wep:Clip1() or 0

            if not Garrylose.ManualShotState and curT >= nextPrimary and (clip1 > 0 or clip1 == -1) then
                Garrylose.ManualShotState = true
                Garrylose.LastShotTime = curT
            end

        else

            Garrylose.ManualShotState = false

        end

    end

    if cmd:KeyDown(IN_ATTACK) and not aimbotActive then

        cmd:SetViewAngles(realAngles)
        FixMovement(cmd, realAngles, realAngles)

    end

        local activeWep = ply:GetActiveWeapon()

    local isHoldingGrenade = IsGrenadeWeapon(activeWep)

    local isHoldingTool = IsValid(activeWep) and (activeWep:GetClass() == "weapon_physgun" or activeWep:GetClass() == "gmod_tool" or activeWep:GetClass() == "gmod_camera")

    local isCursorOpen = vgui.CursorVisible() or gui.IsGameUIVisible() or gui.IsConsoleVisible()

    local shouldSuspendAA = isHoldingGrenade or isHoldingTool or isCursorOpen or isOnLadder or cmd:KeyDown(IN_ATTACK) or cmd:KeyDown(IN_ATTACK2)

    if Garrylose.Config.antiaim_enabled and not aimbotActive and not shouldSuspendAA then

                local fakePitch = realAngles.p

        local fakeYaw = realAngles.y

        local pitchMode = tonumber(Garrylose.Config.antiaim_pitch) or 1

        if pitchMode == 1 then

            fakePitch = 89.0

        elseif pitchMode == 2 then

            fakePitch = -89.0

        elseif pitchMode == 3 then

            local pjAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_pitch_jitter_angle) or 45, 1, 89)

            fakePitch = Garrylose.JitterFlip and pjAngle or -pjAngle

        elseif pitchMode == 4 then

            local pjAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_pitch_jitter_angle) or 89, 1, 89)

            fakePitch = math.Rand(-pjAngle, pjAngle)

        end

        Garrylose.JitterFlip = not Garrylose.JitterFlip

        if Garrylose.Config.manual_aa_state == 1 then

            fakeYaw = fakeYaw + 90

        elseif Garrylose.Config.manual_aa_state == 2 then

            fakeYaw = fakeYaw - 90

        elseif Garrylose.Config.manual_aa_state == 3 then

            fakeYaw = fakeYaw + 180

        else

            if Garrylose.Config.antiaim_yaw == 1 then

                fakeYaw = fakeYaw + 180

            elseif Garrylose.Config.antiaim_yaw == 2 then


                local spinSpeed = tonumber(Garrylose.Config.antiaim_spin_speed) or 450

                local tickDelta = engine.TickInterval() or (1 / 66.6)

                Garrylose.SpinbotYaw = math.NormalizeAngle((Garrylose.SpinbotYaw or realAngles.y) + (spinSpeed * tickDelta))

                fakeYaw = Garrylose.SpinbotYaw

            elseif Garrylose.Config.antiaim_yaw == 3 then

                local jAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_jitter_angle) or 90, 1, 360)

                local jBase = (tonumber(Garrylose.Config.antiaim_jitter_side) or 1) == 2 and 0 or 180

                fakeYaw = fakeYaw + jBase + (Garrylose.JitterFlip and jAngle or -jAngle)

            elseif Garrylose.Config.antiaim_yaw == 4 then

                local jAngle = math.Clamp(tonumber(Garrylose.Config.antiaim_jitter_angle) or 180, 1, 360)

                local jBase = (tonumber(Garrylose.Config.antiaim_jitter_side) or 1) == 2 and 0 or 180

                fakeYaw = fakeYaw + jBase + math.Rand(-jAngle, jAngle)

            end

        end

        local fakeAngles = Angle(fakePitch, math.NormalizeAngle(fakeYaw), 0)

        Garrylose.LastSentFakeAngles = fakeAngles

        FixMovement(cmd, realAngles, fakeAngles)

        cmd:SetViewAngles(fakeAngles)

    elseif not aimbotActive then

                cmd:SetViewAngles(realAngles)

        Garrylose.LastSentFakeAngles = realAngles

    end

    local isTrigKey = false

    local tbKey = Garrylose.Config.bind_triggerbot

    if tbKey and tbKey ~= KEY_NONE and tbKey ~= 0 then

        isTrigKey = (tbKey >= 107 and input.IsMouseDown(tbKey)) or (tbKey < 107 and input.IsKeyDown(tbKey))

    end

    if (Garrylose.Config.triggerbot_enabled or isTrigKey) and not aimbotActive then

        local trCross = util.TraceLine({

            start = ply:GetShootPos(),

            endpos = ply:GetShootPos() + (cmd:GetViewAngles():Forward() * 10000),

            filter = ply,

            mask = MASK_SHOT

        })

        if trCross and trCross.Hit and IsValid(trCross.Entity) and IsValidTarget(trCross.Entity) then

            local isHead = (trCross.HitGroup == 1 or trCross.HitGroup == HITGROUP_HEAD)

            local allowShoot = not Garrylose.Config.triggerbot_head_only or isHead

            if allowShoot then

                local delay = (tonumber(Garrylose.Config.triggerbot_delay) or 0) / 1000

                Garrylose.TriggerbotTimer = Garrylose.TriggerbotTimer or CurTime()

                if (CurTime() - Garrylose.TriggerbotTimer) >= delay then
                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
                    Garrylose.TriggerbotTimer = CurTime() + 0.12

                    local wep = ply:GetActiveWeapon()
                    if IsValid(wep) and IsValidFirearm(wep) then
                        local curT = CurTime()
                        local nextPrimary = wep.GetNextPrimaryFire and wep:GetNextPrimaryFire() or 0
                        local clip1 = wep:Clip1()
                        if curT >= nextPrimary and (clip1 > 0 or clip1 == -1) then
                            local shootSrc = ply:GetShootPos()
                            local hitP = trCross.HitPos or (shootSrc + (ply:GetAimVector() * 50000))
                            if Garrylose.RecordShot then
                                Garrylose.RecordShot(shootSrc, hitP)
                            end
                        end
                    end
                end

            end

        else

            Garrylose.TriggerbotTimer = CurTime()

        end

    end

    if Garrylose.Config.autoreload_enabled then

        local wep = ply:GetActiveWeapon()

        if IsValid(wep) then

            local clip1 = wep:Clip1()

            local maxClip = wep:GetMaxClip1()

            if maxClip > 0 and clip1 == 0 and not aimbotActive and not cmd:KeyDown(IN_ATTACK) then

                if ply:GetAmmoCount(wep:GetPrimaryAmmoType()) > 0 then

                    cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_RELOAD))

                end

            end

        end

    end

    local isAirStopKey = false

    local asKey = Garrylose.Config.bind_airstop

    if asKey and asKey ~= KEY_NONE and asKey ~= 0 then

        isAirStopKey = (asKey >= 107 and input.IsMouseDown(asKey)) or (asKey < 107 and input.IsKeyDown(asKey))

    end

    local shouldAirStop = isAirStopKey or (Garrylose.Config.airstop_enabled and aimbotActive and IsValid(target))

    if shouldAirStop and not ply:OnGround() and ply:GetMoveType() == MOVETYPE_WALK then

        local curVel = ply:GetVelocity()

        local curVel2D = Vector(curVel.x, curVel.y, 0)

        if curVel2D:Length() > 2 then

            local velAng = curVel:Angle()

            local viewAng = cmd:GetViewAngles()

            local diffYaw = math.rad(math.NormalizeAngle(velAng.y - viewAng.y))

                        local fmove = -math.cos(diffYaw) * 10000

            local smove = math.sin(diffYaw) * 10000

            cmd:SetForwardMove(math.Clamp(fmove, -10000, 10000))

            cmd:SetSideMove(math.Clamp(smove, -10000, 10000))

            cmd:SetUpMove(0)

            cmd:RemoveKey(IN_FORWARD)

            cmd:RemoveKey(IN_BACK)

            cmd:RemoveKey(IN_MOVELEFT)

            cmd:RemoveKey(IN_MOVERIGHT)

        else

            cmd:SetForwardMove(0)

            cmd:SetSideMove(0)

            cmd:SetUpMove(0)

        end

    end

    for id, plugin in pairs(Garrylose.Plugins) do

        if plugin.enabled and plugin.onCreateMove then

            pcall(plugin.onCreateMove, cmd)

        end

    end

end)

Garrylose.FixMovement = FixMovement

hook.Add("SetupMove", "Garrylose_JumpBug_SetupMove", function(ply, mv, cmd)
    if not IsValid(ply) or ply ~= LocalPlayer() then return end
    if Garrylose.JumpBugActive then
        mv:SetButtons(bit.bor(mv:GetButtons(), IN_JUMP))
        mv:SetButtons(bit.band(mv:GetButtons(), bit.bnot(IN_DUCK)))
    end
end)

