local matLaser = Material("trails/laser")
local matGlow = Material("sprites/glow04_noz")


local isRenderingAspect = false

hook.Add("RenderScene", "Garrylose_AspectRatio_RenderSceneEngine", function(origin, angles, fov)

    if isRenderingAspect then return end

    if not Garrylose.Config.aspect_ratio_enabled then return end

    local aspect = tonumber(Garrylose.Config.aspect_ratio_val)

    if not aspect or aspect <= 0.05 then return end

    local currentFov = (Garrylose.Config.fov_changer and Garrylose.Config.fov_changer > 0) and Garrylose.Config.fov_changer or fov

    if Garrylose.Config.freecam_enabled then
        return {
            origin = Garrylose.FreecamPos,
            angles = Garrylose.FreecamAng,
            fov = fov,
            drawviewer = true
        }
    end
    local viewAngles = Garrylose.RealViewAngles or angles

    local ply = LocalPlayer()

    local viewOrigin = origin

    if Garrylose.Config.thirdperson_enabled and IsValid(ply) and ply:Alive() then

        local dist = Garrylose.Config.thirdperson_dist or 100

        local tr = util.TraceLine({

            start = origin,

            endpos = origin - (viewAngles:Forward() * dist),

            filter = ply,

            mask = MASK_SOLID

        })

        viewOrigin = tr.HitPos + tr.HitNormal * 4

    end

    local viewData = {

        x = 0,

        y = 0,

        w = ScrW(),

        h = ScrH(),

        origin = viewOrigin,

        angles = viewAngles,

        fov = currentFov,

        drawmonitors = true,

        drawviewmodel = not Garrylose.Config.thirdperson_enabled,

        aspectratio = aspect,

        bloomtone = true

    }

    isRenderingAspect = true

    render.RenderView(viewData)

    pcall(function()

        hook.Run("RenderScreenspaceEffects")

    end)

    render.RenderHUD(0, 0, ScrW(), ScrH())

    isRenderingAspect = false

    return true

end)


local plyMeta = FindMetaTable("Player")
local entMeta = FindMetaTable("Entity")

local orig_PlyEyeAngles = plyMeta and plyMeta.EyeAngles
local orig_EntEyeAngles = entMeta and entMeta.EyeAngles
local orig_EyeAngles = _G.EyeAngles

if plyMeta and orig_PlyEyeAngles then
    function plyMeta:EyeAngles()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles
        end
        return orig_PlyEyeAngles(self)
    end
end

if entMeta and orig_EntEyeAngles then
    function entMeta:EyeAngles()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles
        end
        return orig_EntEyeAngles(self)
    end
end

if orig_EyeAngles then
    function _G.EyeAngles()
        if (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles
        end
        return orig_EyeAngles()
    end
end

local orig_PlyGetAimVector = plyMeta and plyMeta.GetAimVector
local orig_EntGetAimVector = entMeta and entMeta.GetAimVector

if plyMeta and orig_PlyGetAimVector then
    function plyMeta:GetAimVector()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles:Forward()
        end
        return orig_PlyGetAimVector(self)
    end
end

if entMeta and orig_EntGetAimVector then
    function entMeta:GetAimVector()
        if self == LocalPlayer() and (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
            return Garrylose.RealViewAngles:Forward()
        end
        return orig_EntGetAimVector(self)
    end
end

hook.Add("CalcView", "Garrylose_FixCameraView", function(ply, pos, angles, fov)

    if not IsValid(ply) then return end

    if ply:GetMoveType() == MOVETYPE_NOCLIP then return end
    
    if (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent) and Garrylose.RealViewAngles then
        local punch = ply:GetViewPunchAngles() or Angle(0, 0, 0)
        angles = Angle(Garrylose.RealViewAngles.p + punch.p, Garrylose.RealViewAngles.y + punch.y, Garrylose.RealViewAngles.r + punch.r)
    end

    local currentFov = (Garrylose.Config.fov_changer and Garrylose.Config.fov_changer > 0) and Garrylose.Config.fov_changer or fov

    if Garrylose.Config.freecam_enabled then
        return {
            origin = Garrylose.FreecamPos,
            angles = Garrylose.FreecamAng,
            fov = fov,
            drawviewer = true
        }
    end
    local viewAngles = Garrylose.RealViewAngles or angles

    local customAspect = (Garrylose.Config.aspect_ratio_enabled and Garrylose.Config.aspect_ratio_val and Garrylose.Config.aspect_ratio_val > 0) and Garrylose.Config.aspect_ratio_val or nil

    local standingEyePos = ply:GetPos() + Vector(0, 0, 64)

    local isFakeDucking = Garrylose.Config.fakeduck_enabled and ply:OnGround()


    if Garrylose.Config.thirdperson_enabled then

        local dist = Garrylose.Config.thirdperson_dist or 100

        local camOrigin = isFakeDucking and standingEyePos or pos

        local tr = util.TraceLine({

            start = camOrigin,

            endpos = camOrigin - (viewAngles:Forward() * dist),

            filter = ply,

            mask = MASK_SOLID

        })

        local view = {

            origin = tr.HitPos + tr.HitNormal * 4,

            angles = viewAngles,

            fov = currentFov,

            drawviewer = true

        }

        if customAspect then view.aspectratio = customAspect end

        return view

    end

    local camPos = isFakeDucking and standingEyePos or pos

    local view = {

        origin = camPos,

        angles = Garrylose.RealViewAngles or angles,

        fov = currentFov,

        drawviewer = false

    }

    if customAspect then view.aspectratio = customAspect end

    return view

end)



hook.Add("Think", "Garrylose_NoSpread_WeaponCone", function()
    if not Garrylose.Config.nospread_enabled then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) then return end

    if wep.Primary then
        if wep.Primary.Cone and wep.Primary.Cone > 0 then wep.Primary.Cone = 0 end
        if wep.Primary.Spread and wep.Primary.Spread > 0 then wep.Primary.Spread = 0 end
        if wep.Primary.IronAccuracy and wep.Primary.IronAccuracy > 0 then wep.Primary.IronAccuracy = 0 end
    end

    if wep.Secondary then
        if wep.Secondary.Cone and wep.Secondary.Cone > 0 then wep.Secondary.Cone = 0 end
        if wep.Secondary.Spread and wep.Secondary.Spread > 0 then wep.Secondary.Spread = 0 end
    end

    if wep.Cone and wep.Cone > 0 then wep.Cone = 0 end
    if wep.Spread and wep.Spread > 0 then wep.Spread = 0 end
    if wep.Inaccuracy and wep.Inaccuracy > 0 then wep.Inaccuracy = 0 end
    if wep.CurCone and wep.CurCone > 0 then wep.CurCone = 0 end
    if wep.HipSpread and wep.HipSpread > 0 then wep.HipSpread = 0 end
    if wep.AimSpread and wep.AimSpread > 0 then wep.AimSpread = 0 end
    if wep.SpreadModifier and wep.SpreadModifier > 0 then wep.SpreadModifier = 0 end
end)

hook.Add("CalcViewModelView", "Garrylose_FixViewModelView", function(wep, vm, oldPos, oldAng, pos, ang)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local isAAActive = (Garrylose.Config.antiaim_enabled or Garrylose.Config.aimbot_silent)

    local basePos = isAAActive and oldPos or pos
    local baseAng = isAAActive and (Garrylose.RealViewAngles or oldAng) or ang

    local punch = ply:GetViewPunchAngles() or Angle(0, 0, 0)
    local targetAng = Angle(baseAng.p + punch.p, baseAng.y + punch.y, baseAng.r + punch.r)
    local targetPos = Vector(basePos.x, basePos.y, basePos.z)

    if IsValid(wep) and isAAActive then
        if wep.SwayScale and wep.SwayScale > 0 then wep.SwayScale = 0 end
        if wep.BobScale and wep.BobScale > 0 then wep.BobScale = 0 end
    end

    if IsValid(wep) then
        if wep.GetViewModelPosition then
            local p, a = wep:GetViewModelPosition(targetPos * 1, targetAng * 1)
            if p then targetPos = p end
            if a then targetAng = a end
        end
        if wep.CalcViewModelView then
            local p, a = wep:CalcViewModelView(vm, oldPos * 1, oldAng * 1, targetPos * 1, targetAng * 1)
            if p then targetPos = p end
            if a then targetAng = a end
        end
    end

    local vmX = tonumber(Garrylose.Config.viewmodel_x) or 0
    local vmY = tonumber(Garrylose.Config.viewmodel_y) or 0
    local vmZ = tonumber(Garrylose.Config.viewmodel_z) or 0
    if vmX ~= 0 or vmY ~= 0 or vmZ ~= 0 then
        targetPos = targetPos + (targetAng:Right() * vmX) + (targetAng:Forward() * vmY) + (targetAng:Up() * vmZ)
    end

    local vPitch = tonumber(Garrylose.Config.viewmodel_pitch) or 0
    local vYaw = tonumber(Garrylose.Config.viewmodel_yaw) or 0
    local vRoll = tonumber(Garrylose.Config.viewmodel_roll) or 0
    if vPitch ~= 0 or vYaw ~= 0 or vRoll ~= 0 then
        targetAng:RotateAroundAxis(targetAng:Right(), vPitch)
        targetAng:RotateAroundAxis(targetAng:Up(), vYaw)
        targetAng:RotateAroundAxis(targetAng:Forward(), vRoll)
    end

    if IsValid(wep) and Garrylose.Config.viewmodel_fov and Garrylose.Config.viewmodel_fov > 0 then
        wep.ViewModelFOV = Garrylose.Config.viewmodel_fov
    end

    return targetPos, targetAng
end)


Garrylose.Hitmarkers = Garrylose.Hitmarkers or {}

Garrylose.DamageNumbers = Garrylose.DamageNumbers or {}

Garrylose.LastHitTime = 0

Garrylose.LastHitHead = false

Garrylose.LastHitFatal = false

local hitsoundFiles = {

    [1] = "buttons/bell1.wav",

    [2] = "physics/metal/metal_solid_impact_bullet2.wav",

    [3] = "buttons/button15.wav",

    [4] = "garrysmod/balloon_pop.wav",

}

function Garrylose.GetHitsoundOptions()
    local opts = {
        { label = "Bell", data = 1 },
        { label = "Metallic", data = 2 },
        { label = "Click", data = 3 },
        { label = "Balloon Pop", data = 4 }
    }
    local customWavs = file.Find("GLsounds/*.wav", "DATA") or {}
    for i, fn in ipairs(customWavs) do
        table.insert(opts, {
            label = string.StripExtension(fn),
            data = 4 + i,
            dataFile = fn
        })
    end
    return opts
end

function Garrylose.PlayCurrentHitsound()
    local volPct = tonumber(Garrylose.Config.hitsound_volume) or 100
    if volPct <= 0 then return end
    local volNorm = math.Clamp(volPct / 100, 0, 10.0)

    local st = tonumber(Garrylose.Config.hitsound_type) or 1
    if st <= 4 then
        local sf = hitsoundFiles[st] or hitsoundFiles[1]
        sound.PlayFile("sound/" .. sf, "noplay", function(station, errCode, errStr)
            if IsValid(station) then
                station:SetVolume(volNorm)
                station:Play()
            else
                surface.PlaySound(sf)
            end
        end)
        return
    end

    local customWavs = file.Find("GLsounds/*.wav", "DATA") or {}
    local customIdx = st - 4
    local targetFile = customWavs[customIdx]

    if targetFile then
        sound.PlayFile("data/GLsounds/" .. targetFile, "noplay", function(station, errCode, errStr)
            if IsValid(station) then
                station:SetVolume(volNorm)
                station:Play()
            else
                surface.PlaySound("buttons/bell1.wav")
            end
        end)
    else
        surface.PlaySound("buttons/bell1.wav")
    end
end

local lastSoundPlayTime = 0

function Garrylose.SpawnKillEffect(hitPos, isHead)

    if not hitPos or hitPos == Vector(0, 0, 0) then return end

    local effectType = tonumber(Garrylose.Config.killeffect_type) or 1

    local col = Garrylose.Config.col_killeffect or Color(0, 215, 255, 255)

    local dlight = DynamicLight(LocalPlayer():EntIndex() + math.random(1000, 3000))

    if dlight then

        dlight.pos = hitPos + Vector(0, 0, 15)

        dlight.r = col.r

        dlight.g = col.g

        dlight.b = col.b

        dlight.brightness = 5

        dlight.Decay = 1200

        dlight.Size = 280

        dlight.DieTime = CurTime() + 0.6

    end

    if effectType == 1 then


        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetMagnitude(4)

        ed:SetScale(2)

        ed:SetRadius(20)

        util.Effect("Sparks", ed)

        util.Effect("cball_explode", ed)

        sound.Play("ambient/energy/zap" .. math.random(1, 3) .. ".wav", hitPos, 85, math.random(95, 115))

    elseif effectType == 2 then


        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetScale(1.8)

        util.Effect("AR2Explosion", ed)

        sound.Play("weapons/physcannon/energy_sing_explosion2.wav", hitPos, 85, 105)

    elseif effectType == 3 then


        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetScale(3)

        util.Effect("BloodImpact", ed)

        sound.Play("physics/flesh/flesh_squishy_impact_hard" .. math.random(1, 4) .. ".wav", hitPos, 85, 100)

    elseif effectType == 4 then


        local ed = EffectData()

        ed:SetOrigin(hitPos)

        ed:SetScale(2.2)

        util.Effect("cball_bounce", ed)

        sound.Play("weapons/physcannon/energy_bounce" .. math.random(1, 2) .. ".wav", hitPos, 85, 110)

    end

end

function Garrylose.TriggerHit(dmg, isHead, hitPos, isFatal)

    Garrylose.LastHitTime = CurTime()

    Garrylose.LastHitHead = isHead or false

    Garrylose.LastHitFatal = isFatal or false


    if isFatal and Garrylose.Config.killeffect_enabled and hitPos and hitPos ~= Vector(0,0,0) then

        Garrylose.SpawnKillEffect(hitPos, isHead)

    end


    if Garrylose.Config.hitsound_enabled and (CurTime() - lastSoundPlayTime > 0.03) then

        Garrylose.PlayCurrentHitsound()

    end

    if Garrylose.Config.hitmarker_damage_numbers then

        local spawnPos = hitPos or (LocalPlayer():GetShootPos() + LocalPlayer():GetAimVector() * 80)

        table.insert(Garrylose.DamageNumbers, {

            pos = spawnPos + Vector(math.random(-6, 6), math.random(-6, 6), 12),

            dmg = math.Round(dmg or (isFatal and 100 or 25)),

            time = CurTime(),

            isHead = isHead,

            isFatal = isFatal

        })

    end

    if isFatal and Garrylose.TriggerKillsay then

        Garrylose.TriggerKillsay()

    end

end

net.Receive("Garrylose_BulletTracer", function()
    local src = net.ReadVector()
    local dir = net.ReadVector()
    local lp = LocalPlayer()
    local tr = util.TraceLine({
        start = src,
        endpos = src + (dir * 50000),
        filter = lp,
        mask = MASK_SHOT
    })
    if tr and Garrylose.RecordShot then
        Garrylose.RecordShot(src, tr.HitPos)
    end
end)

net.Receive("Garrylose_HitEvent", function()
    local dmg = net.ReadFloat()
    local hitPos = net.ReadVector()
    local isHead = net.ReadBool()
    local isFatal = net.ReadBool()
    if CurTime() - (Garrylose.LastHitTime or 0) > 0.08 then
        Garrylose.TriggerHit(dmg, isHead, hitPos, isFatal)
    end
end)

hook.Add("EntityFireBullets", "Garrylose_Client_BulletImpact", function(ent, data)
    if ent ~= LocalPlayer() then return end

    local wep = ent:GetActiveWeapon()
    if not IsValid(wep) or not Garrylose.IsValidFirearm(wep) then return end
    if Garrylose.IsGrenadeWeapon and Garrylose.IsGrenadeWeapon(wep) then return end

    if Garrylose.Config.nospread_enabled then
        data.Spread = Vector(0, 0, 0)
        if Garrylose.LastShotTargetPos and (CurTime() - (Garrylose.LastShotTime or 0) < 0.15) then
            local shootOrigin = data.Src or ent:GetShootPos()
            data.Dir = (Garrylose.LastShotTargetPos - shootOrigin):GetNormalized()
        elseif Garrylose.CurrentTargetPos then
            local shootOrigin = data.Src or ent:GetShootPos()
            data.Dir = (Garrylose.CurrentTargetPos - shootOrigin):GetNormalized()
        end
    else
        if Garrylose.LastShotTargetPos and (CurTime() - (Garrylose.LastShotTime or 0) < 0.15) then
            local shootOrigin = data.Src or ent:GetShootPos()
            data.Dir = (Garrylose.LastShotTargetPos - shootOrigin):GetNormalized()
        end
    end

    local src = data.Src or ent:GetShootPos()
    local dir = data.Dir or ent:GetAimVector()
    
    local trDirect = util.TraceLine({
        start = src,
        endpos = src + (dir * 50000),
        filter = ent,
        mask = MASK_SHOT
    })
    if trDirect and Garrylose.RecordShot then
        Garrylose.RecordShot(src, trDirect.HitPos)
    end

    local oldCallback = data.Callback
    data.Callback = function(attacker, tr, dmginfo)
        if oldCallback then oldCallback(attacker, tr, dmginfo) end
        if tr and tr.Hit and IsValid(tr.Entity) and tr.Entity ~= LocalPlayer() then
            local e = tr.Entity
            local className = string.lower(e:GetClass() or "")
            if e:IsPlayer() or e:IsNPC() or e:IsNextBot() or e.Type == "nextbot" or string.find(className, "npc_") or string.find(className, "nextbot") or e:IsRagdoll() or string.find(className, "ragdoll") then
                local isHead = (tr.HitGroup == 1 or tr.HitGroup == HITGROUP_HEAD)
                local wepDmg = 25
                local curWep = IsValid(ent) and ent:GetActiveWeapon()
                if IsValid(curWep) then
                    if curWep.Primary and tonumber(curWep.Primary.Damage) and tonumber(curWep.Primary.Damage) > 0 then
                        wepDmg = tonumber(curWep.Primary.Damage)
                    elseif tonumber(curWep.Damage) and tonumber(curWep.Damage) > 0 then
                        wepDmg = tonumber(curWep.Damage)
                    end
                end
                local dmg = (dmginfo and dmginfo:GetDamage() and dmginfo:GetDamage() > 0) and dmginfo:GetDamage() or wepDmg
                if isHead then dmg = math.Round(dmg * 2) end
                local isFatal = (e.Health and e:Health() > 0 and (e:Health() - dmg <= 0)) or e:IsRagdoll()
                Garrylose.TriggerHit(dmg, isHead, tr.HitPos, isFatal)

                local idx = e:EntIndex()
                Garrylose.LastEntityHitTime = Garrylose.LastEntityHitTime or {}
                Garrylose.LastEntityHitTime[idx] = CurTime()
            end
        end
    end

    return true
end)

Garrylose.TrackedTargets = Garrylose.TrackedTargets or {}
Garrylose.LastEntityHitTime = Garrylose.LastEntityHitTime or {}

local nextThinkScan = 0

hook.Add("Think", "Garrylose_Universal_HitTracker", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local curT = CurTime()
    if curT < nextThinkScan then return end
    nextThinkScan = curT + 0.05

    local scanPool = {}
    for _, p in ipairs(player.GetAll()) do
        if IsValid(p) and p ~= ply then scanPool[p] = true end
    end
    for _, ent in ipairs(Garrylose.CachedTargets or {}) do
        if IsValid(ent) and ent ~= ply then scanPool[ent] = true end
    end
    if Garrylose.ActiveNPCs then
        for ent, _ in pairs(Garrylose.ActiveNPCs) do
            if IsValid(ent) then scanPool[ent] = true end
        end
    end

    for ent, _ in pairs(scanPool) do
        local idx = ent:EntIndex()
        local curHp = ent:Health()
        local curPos = ent:WorldSpaceCenter()
        local track = Garrylose.TrackedTargets[idx]
        local lastHit = Garrylose.LastEntityHitTime[idx] or 0

        if track and track.lastHp and curHp < track.lastHp and track.lastHp > 0 then
            local dmg = track.lastHp - curHp
            local isFatal = (curHp <= 0)

            if (curT - lastHit) < 0.12 then
                if #Garrylose.DamageNumbers > 0 then
                    local lastNum = Garrylose.DamageNumbers[#Garrylose.DamageNumbers]
                    if lastNum and (curT - lastNum.time < 0.15) then
                        lastNum.dmg = math.Round(dmg)
                        if isFatal then lastNum.isFatal = true end
                    end
                end
            else
                if Garrylose.CurrentTarget == ent or Garrylose.LastShotTarget == ent or (ply:GetShootPos():DistToSqr(curPos) < 16000000) then
                    Garrylose.TriggerHit(dmg, false, curPos, isFatal)
                    Garrylose.LastEntityHitTime[idx] = curT
                end
            end
        end

        Garrylose.TrackedTargets[idx] = {
            ent = ent,
            lastHp = curHp,
            lastPos = curPos,
            lastSeen = curT
        }
    end

    for idx, data in pairs(Garrylose.TrackedTargets) do
        if not IsValid(data.ent) or data.ent:Health() <= 0 then
            local lastHit = Garrylose.LastEntityHitTime[idx] or 0
            if (curT - lastHit) >= 0.12 and curT - data.lastSeen < 0.45 then
                if data.lastHp and data.lastHp > 0 then
                    if Garrylose.LastShotTarget == data.ent or Garrylose.CurrentTarget == data.ent or (ply:GetShootPos():DistToSqr(data.lastPos) < 16000000) then
                        Garrylose.TriggerHit(data.lastHp, true, data.lastPos, true)
                        Garrylose.LastEntityHitTime[idx] = curT
                    end
                end
            end
            Garrylose.TrackedTargets[idx] = nil
        end
    end
end)

hook.Add("UpdateAnimation", "Garrylose_Spinbot_SyncAnimation", function(ply, velocity, maxSeqGroundSpeed)
    if ply ~= LocalPlayer() then return end
    if not Garrylose.Config.antiaim_enabled or not Garrylose.Config.thirdperson_enabled then return end

    if Garrylose.Config.antiaim_yaw ~= 2 then return end

    if not Garrylose.LastSentFakeAngles then return end

    local fakeYaw = Garrylose.LastSentFakeAngles.y

    local fakePitch = Garrylose.LastSentFakeAngles.p

    ply:SetRenderAngles(Angle(0, fakeYaw, 0))

    ply:SetPoseParameter("head_yaw", 0)

    ply:SetPoseParameter("body_yaw", 0)

    ply:SetPoseParameter("aim_yaw", 0)

    ply:SetPoseParameter("head_pitch", fakePitch)

    ply:SetPoseParameter("aim_pitch", fakePitch)

end)

hook.Add("PrePlayerDraw", "Garrylose_Spinbot_PrePlayerDraw", function(ply)
    if ply == LocalPlayer() and Garrylose.Config.thirdperson_enabled and Garrylose.Config.antiaim_enabled and Garrylose.Config.antiaim_yaw == 2 and Garrylose.LastSentFakeAngles then
        ply:SetRenderAngles(Angle(0, Garrylose.LastSentFakeAngles.y, 0))
    end
end)

local lastMatFullbrightState = false

hook.Add("Think", "Garrylose_Fullbright_Engine", function()
    local isFB = Garrylose.Config.fullbright_enabled
    if isFB ~= lastMatFullbrightState then
        lastMatFullbrightState = isFB
        if isFB then
            RunConsoleCommand("mat_fullbright", "1")
        else
            RunConsoleCommand("mat_fullbright", "0")
        end
    end
end)

local function ApplyNightWorldModulation()
    if Garrylose.Config.fullbright_enabled then
        render.SetLightingMode(1)
        render.SetColorModulation(1, 1, 1)
        render.SetAmbientLight(1, 1, 1)
    elseif Garrylose.Config.nightmode_enabled then
        render.SetLightingMode(0)
        local darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50
        local nightCol = Garrylose.Config.col_nightmode or Color(20, 30, 60, 255)
        local factor = math.Clamp(1.0 - (darkness * 0.85), 0.04, 1.0)
        local r = ((nightCol.r / 255) * factor) * 0.7
        local g = ((nightCol.g / 255) * factor) * 0.7
        local b = ((nightCol.b / 255) * factor) * 0.95
        render.SetColorModulation(r, g, b)
        render.SetAmbientLight(r * 0.5, g * 0.5, b * 0.7)
    else
        render.SetLightingMode(0)
    end
end

local function ResetNightWorldModulation()
    render.SetColorModulation(1, 1, 1)
    render.SetAmbientLight(1, 1, 1)
    render.SetLightingMode(0)
end

hook.Add("PreDrawOpaqueRenderables", "Garrylose_World_PreOpaque", function()

    ApplyNightWorldModulation()

end)

hook.Add("PostDrawOpaqueRenderables", "Garrylose_World_PostOpaque", function()

    ResetNightWorldModulation()

end)

hook.Add("PreDrawTranslucentRenderables", "Garrylose_World_PreTranslucent", function()

    ApplyNightWorldModulation()

end)

local modifiedTransparentProps = {}

function Garrylose.ResetAllTransparentProps()

    for ent, _ in pairs(modifiedTransparentProps) do

        if IsValid(ent) then

            ent:SetRenderMode(RENDERMODE_NORMAL)

            ent:SetColor(Color(255, 255, 255, 255))

        end

    end

    modifiedTransparentProps = {}

end

local lastPropTransState = false

local lastPropAlphaVal = 110

local nextPropScanTime = 0

hook.Add("Think", "Garrylose_PropTransparency_Engine", function()

    local curT = CurTime()

    local isEnabled = Garrylose.Config.prop_transparency_enabled

    local targetAlpha = math.Clamp(tonumber(Garrylose.Config.prop_alpha) or 110, 10, 255)

    if isEnabled then

        if curT >= nextPropScanTime or (lastPropAlphaVal ~= targetAlpha) then

            nextPropScanTime = curT + 0.15

            lastPropAlphaVal = targetAlpha

            local props = ents.FindByClass("prop_physics*")

            table.Add(props, ents.FindByClass("prop_dynamic*"))

            table.Add(props, ents.FindByClass("prop_ragdoll*"))

            for _, ent in ipairs(props) do

                if IsValid(ent) then

                    local curCol = ent:GetColor()

                    if ent:GetRenderMode() ~= RENDERMODE_TRANSCOLOR or curCol.a ~= targetAlpha then

                        ent:SetRenderMode(RENDERMODE_TRANSCOLOR)

                        ent:SetColor(Color(255, 255, 255, targetAlpha))

                        modifiedTransparentProps[ent] = true

                    end

                end

            end

        end

    elseif lastPropTransState then

        Garrylose.ResetAllTransparentProps()

    end

    lastPropTransState = isEnabled

end)

hook.Add("PostDraw2DSkyBox", "Garrylose_CustomSkybox_Render", function()

    if not Garrylose.Config.custom_skybox_enabled then return end

    local skyType = tonumber(Garrylose.Config.custom_skybox_type) or 1

    local skyColors = {

        [1] = Color(10, 12, 30),

        [2] = Color(5, 5, 15),

        [3] = Color(70, 20, 30),

        [4] = Color(40, 10, 65),

        [5] = Color(0, 0, 0),

    }

    local c = skyColors[skyType] or Color(10, 12, 30)

    render.Clear(c.r, c.g, c.b, 255, true, true)

end)

hook.Add("PostDrawTranslucentRenderables", "Garrylose_World_PostTranslucent", function()

    ResetNightWorldModulation()

end)

hook.Add("PreDrawHUD", "Garrylose_World_EnsureHUDReset", function()

    ResetNightWorldModulation()

end)

hook.Add("RenderScreenspaceEffects", "Garrylose_WorldModulation_Effects", function()

    if not Garrylose.Config.nightmode_enabled and not Garrylose.Config.fullbright_enabled then return end

    local darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50

    local isNight = Garrylose.Config.nightmode_enabled

    local isFullbright = Garrylose.Config.fullbright_enabled

    local col = Garrylose.Config.col_nightmode or Color(20, 30, 55, 255)

    local cr = (col.r / 255)

    local cg = (col.g / 255)

    local cb = (col.b / 255)

    local addr = isNight and (cr * darkness * 0.12) or 0

    local addg = isNight and (cg * darkness * 0.12) or 0

    local addb = isNight and (cb * darkness * 0.22) or 0

    local brightness = 0

    local contrast = 1.0

    local colorScale = 1.0

    if isNight then

        brightness = brightness - (darkness * 0.55)

        contrast = contrast + (darkness * 0.40)

        colorScale = math.Clamp(1.0 - (darkness * 0.45), 0.1, 1.0)

    end

    if isFullbright and not isNight then

        brightness = brightness + 0.15

        contrast = contrast + 0.10

        colorScale = colorScale + 0.05

    end

    local colorModify = {

        ["$pp_colour_addr"] = addr,

        ["$pp_colour_addg"] = addg,

        ["$pp_colour_addb"] = addb,

        ["$pp_colour_brightness"] = brightness,

        ["$pp_colour_contrast"] = contrast,

        ["$pp_colour_colour"] = colorScale,

        ["$pp_colour_mulr"] = 0,

        ["$pp_colour_mulg"] = 0,

        ["$pp_colour_mulb"] = 0

    }

    DrawColorModify(colorModify)

end)


hook.Add("SetupWorldFog", "Garrylose_WorldFog_Modulation", function()

    if Garrylose.Config.fog_enabled then

        local fogCol = Garrylose.Config.col_fog or Color(20, 25, 40)

        local density = tonumber(Garrylose.Config.fog_density) or 2200

        render.FogMode(MATERIAL_FOG_LINEAR)

        render.FogStart(100)

        render.FogEnd(density)

        render.FogMaxDensity(0.9)

        render.FogColor(fogCol.r, fogCol.g, fogCol.b)

        return true

    end

end)

hook.Add("SetupSkyboxFog", "Garrylose_SkyboxFog_Modulation", function(scale)

    if Garrylose.Config.fog_enabled then

        local fogCol = Garrylose.Config.col_fog or Color(20, 25, 40)

        local density = (tonumber(Garrylose.Config.fog_density) or 2200) * scale

        render.FogMode(MATERIAL_FOG_LINEAR)

        render.FogStart(50 * scale)

        render.FogEnd(density)

        render.FogMaxDensity(0.9)

        render.FogColor(fogCol.r, fogCol.g, fogCol.b)

        return true

    end

end)


hook.Add("PostDraw2DSkyBox", "Garrylose_Skybox_Modulation", function()

    if Garrylose.Config.skybox_mod_enabled then

        local skyCol = Garrylose.Config.col_skybox or Color(12, 16, 28, 255)

        render.Clear(skyCol.r, skyCol.g, skyCol.b, 255, true, false)

    elseif Garrylose.Config.nightmode_enabled then

        local darkness = tonumber(Garrylose.Config.nightmode_darkness) or 0.50

        local nightSky = Garrylose.Config.col_nightmode or Color(10, 15, 30, 255)

        local factor = math.Clamp(1.0 - (darkness * 0.85), 0.05, 1.0)

        render.Clear(nightSky.r * factor, nightSky.g * factor, nightSky.b * factor, 255, true, false)

    end

end)

hook.Add("PostDrawTranslucentRenderables", "Garrylose_TracersAndImpacts_Render", function(bDepth, bSkybox)
    if bSkybox or bDepth then return end

    local curT = CurTime()

    if Garrylose.Config.bullet_tracers_enabled and Garrylose.BulletTracers then
        local c = Garrylose.Config.col_bullet_tracers or Color(0, 220, 255, 255)

        for i = #Garrylose.BulletTracers, 1, -1 do
            local trItem = Garrylose.BulletTracers[i]
            local age = curT - trItem.time

            if age > trItem.duration then
                table.remove(Garrylose.BulletTracers, i)
            else
                local alpha = math.Clamp(1 - (age / trItem.duration), 0, 1)
                local beamCol = Color(c.r, c.g, c.b, math.floor(255 * alpha))
                local coreCol = Color(255, 255, 255, math.floor(230 * alpha))

                render.SetColorMaterial()
                render.DrawBeam(trItem.startPos, trItem.hitPos, 2.5 * alpha, 0, 1, beamCol)
                render.DrawBeam(trItem.startPos, trItem.hitPos, 0.8 * alpha, 0, 1, coreCol)

                render.SetMaterial(matGlow)
                render.DrawSprite(trItem.hitPos, 8 * alpha, 8 * alpha, beamCol)
                render.DrawSprite(trItem.hitPos, 3 * alpha, 3 * alpha, coreCol)
            end
        end
    end

    if Garrylose.Config.grenade_warning_enabled then

        local warnCol = Garrylose.Config.col_grenade_warning or Color(255, 50, 50, 220)

        local ply = LocalPlayer()

        local myPos = IsValid(ply) and ply:GetPos() or Vector(0,0,0)

        local explosives = {}

        for _, ent in ipairs(ents.FindByClass("npc_grenade_frag")) do table.insert(explosives, { ent = ent, rad = 280, name = "GRENADE" }) end

        for _, ent in ipairs(ents.FindByClass("grenade_hand")) do table.insert(explosives, { ent = ent, rad = 280, name = "GRENADE" }) end

        for _, ent in ipairs(ents.FindByClass("item_ammo_smg1_grenade")) do table.insert(explosives, { ent = ent, rad = 260, name = "SMG GRENADE" }) end

        for _, ent in ipairs(ents.FindByClass("item_ammo_ar2_altfire")) do table.insert(explosives, { ent = ent, rad = 260, name = "COMBINE BALL" }) end

        for _, ent in ipairs(ents.FindByClass("prop_combine_ball")) do table.insert(explosives, { ent = ent, rad = 260, name = "ENERGY BALL" }) end

        for _, ent in ipairs(ents.FindByClass("prop_physics*")) do

            if IsValid(ent) and string.find(string.lower(ent:GetModel() or ""), "oildrum001_explosive") then

                table.insert(explosives, { ent = ent, rad = 350, name = "EXPLOSIVE BARREL" })

            end

        end

        render.SetColorMaterial()

        for _, item in ipairs(explosives) do

            local ent = item.ent

            if IsValid(ent) then

                local ePos = ent:GetPos()

                local dist = myPos:Distance(ePos)

                if dist < 2000 then

                    local pulse = (math.sin(CurTime() * 8) + 1) * 0.5

                    local c = Color(warnCol.r, warnCol.g, warnCol.b, math.floor(180 + pulse * 75))

                    render.DrawWireframeBox(ePos, Angle(0,0,0), Vector(-6,-6,-6), Vector(6,6,6), c, true)


                    local trFloor = util.TraceLine({

                        start = ePos,

                        endpos = ePos - Vector(0, 0, 500),

                        filter = ent,

                        mask = MASK_SOLID_BRUSHONLY

                    })

                    local groundPos = trFloor.Hit and trFloor.HitPos or ePos

                    local rad = item.rad

                    local segs = 32

                    local step = (math.pi * 2) / segs

                    local prevPt = nil

                    for i = 0, segs do

                        local ang = i * step

                        local pt = groundPos + Vector(math.cos(ang) * rad, math.sin(ang) * rad, 1)

                        if prevPt then

                            render.DrawLine(prevPt, pt, c, true)

                            render.DrawLine(prevPt + Vector(0,0,1), pt + Vector(0,0,1), Color(255, 255, 255, 120), true)

                        end

                        prevPt = pt

                    end

                end

            end

        end

    end

    if Garrylose.Config.grenade_pred_enabled then
        local ply = LocalPlayer()
        if IsValid(ply) and ply:Alive() then
            local wep = ply:GetActiveWeapon()
            if IsValid(wep) and Garrylose.IsGrenadeWeapon and Garrylose.IsGrenadeWeapon(wep) then
                local predCol = Garrylose.Config.col_grenade_pred or Color(0, 220, 255, 255)
                local shootPos = ply:GetShootPos()
                local eyeAng = ply:EyeAngles()

                local isUnderhand = ply:KeyDown(IN_ATTACK2)
                local throwSpeed = isUnderhand and 450 or 1200
                local vel = eyeAng:Forward() * throwSpeed + ply:GetVelocity() * 0.9

                local currPos = shootPos
                local grav = Vector(0, 0, -600)
                local stepDt = 0.04
                local maxSteps = 50
                local bounces = 0
                local maxBounces = 4

                local pathPoints = { currPos }
                local hitPoints = {}
                local finalDetonatePos = nil

                for s = 1, maxSteps do
                    local nextPos = currPos + vel * stepDt + 0.5 * grav * (stepDt * stepDt)
                    vel = vel + grav * stepDt

                    local tr = util.TraceHull({
                        start = currPos,
                        endpos = nextPos,
                        mins = Vector(-3, -3, -3),
                        maxs = Vector(3, 3, 3),
                        filter = ply,
                        mask = MASK_SOLID
                    })

                    if tr.Hit then
                        table.insert(pathPoints, tr.HitPos)
                        table.insert(hitPoints, tr.HitPos)
                        bounces = bounces + 1

                        if bounces >= maxBounces or (tr.HitNormal.z > 0.7 and vel:Length() < 120) then
                            finalDetonatePos = tr.HitPos
                            break
                        end

                        vel = (vel - 2 * vel:Dot(tr.HitNormal) * tr.HitNormal) * 0.45
                        currPos = tr.HitPos + tr.HitNormal * 1.5
                    else
                        table.insert(pathPoints, nextPos)
                        currPos = nextPos
                    end
                end

                if not finalDetonatePos and #pathPoints > 0 then
                    finalDetonatePos = pathPoints[#pathPoints]
                end

                if #pathPoints > 1 then
                    render.SetMaterial(matLaser)
                    for idx = 1, #pathPoints - 1 do
                        local pA = pathPoints[idx]
                        local pB = pathPoints[idx + 1]
                        local progress = idx / #pathPoints
                        local segCol = Color(
                            math.floor(predCol.r * (1 - progress * 0.4)),
                            math.floor(predCol.g * (1 - progress * 0.2)),
                            math.floor(predCol.b),
                            220
                        )
                        render.DrawBeam(pA, pB, 3.2, 0, 1, segCol)
                        render.DrawBeam(pA, pB, 1.2, 0, 1, Color(255, 255, 255, 200))
                    end
                end

                render.SetMaterial(matGlow)
                for _, bPos in ipairs(hitPoints) do
                    render.DrawSprite(bPos, 8, 8, predCol)
                    render.DrawSprite(bPos, 3, 3, Color(255, 255, 255, 255))
                end

                if finalDetonatePos then
                    local blastRad = 260
                    local segs = 32
                    local step = (math.pi * 2) / segs
                    local pulse = (math.sin(CurTime() * 6) + 1) * 0.5
                    local blastCol = Color(predCol.r, predCol.g, predCol.b, math.floor(160 + pulse * 80))

                    render.SetColorMaterial()
                    render.DrawBox(finalDetonatePos, Angle(0, 0, 0), Vector(-4, -4, -4), Vector(4, 4, 4), blastCol)
                    render.DrawWireframeBox(finalDetonatePos, Angle(0, 0, 0), Vector(-4, -4, -4), Vector(4, 4, 4), Color(255, 255, 255, 220), true)

                    local prevPt = nil
                    for i = 0, segs do
                        local ang = i * step
                        local pt = finalDetonatePos + Vector(math.cos(ang) * blastRad, math.sin(ang) * blastRad, 2)
                        if prevPt then
                            render.DrawLine(prevPt, pt, blastCol, true)
                            render.DrawLine(prevPt + Vector(0, 0, 1), pt + Vector(0, 0, 1), Color(255, 255, 255, 140), true)
                        end
                        prevPt = pt
                    end

                    render.SetMaterial(matGlow)
                    render.DrawSprite(finalDetonatePos, 14, 14, blastCol)
                    render.DrawSprite(finalDetonatePos, 5, 5, Color(255, 255, 255, 255))
                end
            end
        end
    end

    if Garrylose.Config.bullet_impacts_enabled and Garrylose.BulletImpacts then
        local c = Garrylose.Config.col_bullet_impacts or Color(0, 180, 255, 255)
        local boxVec = Vector(2.0, 2.0, 2.0)
        local boxInner = Vector(1.0, 1.0, 1.0)
        local angZero = Angle(0, 0, 0)

        for i = #Garrylose.BulletImpacts, 1, -1 do
            local imp = Garrylose.BulletImpacts[i]
            local age = curT - imp.time
            if age > imp.duration then
                table.remove(Garrylose.BulletImpacts, i)
            else
                local alpha = math.Clamp(1 - (age / imp.duration), 0, 1)
                local fillCol = Color(c.r, c.g, c.b, math.floor(55 * alpha))
                local edgeCol = Color(c.r, c.g, c.b, math.floor(255 * alpha))
                local coreCol = Color(255, 255, 255, math.floor(200 * alpha))

                render.SetColorMaterial()
                render.DrawBox(imp.pos, angZero, -boxVec, boxVec, fillCol)
                render.DrawWireframeBox(imp.pos, angZero, -boxVec, boxVec, edgeCol, true)
                render.DrawWireframeBox(imp.pos, angZero, -boxInner, boxInner, coreCol, true)

                render.SetMaterial(matGlow)
                render.DrawSprite(imp.pos, 6 * alpha, 6 * alpha, edgeCol)
                render.DrawSprite(imp.pos, 2.5 * alpha, 2.5 * alpha, coreCol)
            end
        end
    end

end)

Garrylose.GhostEntity = Garrylose.GhostEntity or nil

local ghostMaterialWhite = Material("models/debug/debugwhite")

local ghostMaterialWireframe = Material("models/wireframe")

local function GetGhostEntity(ply)

    if not IsValid(ply) then return nil end

    local mdl = ply:GetModel()

    if not mdl or mdl == "" then return nil end

    if not IsValid(Garrylose.GhostEntity) then

        Garrylose.GhostEntity = ClientsideModel(mdl, RENDERGROUP_TRANSLUCENT)

        if IsValid(Garrylose.GhostEntity) then

            Garrylose.GhostEntity:SetNoDraw(true)

        end

    elseif Garrylose.GhostEntity:GetModel() ~= mdl then

        Garrylose.GhostEntity:SetModel(mdl)

    end

    return Garrylose.GhostEntity

end

hook.Add("PostDrawTranslucentRenderables", "Garrylose_DesyncGhost_Render", function(bDepth, bSkybox)

    if bSkybox then return end

    if not Garrylose.Config.desync_ghost_enabled or not Garrylose.Config.thirdperson_enabled or not Garrylose.Config.antiaim_enabled then

        if IsValid(Garrylose.GhostEntity) then

            Garrylose.GhostEntity:SetNoDraw(true)

        end

        return

    end

    local ply = LocalPlayer()

    if not IsValid(ply) or not ply:Alive() then return end

    local ghost = GetGhostEntity(ply)

    if not IsValid(ghost) then return end

    local realAng = Garrylose.RealViewAngles or ply:EyeAngles()

    local ghostCol = Garrylose.Config.col_desync_ghost or Color(0, 230, 255, 140)

    local matMode = tonumber(Garrylose.Config.desync_ghost_mat) or 1


    ghost:SetPos(ply:GetPos())

    ghost:SetAngles(Angle(0, realAng.y, 0))

    ghost:SetSequence(ply:GetSequence())

    ghost:SetCycle(ply:GetCycle())

    ghost:SetPoseParameter("move_x", ply:GetPoseParameter("move_x") or 0)

    ghost:SetPoseParameter("move_y", ply:GetPoseParameter("move_y") or 0)

    ghost:SetPoseParameter("head_pitch", math.Clamp(realAng.p, -89, 89))


    render.SuppressEngineLighting(true)

    render.SetColorModulation(ghostCol.r / 255, ghostCol.g / 255, ghostCol.b / 255)

    render.SetBlend((ghostCol.a or 140) / 255)

    if matMode == 2 then
        render.MaterialOverride(ghostMaterialWireframe)
    else
        render.MaterialOverride(ghostMaterialWhite)
    end
    
    local ok, err = pcall(function() ghost:DrawModel() end)

    render.MaterialOverride(nil)
    render.SetBlend(1)
    render.SetColorModulation(1, 1, 1)
    render.SuppressEngineLighting(false)

end)

hook.Add("ShutDown", "Garrylose_Ghost_Cleanup", function()

    if IsValid(Garrylose.GhostEntity) then

        Garrylose.GhostEntity:Remove()

        Garrylose.GhostEntity = nil

    end

end)

hook.Add("PreDrawHalos", "Garrylose_Glow_ESP", function()

    if not Garrylose.Config.glow_esp_enabled then return end

    local targets = {}

    local col = Garrylose.Config.col_glow_esp or Color(0, 210, 255, 255)

    for _, ent in ipairs(Garrylose.CachedTargets or {}) do

        if IsValid(ent) and ent:Health() > 0 and ent ~= LocalPlayer() then

            table.insert(targets, ent)

        end

    end

    if #targets > 0 then

        halo.Add(targets, col, 2, 2, 2, true, true)

    end

end)

local killsayPhrases = {

    "1 1 1 >> garrylose.cc #1 gmod hvh",

    "missed shot due to spread? never with garrylose.cc",

    "bapped by garrylose.cc neverlose edition",

    "buy garrylose.cc to stop resolving air",

    "get good, get garrylose.cc",

    "owned by garrylose.cc subtick exploit"

}

local lastKillsayTime = 0

Garrylose.TriggerKillsay = function()

    if not Garrylose.Config.killsay_enabled then return end

    if (CurTime() - lastKillsayTime) < 0.6 then return end

    lastKillsayTime = CurTime()

    local msg = killsayPhrases[math.random(#killsayPhrases)]

    RunConsoleCommand("say", msg)

    chat.AddText(Color(0, 180, 255), LocalPlayer():Nick() .. ": ", Color(255, 255, 255), msg)

end

hook.Add("OnNPCKilled", "Garrylose_Killsay_NPC", function(npc, attacker, inflictor)

    if attacker == LocalPlayer() or inflictor == LocalPlayer() then

        Garrylose.TriggerKillsay()

    end

end)


hook.Add("PostDrawTranslucentRenderables", "Garrylose_AutoPeek_RenderVisualizer", function(bDepth, bSkybox)

    if bSkybox then return end

    if not Garrylose.Config.autopeek_enabled or not Garrylose.AutoPeekPos then return end

    local center = Garrylose.AutoPeekPos

    local isReturning = (Garrylose.AutoPeekState == "RETURNING")

    local baseCol = Garrylose.Config.col_autopeek or Color(0, 215, 255, 220)

    local ringCol = isReturning and Color(50, 255, 120, 240) or baseCol

    local radius = 18

    local segments = 24

    render.SetColorMaterial()

    local lastPos = center + Vector(radius, 0, 2)

    for i = 1, segments do

        local rad = math.rad((i / segments) * 360)

        local nextPos = center + Vector(math.cos(rad) * radius, math.sin(rad) * radius, 2)

        render.DrawLine(lastPos, nextPos, ringCol, true)

        lastPos = nextPos

    end

    render.DrawLine(center + Vector(-6, 0, 2), center + Vector(6, 0, 2), ringCol, true)

    render.DrawLine(center + Vector(0, -6, 2), center + Vector(0, 6, 2), ringCol, true)

end)

hook.Add("CalcMainActivity", "Garrylose_Slidewalk_Anim", function(ply, velocity)
    if ply == LocalPlayer() and Garrylose.Config.slidewalk_enabled then
        if ply:OnGround() and velocity:Length2D() > 10 then
            return ACT_HL2MP_IDLE, -1
        end
    end
end)

hook.Add("UpdateAnimation", "Garrylose_Slidewalk_UpdateAnim", function(ply, velocity, maxSeqGroundSpeed)
    if ply ~= LocalPlayer() then return end
    if Garrylose.Config.slidewalk_enabled and ply:OnGround() and velocity:Length2D() > 10 then
        ply:SetPoseParameter("move_x", 0)
        ply:SetPoseParameter("move_y", 0)
        ply:SetPoseParameter("move_yaw", 0)
        ply:SetPoseParameter("move_scale", 0)
        ply:SetPlaybackRate(0)
        return true
    end
end)

Garrylose.JumpCircles = Garrylose.JumpCircles or {}
local lastGround = true
hook.Add("Think", "Garrylose_JumpCircles_Logic", function()
    if not Garrylose.Config.jump_circles then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local onGround = ply:OnGround()
    if onGround and not lastGround then
        table.insert(Garrylose.JumpCircles, { pos = ply:GetPos(), time = CurTime(), radius = 0 })
    end
    lastGround = onGround
end)

hook.Add("PostDrawTranslucentRenderables", "Garrylose_JumpCircles_Draw", function(bDepth, bSky)
    if bSky or not Garrylose.Config.jump_circles then return end
    local c = Garrylose.Config.col_jump_circles or Color(0,255,255)
    for i = #Garrylose.JumpCircles, 1, -1 do
        local circ = Garrylose.JumpCircles[i]
        local age = CurTime() - circ.time
        if age > 1 then table.remove(Garrylose.JumpCircles, i) continue end
        circ.radius = circ.radius + FrameTime() * 150
        local alpha = math.Clamp(255 - (age * 255), 0, 255)
        
        render.SetColorMaterial()
        local segments = 32
        local lastPos = circ.pos + Vector(circ.radius, 0, 1)
        for j = 1, segments do
            local rad = math.rad((j / segments) * 360)
            local nextPos = circ.pos + Vector(math.cos(rad) * circ.radius, math.sin(rad) * circ.radius, 1)
            render.DrawLine(lastPos, nextPos, Color(c.r, c.g, c.b, alpha), true)
            lastPos = nextPos
        end
    end
end)

local worldMats = {}
local worldModState = false
local lastWorldCol = Color(0,0,0)
hook.Add("Think", "Garrylose_WorldMod", function()
    local enabled = Garrylose.Config.worldmod
    local col = Garrylose.Config.col_worldmod or Color(50,50,50)
    
    if enabled then
        if not worldModState or col ~= lastWorldCol then
            if not worldModState then
                for _, matName in ipairs(game.GetWorld():GetMaterials()) do
                    local mat = Material(matName)
                    if mat and not mat:IsError() then
                        worldMats[matName] = mat:GetVector("$color") or Vector(1,1,1)
                    end
                end
            end
            local vec = Vector(col.r/255, col.g/255, col.b/255)
            for matName, _ in pairs(worldMats) do
                local mat = Material(matName)
                if mat then mat:SetVector("$color", vec) end
            end
            worldModState = true
            lastWorldCol = col
        end
    else
        if worldModState then
            for matName, origVec in pairs(worldMats) do
                local mat = Material(matName)
                if mat then mat:SetVector("$color", origVec) end
            end
            worldModState = false
            worldMats = {}
        end
    end
end)

hook.Add("SetupWorldFog", "Garrylose_Fog", function()
    if not Garrylose.Config.fog_enabled then return end
    render.FogMode(MATERIAL_FOG_LINEAR)
    render.FogStart(tonumber(Garrylose.Config.fog_start) or 0)
    render.FogEnd(tonumber(Garrylose.Config.fog_end) or 2000)
    render.FogMaxDensity(tonumber(Garrylose.Config.fog_density) or 1)
    local c = Garrylose.Config.col_fog or Color(100,100,100)
    render.FogColor(c.r, c.g, c.b)
    return true
end)
hook.Add("SetupSkyboxFog", "Garrylose_FogSky", function(scale)
    if not Garrylose.Config.fog_enabled then return end
    render.FogMode(MATERIAL_FOG_LINEAR)
    render.FogStart((tonumber(Garrylose.Config.fog_start) or 0) * scale)
    render.FogEnd((tonumber(Garrylose.Config.fog_end) or 2000) * scale)
    render.FogMaxDensity(tonumber(Garrylose.Config.fog_density) or 1)
    local c = Garrylose.Config.col_fog or Color(100,100,100)
    render.FogColor(c.r, c.g, c.b)
    return true
end)

local matWhite = Material("models/debug/debugwhite")

hook.Add("PreDrawOpaqueRenderables", "Garrylose_SafetyReset_PreOpaque", function()
    render.MaterialOverride(nil)
    render.ModelMaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end)

local function DrawDepthChamEntity(ent, col)
    if not IsValid(ent) or ent:IsDormant() then return end
    render.SuppressEngineLighting(true)
    render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
    render.SetBlend((col.a or 255) / 255)
    render.MaterialOverride(matWhite)

    render.DepthRange(0, 0.01)
    ent:DrawModel()
    local wep = ent.GetActiveWeapon and ent:GetActiveWeapon()
    if IsValid(wep) then wep:DrawModel() end
    render.DepthRange(0, 1)

    render.MaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end

local function IsValidNPCTarget(ent)
    if not IsValid(ent) then return false end
    if ent:IsDormant() or ent:GetNoDraw() then return false end
    
    local c = ent:GetClass()
    if string.find(c, "bullseye") or string.find(c, "maker") or string.find(c, "template") or string.find(c, "spotlight") or string.find(c, "weapon") then
        return false
    end
    
    if ent:IsNPC() or ent:IsNextBot() or string.StartWith(c, "npc_") or string.StartWith(c, "monster_") then
        return true
    end
    
    return false
end

hook.Add("PostDrawOpaqueRenderables", "Garrylose_OpaqueChams", function(bDepth, bSkybox)
    if bSkybox or bDepth or not Garrylose.Config.esp_enabled then return end
    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    if Garrylose.Config.chams_npc then
        local col = Garrylose.Config.col_chams_npc or Color(255, 255, 0, 255)
        for _, ent in ipairs(ents.GetAll()) do
            if IsValidNPCTarget(ent) then
                DrawDepthChamEntity(ent, col)
            end
        end
    end

    if Garrylose.Config.chams_player then
        local col = Garrylose.Config.col_chams_player or Color(0, 255, 0, 255)
        for _, ply in ipairs(player.GetAll()) do
            if ply ~= lp and IsValid(ply) and ply:Alive() and not ply:IsDormant() then
                DrawDepthChamEntity(ply, col)
            end
        end
    end
end)

hook.Add("PrePlayerDraw", "Garrylose_PlayerChams", function(ply, flags)
    if not IsValid(ply) or not Garrylose.Config.esp_enabled then return end
    if ply == LocalPlayer() and Garrylose.Config.chams_self and (Garrylose.Config.thirdperson_enabled or Garrylose.Config.freecam_enabled) then
        local col = Garrylose.Config.col_chams_self or Color(255, 0, 0, 255)
        render.SuppressEngineLighting(true)
        render.MaterialOverride(matWhite)
        render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
        render.SetBlend((col.a or 255) / 255)
    end
end)

hook.Add("PostPlayerDraw", "Garrylose_PlayerChams_Post", function(ply, flags)
    if ply == LocalPlayer() then
        render.MaterialOverride(nil)
        render.SetColorModulation(1, 1, 1)
        render.SetBlend(1)
        render.SuppressEngineLighting(false)
    end
end)

hook.Add("PreDrawPlayerHands", "Garrylose_HandsChams_Apply", function(hands, vm, ply, wep)
    if Garrylose.Config.chams_hands and Garrylose.Config.esp_enabled then
        local col = Garrylose.Config.col_chams_hands or Color(0, 0, 255, 255)
        render.SuppressEngineLighting(true)
        render.ModelMaterialOverride(matWhite)
        render.SetColorModulation(col.r / 255, col.g / 255, col.b / 255)
        render.SetBlend((col.a or 255) / 255)
    end
end)

hook.Add("PostDrawPlayerHands", "Garrylose_HandsChams_Reset", function(hands, vm, ply, wep)
    render.ModelMaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end)

hook.Add("PostDrawViewModel", "Garrylose_ViewModel_SafetyPost", function(vm, ply, wep)
    render.ModelMaterialOverride(nil)
    render.MaterialOverride(nil)
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
    render.SuppressEngineLighting(false)
end)

Garrylose.NothingKeyHeld = false
hook.Add("Think", "Garrylose_Nothing_Logic", function()
    local key = Garrylose.Config.bind_nothing
    if key and key > 0 and input.IsKeyDown(key) then
        if not Garrylose.NothingKeyHeld then
            Garrylose.NothingKeyHeld = true
            Garrylose.Config.nothing_enabled = not Garrylose.Config.nothing_enabled
        end
    else
        Garrylose.NothingKeyHeld = false
    end
end)

Garrylose.NextChatSpam = 0
hook.Add("Think", "Garrylose_ChatSpammer", function()
    if Garrylose.Config.chat_spam and CurTime() > Garrylose.NextChatSpam then
        local txt = Garrylose.Config.chat_spam_text or "Garrylose.cc owns me"
        if txt ~= "" then
            RunConsoleCommand("say", txt)
        end
        Garrylose.NextChatSpam = CurTime() + (tonumber(Garrylose.Config.chat_spam_delay) or 0.5)
    end
end)

local trail_pos = {}
hook.Add("Tick", "Garrylose_MovementTrail_Record", function()
    if not Garrylose.Config.esp_trail then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local max_len = math.min(tonumber(Garrylose.Config.esp_trail_len) or 150, 200)
    table.insert(trail_pos, 1, {pos = ply:GetPos(), time = CurTime()})

    while #trail_pos > max_len do
        table.remove(trail_pos)
    end
end)

local TRAIL_MAT = Material("trails/laser")
hook.Add("PostDrawTranslucentRenderables", "Garrylose_MovementTrail_Render", function(bDepth, bSky)
    if bSky or bDepth or not Garrylose.Config.esp_trail then return end
    
    local n = #trail_pos
    if n < 2 then return end

    local c = Garrylose.Config.col_esp_trail or Color(255, 255, 255)
    local sz = tonumber(Garrylose.Config.esp_trail_size) or 8
    local min_sz = sz * 0.2
    local lifetime = tonumber(Garrylose.Config.esp_trail_fade) or 3.0

    render.SetMaterial(TRAIL_MAT)
    
    for i = 1, n - 1 do
        local p1 = trail_pos[i]
        local p2 = trail_pos[i + 1]
        
        local age = CurTime() - p1.time
        local alpha = 255 - (age / lifetime) * 255
        
        if alpha <= 0 then continue end
        
        local frac = (n - i) / n
        local dyn_sz = min_sz + (sz - min_sz) * frac
        
        render.DrawBeam(p1.pos, p2.pos, dyn_sz, 0, 1, Color(c.r, c.g, c.b, alpha))
    end
end)

Garrylose.PlayHitSound = PlayHitSound
