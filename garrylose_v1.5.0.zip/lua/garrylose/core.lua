Garrylose = Garrylose or {}
Garrylose.Config = Garrylose.Config or {}
Garrylose.Plugins = Garrylose.Plugins or {}
Garrylose.BulletTracers = Garrylose.BulletTracers or {}
Garrylose.BulletImpacts = Garrylose.BulletImpacts or {}
Garrylose.CachedTargets = Garrylose.CachedTargets or {}
Garrylose.RealViewAngles = Garrylose.RealViewAngles or Angle(0, 0, 0)
Garrylose.CurrentTarget = nil
Garrylose.ShotState = false
Garrylose.ManualShotState = false

function Garrylose.PanicUnload()
    hook.Remove("CreateMove", "Garrylose_Core_CreateMove")
    hook.Remove("HUDPaint", "Garrylose_ESP_Paint")
    hook.Remove("Think", "Garrylose_Universal_HitTracker")
    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_World_PostTranslucent")
    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_TracersAndImpacts_Render")
    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_DesyncGhost_Render")
    hook.Remove("PostDrawTranslucentRenderables", "Garrylose_AutoPeek_RenderVisualizer")
    hook.Remove("Think", "Garrylose_PropTransparency_Engine")
    hook.Remove("CalcMainActivity", "Garrylose_Slidewalk_Anim")
    hook.Remove("UpdateAnimation", "Garrylose_Slidewalk_UpdateAnim")
    hook.Remove("EntityFireBullets", "Garrylose_NoSpread_Engine")
    hook.Remove("Think", "Garrylose_NoSpread_WeaponCone")
    if Garrylose.ResetAllTransparentProps then pcall(Garrylose.ResetAllTransparentProps) end
    hook.Remove("PostDraw2DSkyBox", "Garrylose_CustomSkybox_Render")
    hook.Remove("PreDrawHalos", "Garrylose_Glow_ESP")
    hook.Remove("CalcView", "Garrylose_Thirdperson_CalcView")
    hook.Remove("RenderScene", "Garrylose_AspectRatio_Render")
    hook.Remove("RenderScreenspaceEffects", "Garrylose_Nightmode_Visuals")
    hook.Remove("EntityFireBullets", "Garrylose_Client_BulletImpact")

    if IsValid(Garrylose.MenuFrame) then
        Garrylose.MenuFrame:Remove()
        Garrylose.MenuFrame = nil
    end

    if IsValid(Garrylose.GhostEntity) then
        Garrylose.GhostEntity:Remove()
        Garrylose.GhostEntity = nil
    end

    chat.AddText(Color(255, 60, 60), "[GARRYLOSE] ", Color(255, 255, 255), "Cheat cleanly unloaded! All hooks destroyed.")
end

function Garrylose.GetMuzzlePos(ply)
    if not IsValid(ply) then return nil end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) then return ply:GetShootPos() end

    if ply == LocalPlayer() and not (Garrylose.Config and Garrylose.Config.thirdperson_enabled) then
        local vm = ply:GetViewModel()
        if IsValid(vm) then
            local attId = vm:LookupAttachment("muzzle")
            if not attId or attId <= 0 then attId = vm:LookupAttachment("1") end
            if not attId or attId <= 0 then attId = 1 end
            local att = vm:GetAttachment(attId)
            if att and att.Pos and att.Pos:DistToSqr(ply:EyePos()) < 16000 and att.Pos:DistToSqr(ply:EyePos()) > 9 then
                return att.Pos
            end
        end
    else
        local attId = wep:LookupAttachment("muzzle")
        if not attId or attId <= 0 then attId = wep:LookupAttachment("1") end
        if not attId or attId <= 0 then attId = 1 end
        local att = wep:GetAttachment(attId)
        if att and att.Pos and att.Pos:DistToSqr(ply:EyePos()) < 25000 and att.Pos:DistToSqr(ply:EyePos()) > 9 then
            return att.Pos
        end
    end

    return ply:GetShootPos()
end

local nonFirearms = {
    ["weapon_physgun"] = true,
    ["gmod_tool"] = true,
    ["gmod_camera"] = true,
    ["weapon_physcannon"] = true,
    ["weapon_medkit"] = true,
    ["none"] = true,
    ["weapon_crowbar"] = true,
    ["weapon_stunstick"] = true,
    ["weapon_fists"] = true,
    ["weapon_frag"] = true,
    ["weapon_slam"] = true,
}

function Garrylose.IsValidFirearm(wep)
    if not IsValid(wep) then return false end
    local class = string.lower(wep:GetClass() or "")
    if nonFirearms[class] then return false end

    if string.find(class, "knife") or string.find(class, "sword") or string.find(class, "fist") or
       string.find(class, "melee") or string.find(class, "bayonet") or string.find(class, "karambit") or
       string.find(class, "axe") or string.find(class, "bat") or string.find(class, "hammer") or
       string.find(class, "machete") or string.find(class, "grenade") or string.find(class, "frag") or
       string.find(class, "c4") or string.find(class, "bomb") or string.find(class, "ied") or
       string.find(class, "hands") then
        return false
    end

    if wep.IsMelee or wep.IsKnife or wep.Melee then return false end
    return true
end

function Garrylose.RecordShot(startPos, hitPos)
    if not startPos or not hitPos then return end

    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local wep = lp:GetActiveWeapon()
    if not IsValid(wep) or not Garrylose.IsValidFirearm(wep) then
        return
    end
    if Garrylose.IsGrenadeWeapon and Garrylose.IsGrenadeWeapon(wep) then
        return
    end

    local finalStart = startPos
    if IsValid(lp) and Garrylose.GetMuzzlePos then
        local mPos = Garrylose.GetMuzzlePos(lp)
        if mPos then finalStart = mPos end
    end

    local curT = CurTime()
    if Garrylose.LastRecordedShotTime and (curT - Garrylose.LastRecordedShotTime < 0.03) and Garrylose.LastRecordedHitPos and (Garrylose.LastRecordedHitPos:DistToSqr(hitPos) < 256) then
        return
    end
    Garrylose.LastRecordedShotTime = curT
    Garrylose.LastRecordedHitPos = hitPos

    if Garrylose.Config.bullet_tracers_enabled then
        Garrylose.BulletTracers = Garrylose.BulletTracers or {}
        table.insert(Garrylose.BulletTracers, {
            startPos = Vector(finalStart.x, finalStart.y, finalStart.z),
            hitPos = Vector(hitPos.x, hitPos.y, hitPos.z),
            time = curT,
            duration = 2.0
        })
    end

    if Garrylose.Config.bullet_impacts_enabled then
        Garrylose.BulletImpacts = Garrylose.BulletImpacts or {}
        table.insert(Garrylose.BulletImpacts, {
            pos = Vector(hitPos.x, hitPos.y, hitPos.z),
            time = curT,
            duration = 3.5
        })
    end
end


function Garrylose.IsGrenadeWeapon(wep)

    if not IsValid(wep) then return false end

    local class = string.lower(wep:GetClass() or "")

    local hold = string.lower(wep:GetHoldType() or "")

    if hold == "grenade" or hold == "slam" then return true end

    if string.find(class, "grenade") or string.find(class, "frag") or string.find(class, "molotov") 

       or string.find(class, "flash") or string.find(class, "smoke") or string.find(class, "slam") 

       or string.find(class, "bomb") or string.find(class, "pipe") then

        return true

    end

    if wep.IsTFAWeapon and (wep.Type == "Grenade" or wep.Slot == 4) then return true end

    if wep.IsArcCW and (wep.Throwing or wep.Primary.Projectile) then return true end

    if wep.CW20Weapon and wep.Grenade then return true end

    return false

end

local IsGrenadeWeapon = Garrylose.IsGrenadeWeapon

function Garrylose.GetKeyName(key)

    if not key or key == KEY_NONE or key == 0 then return "NONE" end

    if key >= 107 then

        if key == MOUSE_LEFT then return "M1"

        elseif key == MOUSE_RIGHT then return "M2"

        elseif key == MOUSE_MIDDLE then return "M3"

        elseif key == MOUSE_4 then return "M4"

        elseif key == MOUSE_5 then return "M5"

        elseif key == MOUSE_WHEEL_UP then return "MWHEELUP"

        elseif key == MOUSE_WHEEL_DOWN then return "MWHEELWN"

        else return "MOUSE" .. (key - 106) end

    end

    return input.GetKeyName(key) and string.upper(input.GetKeyName(key)) or ("KEY " .. key)

end

Garrylose.ThemeColors = {

    [1] = { name = "Cyan Blue (Neverlose)", accent = Color(0, 180, 255),   glow = Color(0, 180, 255, 120), dim = Color(0, 180, 255, 30),  hov = Color(45, 200, 255) },

    [2] = { name = "Crimson Red",           accent = Color(245, 55, 75),    glow = Color(245, 55, 75, 120), dim = Color(245, 55, 75, 30),  hov = Color(255, 85, 105) },

    [3] = { name = "Purple Violet",         accent = Color(175, 75, 255),   glow = Color(175, 75, 255, 120),dim = Color(175, 75, 255, 30), hov = Color(195, 105, 255) },

    [4] = { name = "Emerald Green",         accent = Color(40, 215, 120),   glow = Color(40, 215, 120, 120),dim = Color(40, 215, 120, 30), hov = Color(70, 235, 145) },

    [5] = { name = "Gold Orange",           accent = Color(255, 165, 0),    glow = Color(255, 165, 0, 120),  dim = Color(255, 165, 0, 30),  hov = Color(255, 190, 45) },

    [6] = { name = "Hot Pink",              accent = Color(255, 60, 160),   glow = Color(255, 60, 160, 120), dim = Color(255, 60, 160, 30), hov = Color(255, 95, 185) }

}

function Garrylose.GetActiveTheme()

    local themeIdx = tonumber(Garrylose.Config.menu_theme) or 1

    if themeIdx == 7 then

        local r = tonumber(Garrylose.Config.custom_accent_r) or 0

        local g = tonumber(Garrylose.Config.custom_accent_g) or 180

        local b = tonumber(Garrylose.Config.custom_accent_b) or 255

        local col = Color(r, g, b, 255)

        local hov = Color(math.min(r + 35, 255), math.min(g + 35, 255), math.min(b + 35, 255), 255)

        local dim = Color(r, g, b, 30)

        local glow = Color(r, g, b, 120)

        return { name = "Custom Color Wheel", accent = col, glow = glow, dim = dim, hov = hov }

    end

    return Garrylose.ThemeColors[themeIdx] or Garrylose.ThemeColors[1]

end

Garrylose.Languages = {

    ["en"] = {

        ["tab_aim"] = "Aimbot",

        ["desc_aim"] = "Ragebot & Targeting",

        ["tab_aa"] = "Anti-Aim",

        ["desc_aa"] = "Desync & Yaw Angles",

        ["tab_vis"] = "Visuals",

        ["desc_vis"] = "ESP, Chams & Camera",

        ["tab_misc"] = "Miscellaneous",

        ["desc_misc"] = "Movement & System",

        ["tab_cfg"] = "Configs",

        ["desc_cfg"] = "Profile Management",

        ["tab_lua"] = "Lua Scripts",

        ["desc_lua"] = "In-Game IDE & Plugins",

        ["tab_opt"] = "Options",

        ["desc_opt"] = "Theme & Localization",

        ["aim_main"] = "Aimbot & Resolver",

        ["aim_targeting"] = "Hitboxes & Targeting",

        ["enable_aim"] = "Enable Aimbot",

        ["silent_aim"] = "Silent Aim",

        ["rcs"] = "Recoil Control (RCS)",

        ["auto_shoot"] = "Auto Shoot",

        ["resolver"] = "HvH Anti-Aim Resolver",

        ["resolver_mode"] = "Resolver Mode",

        ["multipoint"] = "Hitbox Multipoint Scan",

        ["mp_scale"] = "Multipoint Scale",

        ["aim_fov"] = "Aimbot FOV",

        ["fov_circle"] = "Draw FOV Circle",

        ["shoot_mode"] = "Shoot Mode",

        ["wall_check"] = "Wall Check (LoS)",

        ["min_damage"] = "Minimum Damage",

        ["min_damage_override"] = "Min Damage Override",

        ["target_players"] = "Target Players",

        ["team_check"] = "Team Check (Ignore Teammates)",

        ["target_npcs"] = "Target NPCs & Nextbots",

        ["vis_esp"] = "Player & NPC ESP",

        ["vis_world"] = "World & Camera",

        ["enable_esp"] = "Enable ESP",

        ["boxes"] = "2D Boxes",

        ["names_class"] = "Player Names & Class",

        ["health_status"] = "Health Status",

        ["snaplines"] = "Snaplines",

        ["thirdperson"] = "Thirdperson View",

        ["tp_dist"] = "Thirdperson Distance",

        ["cam_fov"] = "Camera FOV Override",

        ["fov_ring"] = "Draw FOV Ring Circle",

        ["misc_move"] = "Movement & Display",

        ["misc_hit"] = "Hit Feedback & System",

        ["bhop"] = "Auto BunnyHop",

        ["autostrafe"] = "Auto Strafer",

        ["strafer_mode"] = "Strafer Mode",

        ["edgejump"] = "Edge Jump",

        ["fakeduck"] = "Fake Duck",

        ["crouchjump"] = "Crouch Jump (Air Duck)",

        ["autopeek"] = "Peek Assist",

        ["pedals"] = "Subtick Exploit (Pedals)",

        ["autoreload"] = "Auto Reload Weapon",

        ["keybinds_hud"] = "Keybinds List (HUD)",

        ["aspect_ratio"] = "Aspect Ratio Override",

        ["aspect_scale"] = "Aspect Ratio",

        ["watermark"] = "Watermark & Speedometer",

        ["hitmarkers"] = "Crosshair Hitmarkers (X)",

        ["dmg_numbers"] = "Floating Damage (-HP)",

        ["hitsounds"] = "Enable Hitsound Audio",

        ["hitsound_preset"] = "Hitsound Preset",

        ["menu_bind"] = "Menu Keybind:",

        ["reset_default"] = "Reset Settings to Default",

        ["opt_theme"] = "Menu Theme & Accent",

        ["opt_lang"] = "Language & Localization",

        ["accent_preset"] = "Accent Color Preset",

        ["ui_language"] = "Interface Language"

    },

    ["ru"] = {

        ["tab_aim"] = "Р С’Р С‘Р СР В±Р С•РЎвЂљ",

        ["desc_aim"] = "Р РЋРЎвЂљРЎР‚Р ВµР В»РЎРЉР В±Р В° Р С‘ Р Р…Р В°Р Р†Р С•Р Т‘Р С”Р В°",

        ["tab_aa"] = "Р С’Р Р…РЎвЂљР С‘-Р С’Р С‘Р СРЎвЂ№",

        ["desc_aa"] = "Р Р€Р С–Р В»РЎвЂ№ Р С‘ Р В·Р В°РЎвЂ°Р С‘РЎвЂљР В°",

        ["tab_vis"] = "Р вЂ™Р С‘Р В·РЎС“Р В°Р В»РЎвЂ№",

        ["desc_vis"] = "ESP, Р В§Р В°Р СРЎРѓРЎвЂ№ Р С‘ Р С”Р В°Р СР ВµРЎР‚Р В°",

        ["tab_misc"] = "Р В Р В°Р В·Р Р…Р С•Р Вµ",

        ["desc_misc"] = "Р вЂќР Р†Р С‘Р В¶Р ВµР Р…Р С‘Р Вµ Р С‘ РЎРѓР С‘РЎРѓРЎвЂљР ВµР СР В°",

        ["tab_cfg"] = "Р С™Р С•Р Р…РЎвЂћР С‘Р С–Р С‘",

        ["desc_cfg"] = "Р Р€Р С—РЎР‚Р В°Р Р†Р В»Р ВµР Р…Р С‘Р Вµ Р С—РЎР‚Р С•РЎвЂћР С‘Р В»РЎРЏР СР С‘",

        ["tab_lua"] = "Lua Р РЋР С”РЎР‚Р С‘Р С—РЎвЂљРЎвЂ№",

        ["desc_lua"] = "IDE Р С‘ Р С—Р В»Р В°Р С–Р С‘Р Р…РЎвЂ№",

        ["tab_opt"] = "Р С›Р С—РЎвЂ Р С‘Р С‘",

        ["desc_opt"] = "Р СћР ВµР СР В° Р С‘ РЎРЏР В·РЎвЂ№Р С” Р СР ВµР Р…РЎР‹",

        ["aim_main"] = "Р С’Р С‘Р СР В±Р С•РЎвЂљ Р С‘ Р В Р ВµР В·Р С•Р В»РЎРЉР Р†Р ВµРЎР‚",

        ["aim_targeting"] = "Р ТђР С‘РЎвЂљР В±Р С•Р С”РЎРѓРЎвЂ№ Р С‘ Р В¦Р ВµР В»Р С‘",

        ["enable_aim"] = "Р вЂ™Р С”Р В»РЎР‹РЎвЂЎР С‘РЎвЂљРЎРЉ Р С’Р С‘Р СР В±Р С•РЎвЂљ",

        ["silent_aim"] = "Р РЋР В°Р в„–Р В»Р ВµР Р…РЎвЂљ Р С’Р С‘Р С",

        ["rcs"] = "Р С™Р С•Р Р…РЎвЂљРЎР‚Р С•Р В»РЎРЉ Р С•РЎвЂљР Т‘Р В°РЎвЂЎР С‘ (RCS)",

        ["auto_shoot"] = "Р С’Р Р†РЎвЂљР С•-Р Р†РЎвЂ№РЎРѓРЎвЂљРЎР‚Р ВµР В»",


        ["resolver"] = "HvH Р В Р ВµР В·Р С•Р В»РЎРЉР Р†Р ВµРЎР‚ РЎС“Р С–Р В»Р С•Р Р†",

        ["resolver_mode"] = "Р В Р ВµР В¶Р С‘Р С РЎР‚Р ВµР В·Р С•Р В»РЎРЉР Р†Р ВµРЎР‚Р В°",

        ["multipoint"] = "Р СљРЎС“Р В»РЎРЉРЎвЂљР С‘Р С—Р С•Р С‘Р Р…РЎвЂљРЎвЂ№ РЎвЂ¦Р С‘РЎвЂљР В±Р С•Р С”РЎРѓР С•Р Р†",

        ["mp_scale"] = "Р В Р В°Р Т‘Р С‘РЎС“РЎРѓ Р СРЎС“Р В»РЎРЉРЎвЂљР С‘Р С—Р С•Р С‘Р Р…РЎвЂљР С•Р Р†",

        ["aim_fov"] = "Р Р€Р С–Р С•Р В» Р С•Р В±Р В·Р С•РЎР‚Р В° (FOV)",

        ["fov_circle"] = "Р С™РЎР‚РЎС“Р С– FOV Р Р…Р В° РЎРЊР С”РЎР‚Р В°Р Р…Р Вµ",

        ["shoot_mode"] = "Р В Р ВµР В¶Р С‘Р С РЎРѓРЎвЂљРЎР‚Р ВµР В»РЎРЉР В±РЎвЂ№",

        ["wall_check"] = "Р СџРЎР‚Р С•Р Р†Р ВµРЎР‚Р С”Р В° Р Р†Р С‘Р Т‘Р С‘Р СР С•РЎРѓРЎвЂљР С‘ (LoS)",

        ["min_damage"] = "Р СљР С‘Р Р…Р С‘Р СР В°Р В»РЎРЉР Р…РЎвЂ№Р в„– РЎС“РЎР‚Р С•Р Р…",

        ["min_damage_override"] = "Р С›Р Р†Р ВµРЎР‚РЎР‚Р В°Р в„–Р Т‘ Р СР С‘Р Р…. РЎС“РЎР‚Р С•Р Р…Р В°",

        ["target_players"] = "Р В¦Р ВµР В»Р С‘РЎвЂљРЎРЉРЎРѓРЎРЏ Р Р† Р С‘Р С–РЎР‚Р С•Р С”Р С•Р Р†",

        ["team_check"] = "Р СџРЎР‚Р С•Р Р†Р ВµРЎР‚Р С”Р В° Р С”Р С•Р СР В°Р Р…Р Т‘РЎвЂ№ (Р СњР Вµ Р В±Р С‘РЎвЂљРЎРЉ РЎРѓР Р†Р С•Р С‘РЎвЂ¦)",

        ["target_npcs"] = "Р В¦Р ВµР В»Р С‘РЎвЂљРЎРЉРЎРѓРЎРЏ Р Р† NPC Р С‘ Р В±Р С•РЎвЂљР С•Р Р†",

        ["vis_esp"] = "ESP Р ВР С–РЎР‚Р С•Р С”Р С•Р Р† Р С‘ NPC",

        ["vis_world"] = "Р СљР С‘РЎР‚ Р С‘ Р С™Р В°Р СР ВµРЎР‚Р В°",

        ["enable_esp"] = "Р вЂ™Р С”Р В»РЎР‹РЎвЂЎР С‘РЎвЂљРЎРЉ ESP",

        ["boxes"] = "2D Р вЂР С•Р С”РЎРѓРЎвЂ№",

        ["names_class"] = "Р ВР СР ВµР Р…Р В° Р С‘ Р С”Р В»Р В°РЎРѓРЎРѓ РЎвЂ Р ВµР В»Р С‘",

        ["health_status"] = "Р СџР С•Р В»Р С•РЎРѓР В° Р В·Р Т‘Р С•РЎР‚Р С•Р Р†РЎРЉРЎРЏ",

        ["snaplines"] = "Р вЂєР С‘Р Р…Р С‘Р С‘ Р С” РЎвЂ Р ВµР В»Р С‘",

        ["thirdperson"] = "Р вЂ™Р С‘Р Т‘ Р С•РЎвЂљ 3-Р С–Р С• Р В»Р С‘РЎвЂ Р В°",

        ["tp_dist"] = "Р вЂќР С‘РЎРѓРЎвЂљР В°Р Р…РЎвЂ Р С‘РЎРЏ Р С”Р В°Р СР ВµРЎР‚РЎвЂ№",

        ["cam_fov"] = "Р Р€Р С–Р С•Р В» Р С•Р В±Р В·Р С•РЎР‚Р В° Р С”Р В°Р СР ВµРЎР‚РЎвЂ№",

        ["fov_ring"] = "Р С™РЎР‚РЎС“Р С– FOV Р Р…Р В° РЎРЊР С”РЎР‚Р В°Р Р…Р Вµ",

        ["misc_move"] = "Р вЂќР Р†Р С‘Р В¶Р ВµР Р…Р С‘Р Вµ Р С‘ Р В­Р С”РЎР‚Р В°Р Р…",

        ["misc_hit"] = "Р С›РЎвЂљР С”Р В»Р С‘Р С” Р С—Р С•Р С—Р В°Р Т‘Р В°Р Р…Р С‘Р в„– Р С‘ Р РЋР С‘РЎРѓРЎвЂљР ВµР СР В°",

        ["bhop"] = "Р С’Р Р†РЎвЂљР С•-РЎР‚Р В°РЎРѓР С—РЎР‚РЎвЂ№Р В¶Р С”Р В° (Bhop)",

        ["autostrafe"] = "Р С’Р Р†РЎвЂљР С•-РЎРѓРЎвЂљРЎР‚Р ВµР в„–РЎвЂћР ВµРЎР‚",

        ["strafer_mode"] = "Р В Р ВµР В¶Р С‘Р С РЎРѓРЎвЂљРЎР‚Р ВµР в„–РЎвЂћР ВµРЎР‚Р В°",

        ["edgejump"] = "Р СџРЎР‚РЎвЂ№Р В¶Р С•Р С” РЎРѓ Р С”РЎР‚Р В°РЎРЏ (Edge Jump)",

        ["fakeduck"] = "Р В¤Р ВµР в„–Р С”-Р С—РЎР‚Р С‘РЎРѓР ВµР Т‘ (Fake Duck)",

        ["crouchjump"] = "Crouch Jump (Air Duck)",

        ["autopeek"] = "Р С’Р Р†РЎвЂљР С•-Р С—Р С‘Р С” (Quick Peek)",

        ["pedals"] = "Subtick Exploit (Р СџР ВµР Т‘Р В°Р В»Р С‘)",

        ["autoreload"] = "Р С’Р Р†РЎвЂљР С•-Р С—Р ВµРЎР‚Р ВµР В·Р В°РЎР‚РЎРЏР Т‘Р С”Р В°",

        ["keybinds_hud"] = "Р РЋР С—Р С‘РЎРѓР С•Р С” Р В±Р С‘Р Р…Р Т‘Р С•Р Р† (HUD)",

        ["aspect_ratio"] = "Р В Р В°РЎРѓРЎвЂљРЎРЏР В¶Р ВµР Р…Р С‘Р Вµ РЎРЊР С”РЎР‚Р В°Р Р…Р В° (Aspect)",

        ["aspect_scale"] = "Р РЋР С•Р С•РЎвЂљР Р…Р С•РЎв‚¬Р ВµР Р…Р С‘Р Вµ РЎРѓРЎвЂљР С•РЎР‚Р С•Р Р…",

        ["watermark"] = "Р вЂ™Р В°РЎвЂљР ВµРЎР‚Р СР В°РЎР‚Р С” Р С‘ РЎРѓР С—Р С‘Р Т‘Р С•Р СР ВµРЎвЂљРЎР‚",

        ["hitmarkers"] = "Р ТђР С‘РЎвЂљР СР В°РЎР‚Р С”Р ВµРЎР‚ Р Р…Р В° Р С—РЎР‚Р С‘РЎвЂ Р ВµР В»Р Вµ (X)",

        ["dmg_numbers"] = "Р вЂ™РЎРѓР С—Р В»РЎвЂ№Р Р†Р В°РЎР‹РЎвЂ°Р С‘Р в„– РЎС“РЎР‚Р С•Р Р… (-HP)",

        ["hitsounds"] = "Р вЂ”Р Р†РЎС“Р С”Р С‘ Р С—Р С•Р С—Р В°Р Т‘Р В°Р Р…Р С‘РЎРЏ (Hitsound)",

        ["hitsound_preset"] = "Р СџРЎР‚Р ВµРЎРѓР ВµРЎвЂљ Р В·Р Р†РЎС“Р С”Р В°",

        ["menu_bind"] = "Р С™Р В»Р В°Р Р†Р С‘РЎв‚¬Р В° Р С•РЎвЂљР С”РЎР‚РЎвЂ№РЎвЂљР С‘РЎРЏ Р СР ВµР Р…РЎР‹:",

        ["reset_default"] = "Р РЋР В±РЎР‚Р С•РЎРѓР С‘РЎвЂљРЎРЉ Р Р…Р В°РЎРѓРЎвЂљРЎР‚Р С•Р в„–Р С”Р С‘",

        ["opt_theme"] = "Р В¦Р Р†Р ВµРЎвЂљР С•Р Р†Р В°РЎРЏ РЎвЂљР ВµР СР В° Р СР ВµР Р…РЎР‹",

        ["opt_lang"] = "Р Р‡Р В·РЎвЂ№Р С” Р С‘Р Р…РЎвЂљР ВµРЎР‚РЎвЂћР ВµР в„–РЎРѓР В°",

        ["accent_preset"] = "Р С›РЎРѓР Р…Р С•Р Р†Р Р…Р С•Р в„– РЎвЂ Р Р†Р ВµРЎвЂљ Р В°Р С”РЎвЂ Р ВµР Р…РЎвЂљР В°",

        ["ui_language"] = "Р вЂ™РЎвЂ№Р В±Р С•РЎР‚ РЎРЏР В·РЎвЂ№Р С”Р В° (Language)"

    }

}

function Garrylose.L(key, fallback)

    local lang = Garrylose.Config.language or "ru"

    local dict = Garrylose.Languages[lang] or Garrylose.Languages["ru"]

    return dict[key] or fallback or key

end

hook.Add("OnPlayerChat", "Garrylose_ChatCommands", function(ply, text, teamOnly, isDead)

    if ply == LocalPlayer() then

        local cmd = string.lower(string.Trim(text))

        if cmd == "!menu" or cmd == "/menu" or cmd == ".menu" or cmd == "!garrylose" or cmd == "/garrylose" or cmd == ".garrylose" or cmd == "!hvh" or cmd == "/hvh" or cmd == "-menu" then

            Garrylose.ToggleMenu()

            return true

        end

    end

end)

function Garrylose.RegisterPlugin(id, pluginTable)

    Garrylose.Plugins[id] = pluginTable

    Garrylose.Plugins[id].enabled = pluginTable.enabled or false

    print("[Garrylose] Loaded Custom Plugin: " .. (pluginTable.name or id))

end

Garrylose.RegisterPlugin("fov_ring", {

    name = "Custom FOV Ring",

    author = "Garrylose Dev",

    enabled = true,

    onHUDPaint = function()

        if not Garrylose.Config.aimbot_enabled then return end

        local ply = LocalPlayer()

        if not IsValid(ply) then return end

        local currentFov = ply:GetFOV() or 90

        if currentFov <= 0 then currentFov = 90 end

        local aimFov = tonumber(Garrylose.Config.aimbot_fov) or 90

        local fovRadius = math.tan(math.rad(aimFov / 2)) / math.tan(math.rad(currentFov / 2)) * (ScrW() / 2)

        local ringCol = Garrylose.Config.col_fov_ring or Color(0, 190, 255, 140)

        surface.SetDrawColor(ringCol)

        local cx, cy = ScrW() / 2, ScrH() / 2

        local segments = 64

        for i = 1, segments do

            local a1 = math.rad((i - 1) * (360 / segments))

            local a2 = math.rad(i * (360 / segments))

            surface.DrawLine(cx + math.cos(a1) * fovRadius, cy + math.sin(a1) * fovRadius,

                             cx + math.cos(a2) * fovRadius, cy + math.sin(a2) * fovRadius)

        end

    end

})
