local IsGrenadeWeapon = Garrylose.IsGrenadeWeapon
local GetActiveBindsList = Garrylose.GetActiveBindsList
local GetKeyName = Garrylose.GetKeyName

hook.Add("HUDPaint", "Garrylose_Core_HUDPaint", function()

    local ply = LocalPlayer()

    if not IsValid(ply) then return end

    local currentHitbox = tonumber(Garrylose.Config.aimbot_hitbox) or 1

    if Garrylose.Config.esp_enabled then


        if Garrylose.Config.offscreen_esp_enabled then
            local center = Vector(ScrW() / 2, ScrH() / 2, 0)
            local offCol = Garrylose.Config.col_offscreen_esp or Color(255, 60, 90, 255)
            local radius = tonumber(Garrylose.Config.offscreen_esp_radius) or 240
            local userSize = tonumber(Garrylose.Config.offscreen_esp_size) or 14

            for _, ent in ipairs(Garrylose.CachedTargets) do
                if IsValid(ent) and ent:Health() > 0 and ent ~= ply then
                    local targetPos = ent:WorldSpaceCenter()
                    local toTarget = (targetPos - ply:GetShootPos()):Angle()
                    local diffYaw = math.AngleDifference(toTarget.y, (Garrylose.RealViewAngles or ply:EyeAngles()).y)
                    local screen = targetPos:ToScreen()

                    if not screen.visible or screen.x < 50 or screen.x > ScrW() - 50 or screen.y < 50 or screen.y > ScrH() - 50 then
                        local rad = math.rad(-diffYaw - 90)
                        local ax = center.x + math.cos(rad) * radius
                        local ay = center.y + math.sin(rad) * radius

                        local forwardVec = Vector(math.cos(rad), math.sin(rad), 0)
                        local rightVec = Vector(-math.sin(rad), math.cos(rad), 0)

                        local out1 = Vector(ax, ay, 0) + forwardVec * (userSize + 2)
                        local out2 = Vector(ax, ay, 0) - forwardVec * ((userSize + 2) * 0.5) + rightVec * ((userSize + 2) * 0.7)
                        local out3 = Vector(ax, ay, 0) - forwardVec * ((userSize + 2) * 0.5) - rightVec * ((userSize + 2) * 0.7)

                        local p1 = Vector(ax, ay, 0) + forwardVec * userSize
                        local p2 = Vector(ax, ay, 0) - forwardVec * (userSize * 0.5) + rightVec * (userSize * 0.65)
                        local p3 = Vector(ax, ay, 0) - forwardVec * (userSize * 0.5) - rightVec * (userSize * 0.65)

                        local c1 = Vector(ax, ay, 0) + forwardVec * (userSize * 0.5)
                        local c2 = Vector(ax, ay, 0) - forwardVec * (userSize * 0.2) + rightVec * (userSize * 0.3)
                        local c3 = Vector(ax, ay, 0) - forwardVec * (userSize * 0.2) - rightVec * (userSize * 0.3)

                        draw.NoTexture()
                        surface.SetDrawColor(Color(0, 0, 0, 220))
                        surface.DrawPoly({
                            { x = out1.x, y = out1.y },
                            { x = out2.x, y = out2.y },
                            { x = out3.x, y = out3.y }
                        })

                        surface.SetDrawColor(offCol)
                        surface.DrawPoly({
                            { x = p1.x, y = p1.y },
                            { x = p2.x, y = p2.y },
                            { x = p3.x, y = p3.y }
                        })

                        surface.SetDrawColor(Color(255, 255, 255, 140))
                        surface.DrawPoly({
                            { x = c1.x, y = c1.y },
                            { x = c2.x, y = c2.y },
                            { x = c3.x, y = c3.y }
                        })

                        local distMeters = math.max(1, math.floor(ply:GetPos():Distance(targetPos) * 0.0254))
                        draw.SimpleText(distMeters .. "m", "DermaDefault", ax, ay + userSize * 0.65, Color(240, 240, 240, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                    end
                end
            end
        end

        for _, ent in ipairs(Garrylose.CachedTargets) do

            if IsValid(ent) then

                local pos = ent:GetPos()

                local height = ent:OBBMaxs().z

                if height <= 20 then height = 72 end

                local screenPos = pos:ToScreen()

                local headPos = (pos + Vector(0, 0, height + 4)):ToScreen()

                if screenPos.visible or headPos.visible then

                    local h = math.abs(screenPos.y - headPos.y)

                    local w = math.max(h / 2, 14)

                    local boxCol = Garrylose.Config.col_esp_boxes or Color(0, 210, 255, 255)

                    local snapCol = Garrylose.Config.col_esp_snaplines or Color(0, 210, 255, 200)


                    if Garrylose.Config.esp_boxes then

                        surface.SetDrawColor(boxCol)

                        surface.DrawOutlinedRect(screenPos.x - w / 2, headPos.y, w, h)

                    end

                    if Garrylose.Config.esp_box_fill then
                        local colFill = Garrylose.Config.col_esp_box_fill or Color(255, 255, 255, 30)
                        surface.SetDrawColor(colFill)
                        surface.DrawRect(screenPos.x - w / 2, headPos.y, w, h)
                    end


                    local nameCol = Garrylose.Config.col_esp_names or Color(240, 245, 255, 255)

                    local hpCol = Garrylose.Config.col_esp_health or Color(0, 230, 180, 255)

                    local snapCol = Garrylose.Config.col_esp_snaplines or Color(0, 210, 255, 255)


                    if Garrylose.Config.esp_skeleton and ent.LookupBone and ent:LookupBone("ValveBiped.Bip01_Head1") then

                        local skelCol = Garrylose.Config.col_esp_skeleton or Color(255, 255, 255, 220)

                        surface.SetDrawColor(skelCol)

                        local bones = {

                            {"ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1"},

                            {"ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Spine4"},

                            {"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_Spine2"},

                            {"ValveBiped.Bip01_Spine2", "ValveBiped.Bip01_Pelvis"},

                            {"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_L_UpperArm"},

                            {"ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm"},

                            {"ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand"},

                            {"ValveBiped.Bip01_Spine4", "ValveBiped.Bip01_R_UpperArm"},

                            {"ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm"},

                            {"ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand"},

                            {"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh"},

                            {"ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf"},

                            {"ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot"},

                            {"ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh"},

                            {"ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf"},

                            {"ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot"}

                        }

                        for _, pair in ipairs(bones) do

                            local b1 = ent:LookupBone(pair[1])

                            local b2 = ent:LookupBone(pair[2])

                            if b1 and b2 then

                                local p1 = ent:GetBonePosition(b1)

                                local p2 = ent:GetBonePosition(b2)

                                if p1 and p2 then

                                    local s1 = p1:ToScreen()

                                    local s2 = p2:ToScreen()

                                    if s1.visible and s2.visible then

                                        surface.DrawLine(s1.x, s1.y, s2.x, s2.y)

                                    end

                                end

                            end

                        end

                    end


                    if Garrylose.Config.esp_names then

                        local name = ent:IsPlayer() and ent:Nick() or ent:GetClass()

                        draw.SimpleText(name, "DefaultFixed", screenPos.x, headPos.y - 14, nameCol, TEXT_ALIGN_CENTER)

                    end


                    if Garrylose.Config.esp_health then

                        local hp = ent:Health()

                        if hp > 0 then

                            draw.SimpleText("HP: " .. hp, "DefaultFixed", screenPos.x, screenPos.y + 4, hpCol, TEXT_ALIGN_CENTER)

                        end

                    end


                    if Garrylose.Config.esp_weapon_info and ent.GetActiveWeapon then

                        local wep = ent:GetActiveWeapon()

                        if IsValid(wep) then

                            local wName = string.upper(string.Replace(wep:GetClass() or "", "weapon_", ""))

                            local clip = wep:Clip1()

                            local maxClip = wep:GetMaxClip1()

                            local txt = (clip >= 0) and (wName .. " [" .. clip .. "]") or wName

                            local wCol = Garrylose.Config.col_esp_weapon or Color(240, 245, 255, 255)

                            local yOff = (Garrylose.Config.esp_health and 16 or 4)

                            draw.SimpleText(txt, "DefaultFixed", screenPos.x, screenPos.y + yOff, wCol, TEXT_ALIGN_CENTER)


                            if Garrylose.Config.esp_ammo and clip >= 0 and maxClip > 0 then

                                local ammoPct = math.Clamp(clip / maxClip, 0, 1)

                                local barW = w

                                local barH = 3

                                local barX = screenPos.x - w / 2

                                local barY = screenPos.y + yOff + 13

                                local ammoCol = Garrylose.Config.col_esp_ammo or Color(255, 180, 40, 255)

                                surface.SetDrawColor(0, 0, 0, 200)

                                surface.DrawRect(barX - 1, barY - 1, barW + 2, barH + 2)

                                surface.SetDrawColor(ammoCol)

                                surface.DrawRect(barX, barY, math.max(barW * ammoPct, 1), barH)

                            end

                        end

                    end


                    if Garrylose.Config.esp_snaplines then

                        surface.SetDrawColor(snapCol)

                        surface.DrawLine(ScrW() / 2, ScrH(), screenPos.x, screenPos.y)

                    end

                end

            end

        end

    end

    local cx, cy = ScrW() / 2, ScrH() / 2

    local curTime = CurTime()

    if Garrylose.Config.hitmarker_enabled and Garrylose.LastHitTime > 0 then

        local delta = curTime - Garrylose.LastHitTime

        local dur = 0.35

        if delta < dur then

            local alpha = (1 - (delta / dur)) * 255

            local baseCol = Garrylose.Config.col_hitmarker or Color(255, 255, 255, 255)

            local col = Color(baseCol.r, baseCol.g, baseCol.b, (baseCol.a / 255) * alpha)

            surface.SetDrawColor(col)

            local gap = 4

            local len = 8

            surface.DrawLine(cx - gap, cy - gap, cx - gap - len, cy - gap - len)

            surface.DrawLine(cx + gap, cy - gap, cx + gap + len, cy - gap - len)

            surface.DrawLine(cx - gap, cy + gap, cx - gap - len, cy + gap + len)

            surface.DrawLine(cx + gap, cy + gap, cx + gap + len, cy + gap + len)

        end

    end

    if Garrylose.Config.hitmarker_damage_numbers and #Garrylose.DamageNumbers > 0 then

        for i = #Garrylose.DamageNumbers, 1, -1 do

            local item = Garrylose.DamageNumbers[i]

            local age = curTime - item.time

            local lifetime = 1.0

            if age > lifetime then

                table.remove(Garrylose.DamageNumbers, i)

            else

                local progress = age / lifetime

                local floatPos = item.pos + Vector(0, 0, progress * 35)

                local scr = floatPos:ToScreen()

                if scr.visible then

                    local alpha = (1 - progress) * 255

                    local text = "- " .. tostring(item.dmg)

                    if item.isFatal then

                        text = text .. " [KILL]"

                    elseif item.isHead then

                        text = text .. " [HEAD]"

                    end

                    local baseCol = Garrylose.Config.col_dmg_numbers or Color(255, 255, 255, 255)

                    local col = Color(baseCol.r, baseCol.g, baseCol.b, (baseCol.a / 255) * alpha)

                    draw.SimpleTextOutlined(text, "DermaDefaultBold", scr.x, scr.y, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, alpha))

                end

            end

        end

    end

    local curTheme = Garrylose.GetActiveTheme()

    local themeAccent = curTheme.accent or Color(0, 180, 255, 255)

    if Garrylose.Config.watermark_enabled then

        local speed = math.Round(ply:GetVelocity():Length2D())

        local wmText = "GARRYLOSE.cc | v1.5.0 | FPS: " .. math.Round(1 / math.max(FrameTime(), 0.001)) .. " | Speed: " .. speed .. " u/s"

        surface.SetFont("DermaDefaultBold")

        local tw, th = surface.GetTextSize(wmText)

        draw.RoundedBox(6, ScrW() - tw - 25, 15, tw + 15, th + 10, Color(11, 14, 20, 240))

        surface.SetDrawColor(themeAccent)

        surface.DrawOutlinedRect(ScrW() - tw - 25, 15, tw + 15, th + 10)

        draw.RoundedBox(2, ScrW() - tw - 20, 19, 3, th + 2, themeAccent)

        draw.SimpleText(wmText, "DermaDefaultBold", ScrW() - tw - 13, 20, Color(230, 240, 255), TEXT_ALIGN_LEFT)

    end

    if Garrylose.Config.radar_enabled then

        local rx = Garrylose.Config.radar_pos_x or 24

        local ry = Garrylose.Config.radar_pos_y or 65

        local rSize = tonumber(Garrylose.Config.radar_size) or 140

        local rRadius = rSize / 2

        local rRange = tonumber(Garrylose.Config.radar_range) or 2500

        local cx = rx + rRadius

        local cy = ry + rRadius

        local localPly = LocalPlayer()

        local myPos = localPly:GetPos()

        local viewAng = EyeAngles()

        local myYawAng = Angle(0, viewAng.y, 0)

        local fwdVec = myYawAng:Forward()

        local rgtVec = myYawAng:Right()


        draw.RoundedBox(6, rx, ry, rSize, rSize, Color(12, 16, 24, 235))

        surface.SetDrawColor(curTheme.dim or Color(35, 45, 65, 200))

        surface.DrawOutlinedRect(rx, ry, rSize, rSize)


        surface.SetDrawColor(Color(55, 70, 95, 90))

        surface.DrawLine(cx, ry + 4, cx, ry + rSize - 4)

        surface.DrawLine(rx + 4, cy, rx + rSize - 4, cy)


        surface.DrawCircle(cx, cy, rRadius * 0.45, 55, 70, 95, 50)

        surface.DrawCircle(cx, cy, rRadius * 0.85, 55, 70, 95, 70)

        draw.RoundedBox(2, cx - 2, cy - 2, 4, 4, curTheme.accent or Color(0, 220, 255))

        surface.SetDrawColor(curTheme.accent or Color(0, 220, 255))

        surface.DrawLine(cx, cy, cx, cy - 7)


        local targetMode = Garrylose.Config.radar_target_mode or 1

        local colPlayers = Garrylose.Config.col_radar_players or Color(245, 55, 75, 255)

        local colNPCs = Garrylose.Config.col_radar_npcs or Color(255, 185, 45, 255)

        for _, ent in ipairs(Garrylose.CachedTargets or {}) do

            if IsValid(ent) and ent ~= localPly and ent:Health() > 0 then

                local isPlayer = ent:IsPlayer()

                local isNPC = ent:IsNPC() or ent:IsNextBot() or ent.Type == "nextbot"

                local show = false

                if targetMode == 1 and (isPlayer or isNPC) then

                    show = true

                elseif targetMode == 2 and isPlayer then

                    show = true

                elseif targetMode == 3 and isNPC then

                    show = true

                end

                if show then

                    local entPos = ent:GetPos()

                    local diff = entPos - myPos

                    local dist = diff:Length2D()

                    if dist <= rRange then


                        local forwardDist = diff:Dot(fwdVec)

                        local rightDist = diff:Dot(rgtVec)

                        local scale = (rRadius * 0.85) / rRange

                        local blipX = cx + (rightDist * scale)

                        local blipY = cy - (forwardDist * scale)


                        blipX = math.Clamp(blipX, rx + 4, rx + rSize - 4)

                        blipY = math.Clamp(blipY, ry + 4, ry + rSize - 4)

                        local blipCol = isPlayer and colPlayers or colNPCs

                        draw.RoundedBox(3, blipX - 3, blipY - 3, 6, 6, blipCol)

                        surface.SetDrawColor(Color(0, 0, 0, 180))

                        surface.DrawOutlinedRect(blipX - 3, blipY - 3, 6, 6)


                        local entFwd = ent:EyeAngles():Forward()

                        local entFwdRel = entFwd:Dot(fwdVec)

                        local entRgtRel = entFwd:Dot(rgtVec)

                        local pX = blipX + (entRgtRel * 6)

                        local pY = blipY - (entFwdRel * 6)

                        surface.SetDrawColor(blipCol)

                        surface.DrawLine(blipX, blipY, pX, pY)

                    end

                end

            end

        end

        draw.SimpleText("RADAR", "DefaultFixed", rx + 6, ry + 4, Color(130, 150, 180, 180), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

    end

    if Garrylose.Config.grenade_warning_enabled then

        local myPos = ply:GetPos()

        local isNearBlast = false

        for _, ent in ipairs(ents.FindByClass("npc_grenade_frag")) do if IsValid(ent) and ent:GetPos():Distance(myPos) < 320 then isNearBlast = true break end end

        if not isNearBlast then for _, ent in ipairs(ents.FindByClass("grenade_hand")) do if IsValid(ent) and ent:GetPos():Distance(myPos) < 320 then isNearBlast = true break end end end

        if not isNearBlast then for _, ent in ipairs(ents.FindByClass("item_ammo_ar2_altfire")) do if IsValid(ent) and ent:GetPos():Distance(myPos) < 300 then isNearBlast = true break end end end

        if isNearBlast then

            local pulse = (math.sin(CurTime() * 12) + 1) * 0.5

            local warnCol = Color(255, 40 + math.floor(pulse * 60), 40, 240)

            local bannerY = ScrH() * 0.28

            draw.RoundedBox(6, ScrW()/2 - 160, bannerY - 14, 320, 28, Color(20, 0, 0, 220))

            surface.SetDrawColor(warnCol)

            surface.DrawOutlinedRect(ScrW()/2 - 160, bannerY - 14, 320, 28)

            draw.SimpleText("⚠ DANGER: GRENADE BLAST RADIUS ⚠", "DermaDefaultBold", ScrW()/2, bannerY, warnCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        end

    end

    if Garrylose.Config.spectator_list_enabled then

        Garrylose.SpectatorStartTime = Garrylose.SpectatorStartTime or CurTime()

        local elapsed = CurTime() - Garrylose.SpectatorStartTime

        local specs = {}

        for _, p in ipairs(player.GetAll()) do

            if IsValid(p) and p ~= ply and p:GetObserverTarget() == ply then

                table.insert(specs, { name = p:Nick(), col = Color(220, 235, 255, 255) })

            end

        end

        if elapsed >= 5 then

            table.insert(specs, { name = "meaty", col = Color(255, 55, 55, 255) })

        end

        if elapsed >= 10 then

            table.insert(specs, { name = "The Watcher", col = Color(185, 85, 255, 255) })

        end

        local spW = 175

        local spH = 28 + (math.max(#specs, 1) * 20) + 4

        local spX = ScrW() - spW - 20

        local spY = 70

        local hudAccent = (Garrylose.GetActiveTheme and Garrylose.GetActiveTheme().accent) or Color(0, 180, 255, 255)

        draw.RoundedBox(6, spX, spY, spW, spH, Color(11, 14, 20, 240))

        surface.SetDrawColor(hudAccent)

        surface.DrawOutlinedRect(spX, spY, spW, spH)


        draw.SimpleText("SPECTATORS (" .. #specs .. ")", "DefaultFixed", spX + 8, spY + 7, hudAccent, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        surface.SetDrawColor(40, 50, 70, 200)

        surface.DrawLine(spX + 4, spY + 24, spX + spW - 4, spY + 24)

        if #specs == 0 then

            draw.SimpleText("None", "DefaultFixed", spX + 12, spY + 28, Color(120, 135, 160, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

        else

            local rowY = spY + 28

            for _, s in ipairs(specs) do

                draw.SimpleText(s.name, "DefaultFixed", spX + 12, rowY, s.col, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)

                rowY = rowY + 20

            end

        end

    else

        Garrylose.SpectatorStartTime = nil

    end

    if Garrylose.Config.indicators_enabled ~= false then

        local indX = ScrW() / 2

        local indY = ScrH() / 2 + 45


        if Garrylose.Config.fakeduck_enabled then

            draw.SimpleTextOutlined("FD", "DermaDefaultBold", indX, indY, Color(255, 160, 20, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))

            indY = indY + 15

        end

        if Garrylose.Config.manual_aa_arrows then

            local mainCol = Garrylose.Config.col_manual_arrows or Color(0, 215, 255, 255)

            local baseCol = Color(mainCol.r, mainCol.g, mainCol.b, 255)

            local dimCol  = Color(mainCol.r, mainCol.g, mainCol.b, 50)

            local shadowCol = Color(0, 0, 0, 180)

            local cx = ScrW() / 2

            local cy = ScrH() / 2

            local dist = 55

            local aaState = tonumber(Garrylose.Config.manual_aa_state) or 0

            local function DrawArrow(xPeak, yPeak, xBase1, yBase1, xBase2, yBase2, isActive)

                local col = isActive and baseCol or dimCol

                draw.NoTexture()


                local dx1 = (xPeak > cx) and 2 or ((xPeak < cx) and -2 or 0)

                local dy1 = (yPeak > cy) and 2 or ((yPeak < cy) and -2 or 0)

                surface.SetDrawColor(shadowCol)

                surface.DrawPoly({

                    { x = xPeak + dx1, y = yPeak + dy1 },

                    { x = xBase1, y = yBase1 },

                    { x = xBase2, y = yBase2 }

                })


                surface.SetDrawColor(col)

                surface.DrawPoly({

                    { x = xPeak, y = yPeak },

                    { x = xBase1, y = yBase1 },

                    { x = xBase2, y = yBase2 }

                })

            end

            local size = 12

            local hSize = 9

            local isL = (aaState == 1)

            local lSize = isL and (size + 3) or size

            local lHSize = isL and (hSize + 2) or hSize

            DrawArrow(

                cx - dist - lSize, cy,

                cx - dist + 2, cy - lHSize,

                cx - dist + 2, cy + lHSize,

                isL

            )

            local isR = (aaState == 2)

            local rSize = isR and (size + 3) or size

            local rHSize = isR and (hSize + 2) or hSize

            DrawArrow(

                cx + dist + rSize, cy,

                cx + dist - 2, cy + rHSize,

                cx + dist - 2, cy - rHSize,

                isR

            )

            local isB = (aaState == 3)

            local bSize = isB and (size + 3) or size

            local bHSize = isB and (hSize + 2) or hSize

            DrawArrow(

                cx, cy + dist + bSize,

                cx - bHSize, cy + dist - 2,

                cx + bHSize, cy + dist - 2,

                isB

            )

        end


        if Garrylose.Config.min_damage_override_active then

            local dmgVal = Garrylose.Config.aimbot_min_damage_override or 1

            draw.SimpleTextOutlined("DMG: " .. dmgVal, "DermaDefaultBold", indX, indY, Color(255, 220, 50, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))

            indY = indY + 15

        end


        if Garrylose.Config.hitchance_override_active then

            local hcVal = Garrylose.Config.aimbot_hitchance_override or 20

            draw.SimpleTextOutlined("HC: " .. hcVal .. "%", "DermaDefaultBold", indX, indY, Color(0, 220, 255, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))

            indY = indY + 15

        end

        if Garrylose.Config.jumpbug_enabled then
            local lp = LocalPlayer()
            if IsValid(lp) and lp:Alive() and not lp:OnGround() and lp:GetVelocity().z < -100 then
                local jbCol = Garrylose.JumpBugActive and Color(50, 255, 100, 255) or Color(0, 220, 255, 220)
                local jbText = Garrylose.JumpBugActive and "JB [BUG]" or "JB"
                draw.SimpleTextOutlined(jbText, "DermaDefaultBold", indX, indY, jbCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP, 1, Color(0, 0, 0, 200))
                indY = indY + 15
            end
        end

    end

    if Garrylose.Config.keybinds_list_enabled then

        local activeBinds = {}

        local curTheme = Garrylose.GetActiveTheme()

        local themeAccent = curTheme.accent or Color(0, 180, 255, 255)

        local features = {

            { name = "Aimbot",        config = "aimbot_enabled",             bind = "bind_aimbot" },

            { name = "Night-Mode",    config = "nightmode_enabled",          bind = "bind_nightmode" },

            { name = "Anti-Aim",      config = "antiaim_enabled",            bind = "bind_antiaim" },

            { name = "Peek-Assist",  config = "autopeek_enabled",           bind = "bind_autopeek" },

            { name = "Min-Damage",    config = "min_damage_override_active", bind = "bind_min_damage_override", checkHold = true },

            { name = "HC-Override",   config = "hitchance_override_active",  bind = "bind_hitchance_override", checkHold = true },

            { name = "Triggerbot",    config = "triggerbot_enabled",         bind = "bind_triggerbot" },

            { name = "Air-Stop",      config = "airstop_enabled",            bind = "bind_airstop", checkHold = true },

            { name = "Fake-Duck",     config = "fakeduck_enabled",           bind = "bind_fakeduck" },

            { name = "Edge-Jump",     config = "edgejump_enabled",           bind = "bind_edgejump" },

            { name = "Crouch-Jump",   config = "crouchjump_enabled",         bind = "bind_crouchjump" },
            { name = "Jump-Bug",      config = "jumpbug_enabled",            bind = "bind_jumpbug" },

            { name = "Thirdperson",   config = "thirdperson_enabled",        bind = "bind_thirdperson" },

            { name = "Auto-Strafe",   config = "autostrafe_enabled",         bind = "bind_autostrafe" },

            { name = "Auto-Bhop",     config = "bhop_enabled",               bind = "bind_bhop" },

            { name = "Player ESP",    config = "esp_enabled",                bind = "bind_esp" },

            { name = "Manual AA L",   config = "manual_aa_state",            bind = "bind_manual_left",  customCheck = function() return Garrylose.Config.manual_aa_state == 1 end },

            { name = "Manual AA R",   config = "manual_aa_state",            bind = "bind_manual_right", customCheck = function() return Garrylose.Config.manual_aa_state == 2 end },

            { name = "Manual AA B",   config = "manual_aa_state",            bind = "bind_manual_back",  customCheck = function() return Garrylose.Config.manual_aa_state == 3 end },

        }

        for _, f in ipairs(features) do

            local key = Garrylose.Config[f.bind]

            local hasKey = (key and key ~= KEY_NONE and key ~= 0 and key ~= -1)

            if hasKey then

                local state = false

                if f.customCheck then

                    state = f.customCheck()

                else

                    state = Garrylose.Config[f.config] and true or false

                end

                if f.checkHold then

                    local isHeld = false

                    pcall(function()

                        if (key >= 107 and input.IsMouseDown(key)) or (key < 107 and input.IsKeyDown(key)) or input.IsButtonDown(key) then

                            isHeld = true

                        end

                    end)

                    state = state or isHeld

                end

                local kName = Garrylose.GetKeyName(key)

                local keyBadge = "[" .. kName .. "]"

                local activeColor = Color(50, 240, 110)

                local inactiveColor = Color(115, 130, 150)

                table.insert(activeBinds, {

                    name = f.name,

                    keyText = keyBadge,

                    state = state,

                    keyCol = state and activeColor or inactiveColor,

                    nameCol = state and Color(245, 252, 255) or Color(135, 145, 165)

                })

            end

        end


        Garrylose.KeybindsPos = Garrylose.KeybindsPos or {

            x = tonumber(Garrylose.Config.keybinds_x) or 30,

            y = tonumber(Garrylose.Config.keybinds_y) or (ScrH() / 2 - 80)

        }

        local kW = 205

        local rowH = 22

        local itemsCount = math.max(#activeBinds, 1)

        local kH = 28 + (itemsCount * rowH) + 6

        local kX = Garrylose.KeybindsPos.x

        local kY = Garrylose.KeybindsPos.y


        if vgui.CursorVisible() then

            local mx, my = gui.MousePos()

            if input.IsMouseDown(MOUSE_LEFT) then

                if not Garrylose.IsDraggingKeybinds then

                    if mx >= kX and mx <= kX + kW and my >= kY and my <= kY + 28 then

                        Garrylose.IsDraggingKeybinds = true

                        Garrylose.DragOffset = { x = mx - kX, y = my - kY }

                    end

                else

                    Garrylose.KeybindsPos.x = math.Clamp(mx - Garrylose.DragOffset.x, 0, ScrW() - kW)

                    Garrylose.KeybindsPos.y = math.Clamp(my - Garrylose.DragOffset.y, 0, ScrH() - kH)

                    Garrylose.Config.keybinds_x = Garrylose.KeybindsPos.x

                    Garrylose.Config.keybinds_y = Garrylose.KeybindsPos.y

                    kX = Garrylose.KeybindsPos.x

                    kY = Garrylose.KeybindsPos.y

                end

            else

                Garrylose.IsDraggingKeybinds = false

            end

        else

            Garrylose.IsDraggingKeybinds = false

        end

        draw.RoundedBox(6, kX, kY, kW, kH, Color(11, 14, 20, 245))

        surface.SetDrawColor(Color(28, 38, 56, 255))

        surface.DrawOutlinedRect(kX, kY, kW, kH)

        draw.RoundedBoxEx(6, kX, kY, kW, 26, Color(18, 24, 34, 255), true, true, false, false)

        surface.SetDrawColor(themeAccent)

        surface.DrawLine(kX + 1, kY + 26, kX + kW - 1, kY + 26)


        draw.RoundedBox(2, kX + 8, kY + 8, 3, 10, themeAccent)

        draw.SimpleText("KEYBINDS", "DermaDefaultBold", kX + 16, kY + 13, Color(235, 245, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

        draw.SimpleText("[" .. #activeBinds .. "]", "DefaultFixed", kX + kW - 8, kY + 13, themeAccent, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

        if #activeBinds == 0 then

            draw.SimpleText("No bound keys", "DefaultFixed", kX + kW / 2, kY + 38, Color(125, 145, 170), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        else

            for idx, b in ipairs(activeBinds) do

                local rY = kY + 28 + (idx - 1) * rowH + 11

                if b.state then

                    draw.RoundedBox(4, kX + 5, rY - 9, kW - 10, rowH - 2, Color(50, 240, 110, 15))

                end

                draw.SimpleText(b.name, "DermaDefaultBold", kX + 10, rY, b.nameCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                draw.SimpleText(b.keyText, "DefaultFixed", kX + kW - 10, rY, b.keyCol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)

            end

        end

    end

    if Garrylose.Config.aimbot_enabled and Garrylose.Config.draw_fov_ring then

        local fovVal = tonumber(Garrylose.Config.aimbot_fov) or 90

        local plyFov = (IsValid(ply) and ply:GetFOV()) or 90

        if plyFov <= 0 then plyFov = 90 end

        local fovRadius = math.tan(math.rad(fovVal / 2)) / math.tan(math.rad(plyFov / 2)) * (ScrH() / 2)

        local ringCol = Garrylose.Config.col_fov_ring or Color(0, 190, 255, 140)

        surface.SetDrawColor(ringCol)

        local cx, cy = ScrW() / 2, ScrH() / 2

        local segments = 64

        local poly = {}

        for i = 1, segments do

            local a = math.rad((i / segments) * 360)

            table.insert(poly, {

                x = cx + math.cos(a) * fovRadius,

                y = cy + math.sin(a) * fovRadius

            })

        end

        for i = 1, #poly do

            local nextPt = poly[i + 1] or poly[1]

            surface.DrawLine(poly[i].x, poly[i].y, nextPt.x, nextPt.y)

        end

    end

    for id, plugin in pairs(Garrylose.Plugins) do

        if plugin.enabled and plugin.onHUDPaint then

            pcall(plugin.onHUDPaint)

        end

    end

end)
