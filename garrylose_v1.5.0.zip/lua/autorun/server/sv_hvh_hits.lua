util.AddNetworkString("Garrylose_HitEvent")
util.AddNetworkString("Garrylose_BulletTracer")

hook.Add("EntityTakeDamage", "Garrylose_Server_EntityTakeDamage", function(target, dmginfo)
    if not IsValid(target) or not dmginfo then return end

    local attacker = dmginfo:GetAttacker()
    if IsValid(attacker) and attacker:IsPlayer() and attacker ~= target then
        local dmg = dmginfo:GetDamage()
        local hitPos = dmginfo:GetDamagePosition()
        if not hitPos or hitPos == Vector(0,0,0) then
            hitPos = target:WorldSpaceCenter()
        end

        local isFatal = (target:Health() - dmg <= 0)
        local isHead = (target:LastHitGroup() == HITGROUP_HEAD)

        net.Start("Garrylose_HitEvent")
            net.WriteFloat(dmg)
            net.WriteVector(hitPos)
            net.WriteBool(isHead)
            net.WriteBool(isFatal)
        net.Send(attacker)
    end
end)

hook.Add("PlayerDeath", "Garrylose_Server_PlayerDeath", function(victim, inflictor, attacker)
    if IsValid(attacker) and attacker:IsPlayer() and attacker ~= victim then
        net.Start("Garrylose_HitEvent")
            net.WriteFloat(100)
            net.WriteVector(victim:WorldSpaceCenter())
            net.WriteBool(victim:LastHitGroup() == HITGROUP_HEAD)
            net.WriteBool(true)
        net.Send(attacker)
    end
end)

hook.Add("OnNPCKilled", "Garrylose_Server_OnNPCKilled", function(npc, attacker, inflictor)
    if IsValid(attacker) and attacker:IsPlayer() and IsValid(npc) then
        net.Start("Garrylose_HitEvent")
            net.WriteFloat(100)
            net.WriteVector(npc:WorldSpaceCenter())
            net.WriteBool(npc:LastHitGroup() == HITGROUP_HEAD)
            net.WriteBool(true)
        net.Send(attacker)
    end
end)

local nonFirearms = {
    ["weapon_physgun"] = true,
    ["gmod_tool"] = true,
    ["gmod_camera"] = true,
    ["weapon_physcannon"] = true,
    ["weapon_medkit"] = true,
    ["none"] = true,
    ["weapon_crowbar"] = true,
    ["weapon_stunstick"] = true,
    ["weapon_fists"] = true,
    ["weapon_frag"] = true,
    ["weapon_slam"] = true,
}

local function IsValidFirearm(wep)
    if not IsValid(wep) then return false end
    local class = string.lower(wep:GetClass() or "")
    if nonFirearms[class] then return false end
    if string.find(class, "knife") or string.find(class, "sword") or string.find(class, "melee") or string.find(class, "fist") then
        return false
    end
    return true
end

hook.Add("EntityFireBullets", "Garrylose_Server_BulletTracers", function(ent, data)
    if not IsValid(ent) or not ent:IsPlayer() then return end
    local wep = ent:GetActiveWeapon()
    if not IsValidFirearm(wep) then return end
    net.Start("Garrylose_BulletTracer")
        net.WriteVector(data.Src)
        net.WriteVector(data.Dir or ent:GetAimVector())
    net.Send(ent)
end)

hook.Add("GetFallDamage", "Garrylose_Server_GetFallDamage", function(ply, speed)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if ply:KeyDown(IN_JUMP) then
        return 0
    end
end)

hook.Add("OnPlayerHitGround", "Garrylose_Server_OnPlayerHitGround", function(ply, inWater, onFloater, speed)
    if not IsValid(ply) or not ply:IsPlayer() then return end
    if ply:KeyDown(IN_JUMP) and speed > 180 then
        timer.Simple(0, function()
            if IsValid(ply) and ply:Alive() then
                local v = ply:GetVelocity()
                ply:SetVelocity(Vector(0, 0, 180 - v.z))
            end
        end)
    end
end)
