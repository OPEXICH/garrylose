ENT.Base = "base_nextbot"
ENT.Type = "nextbot"
ENT.PrintName = "HvH Bot"
ENT.Author = "Garrylose"
ENT.Category = "Garrylose HvH"
ENT.Spawnable = true
