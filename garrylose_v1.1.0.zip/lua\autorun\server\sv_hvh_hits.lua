util.AddNetworkString("Garrylose_HitEvent")
util.AddNetworkString("Garrylose_DoubleTapFire")
util.AddNetworkString("Garrylose_BulletTracer")

hook.Add("EntityTakeDamage", "Garrylose_Server_EntityTakeDamage", function(target, dmginfo)
    if not IsValid(target) or not dmginfo then return end

    local attacker = dmginfo:GetAttacker()
    if IsValid(attacker) and attacker:IsPlayer() and attacker ~= target then
        local dmg = dmginfo:GetDamage()
        local hitPos = dmginfo:GetDamagePosition()
        if not hitPos or hitPos == Vector(0,0,0) then
            hitPos = target:WorldSpaceCenter()
        end

        local isFatal = (target:Health() - dmg <= 0)
        local isHead = (target.LastHitGroup and isfunction(target.LastHitGroup) and target:LastHitGroup() == HITGROUP_HEAD) or false

        net.Start("Garrylose_HitEvent")
            net.WriteFloat(dmg)
            net.WriteVector(hitPos)
            net.WriteBool(isHead)
            net.WriteBool(isFatal)
        net.Send(attacker)
    end
end)

hook.Add("PlayerDeath", "Garrylose_Server_PlayerDeath", function(victim, inflictor, attacker)
    if IsValid(attacker) and attacker:IsPlayer() and attacker ~= victim then
        local isHead = (victim.LastHitGroup and isfunction(victim.LastHitGroup) and victim:LastHitGroup() == HITGROUP_HEAD) or false
        net.Start("Garrylose_HitEvent")
            net.WriteFloat(100)
            net.WriteVector(victim:WorldSpaceCenter())
            net.WriteBool(isHead)
            net.WriteBool(true)
        net.Send(attacker)
    end
end)

hook.Add("OnNPCKilled", "Garrylose_Server_OnNPCKilled", function(npc, attacker, inflictor)
    if IsValid(attacker) and attacker:IsPlayer() and IsValid(npc) then
        local isHead = (npc.LastHitGroup and isfunction(npc.LastHitGroup) and npc:LastHitGroup() == HITGROUP_HEAD) or false
        net.Start("Garrylose_HitEvent")
            net.WriteFloat(100)
            net.WriteVector(npc:WorldSpaceCenter())
            net.WriteBool(isHead)
            net.WriteBool(true)
        net.Send(attacker)
    end
end)

local function IsValidFirearm(wep)
    if not IsValid(wep) then return false end
    local class = string.lower(wep:GetClass() or "")
    if class == "weapon_physgun" or class == "gmod_tool" or class == "gmod_camera" or class == "weapon_physcannon" or class == "weapon_medkit" or class == "none" then
        return false
    end
    return true
end

net.Receive("Garrylose_DoubleTapFire", function(len, ply)
    if not IsValid(ply) or not ply:Alive() then return end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or not IsValidFirearm(wep) then return end

    local targetPos = net.ReadVector()
    local isHead = net.ReadBool()

    local clip1 = wep:Clip1()
    if clip1 == 0 then return end

    if wep.SetNextPrimaryFire then
        wep:SetNextPrimaryFire(CurTime() - 0.1)
    end
    if wep.SetNextSecondaryFire then
        wep:SetNextSecondaryFire(CurTime() - 0.1)
    end

    timer.Simple(0.035, function()
        if not IsValid(ply) or not ply:Alive() then return end
        local curWep = ply:GetActiveWeapon()
        if not IsValid(curWep) or curWep ~= wep then return end
        if curWep:Clip1() == 0 then return end

        if curWep.SetNextPrimaryFire then
            curWep:SetNextPrimaryFire(CurTime() - 0.1)
        end

        local firedViaSWEP = false
        if curWep.PrimaryAttack and isfunction(curWep.PrimaryAttack) then
            pcall(function()
                curWep:PrimaryAttack()
                firedViaSWEP = true
            end)
        end

        if not firedViaSWEP then
            local shootPos = ply:GetShootPos()
            local shootDir = ply:GetAimVector()
            if targetPos and targetPos ~= Vector(0, 0, 0) then
                shootDir = (targetPos - shootPos):GetNormalized()
            end

            local class = curWep:GetClass()
            local bulletDmg = 35
            local bulletNum = 1
            local bulletSpread = Vector(0.01, 0.01, 0)
            local soundName = "Weapon_Pistol.Single"

            if class == "weapon_357" then
                bulletDmg = 75
                soundName = "Weapon_357.Single"
            elseif class == "weapon_smg1" then
                bulletDmg = 15
                soundName = "Weapon_SMG1.Single"
            elseif class == "weapon_ar2" then
                bulletDmg = 20
                soundName = "Weapon_AR2.Single"
            elseif class == "weapon_shotgun" then
                bulletDmg = 11
                bulletNum = 7
                bulletSpread = Vector(0.05, 0.05, 0)
                soundName = "Weapon_Shotgun.Single"
            elseif class == "weapon_crossbow" then
                bulletDmg = 100
                soundName = "Weapon_Crossbow.Single"
            end

            local bullet = {}
            bullet.Num = bulletNum
            bullet.Src = shootPos
            bullet.Dir = shootDir
            bullet.Spread = bulletSpread
            bullet.Tracer = 1
            bullet.TracerName = "Tracer"
            bullet.Force = 10
            bullet.Damage = bulletDmg
            bullet.Attacker = ply
            bullet.Inflictor = curWep

            ply:FireBullets(bullet)
            curWep:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
            ply:SetAnimation(PLAYER_ATTACK1)
            ply:EmitSound(soundName, 75, 100, 1, CHAN_WEAPON)

            if curWep.TakePrimaryAmmo then
                curWep:TakePrimaryAmmo(1)
            elseif curWep.SetClip1 and curWep:Clip1() > 0 then
                curWep:SetClip1(curWep:Clip1() - 1)
            end
        end
    end)
end)

hook.Add("EntityFireBullets", "Garrylose_Server_BulletTracers", function(ent, data)
    if not IsValid(ent) or not ent:IsPlayer() then return end
    net.Start("Garrylose_BulletTracer", true)
        net.WriteVector(data.Src)
        net.WriteVector(data.Dir or ent:GetAimVector())
    net.Send(ent)
end)

hook.Add("GetFallDamage", "Garrylose_Server_GetFallDamage", function(ply, speed)
    if IsValid(ply) and ply:IsPlayer() then
        -- Safe fall damage handling
    end
end)
