AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/player/phoenix.mdl")
    self:SetHealth(100)
    self:SetMaxHealth(100)
    self:SetCollisionBounds(Vector(-16, -16, 0), Vector(16, 16, 72))
    self:SetSolid(SOLID_BBOX)
    self:SetCollisionGroup(COLLISION_GROUP_NPC)
    self:SetBloodColor(BLOOD_COLOR_RED)
    
    timer.Simple(0.1, function()
        if IsValid(self) then
            local wep = ents.Create("weapon_smg1")
            if IsValid(wep) then
                wep:SetPos(self:GetPos())
                wep:SetOwner(self)
                wep:Spawn()
                wep:SetParent(self)
                wep:Fire("setparentattachment", "anim_attachment_RH")
                self.WeaponEnt = wep
            end
        end
    end)
    
    self.SpinYaw = 0
    self.NextAttack = 0
    self.IsKilled = false
end

function ENT:OnRemove()
    if IsValid(self.WeaponEnt) then
        self.WeaponEnt:Remove()
    end
end

function ENT:OnInjured(dmginfo)
    if self.IsKilled then return end

    local dmg = (dmginfo and dmginfo:GetDamage()) or 25
    if dmg <= 0 then dmg = 25 end

    if dmginfo and dmginfo:IsDamageType(DMG_BULLET) and self:LastHitGroup() == HITGROUP_HEAD then
        dmg = dmg * 2.5
    end

    local newHp = self:Health() - dmg
    self:SetHealth(math.max(newHp, 0))

    if newHp <= 0 then
        self:OnKilled(dmginfo)
    end
end

function ENT:OnTakeDamage(dmginfo)
    self:OnInjured(dmginfo)
    return (dmginfo and dmginfo:GetDamage()) or 25
end

function ENT:OnKilled(dmginfo)
    if self.IsKilled then return end
    self.IsKilled = true

    if IsValid(self.WeaponEnt) then
        self.WeaponEnt:Remove()
    end

    pcall(function()
        if dmginfo then
            hook.Run("OnNPCKilled", self, dmginfo:GetAttacker(), dmginfo:GetInflictor())
        end
    end)

    local rag = ents.Create("prop_ragdoll")
    if IsValid(rag) then
        rag:SetModel(self:GetModel() or "models/player/phoenix.mdl")
        rag:SetPos(self:GetPos())
        rag:SetAngles(self:GetAngles())
        rag:Spawn()
        rag:Activate()
        rag:SetCollisionGroup(COLLISION_GROUP_DEBRIS)

        local force = (dmginfo and dmginfo:GetDamageForce()) or Vector(0, 0, 0)
        local forceDir = force:GetNormalized()
        local forceMag = math.Clamp(force:Length() * 0.05, 50, 400)

        for i = 0, rag:GetPhysicsObjectCount() - 1 do
            local phys = rag:GetPhysicsObjectNum(i)
            if IsValid(phys) then
                phys:Wake()
                phys:SetVelocity(forceDir * forceMag + Vector(math.random(-30, 30), math.random(-30, 30), math.random(10, 40)))
            end
        end

        SafeRemoveEntityDelayed(rag, 15)
    end

    self:Remove()
end

function ENT:RunBehaviour()
    while true do
        if self.IsKilled then break end

        local aiDisabled = GetConVar("ai_disabled") and GetConVar("ai_disabled"):GetBool()
        if aiDisabled then
            self:StartActivity(ACT_HL2MP_IDLE)
            coroutine.wait(0.5)
        else
            local enemy = self:FindEnemy()
            if IsValid(enemy) then
                self.loco:FaceTowards(enemy:GetPos())
                self:StartActivity(ACT_HL2MP_RUN)
                self.loco:SetDesiredSpeed(300)
                self:MoveToPos(enemy:GetPos(), { lookahead = 20, tolerance = 120 })
                self:StartActivity(ACT_HL2MP_IDLE)
            else
                self:StartActivity(ACT_HL2MP_WALK)
                self.loco:SetDesiredSpeed(100)
                self:MoveToPos(self:GetPos() + Vector(math.random(-300, 300), math.random(-300, 300), 0))
                self:StartActivity(ACT_HL2MP_IDLE)
            end
        end
        coroutine.yield()
    end
end

function ENT:FindEnemy()
    if self.IsKilled then return nil end
    local aiDisabled = GetConVar("ai_disabled") and GetConVar("ai_disabled"):GetBool()
    if aiDisabled then return nil end

    for _, ply in ipairs(player.GetAll()) do
        if ply:Alive() and ply:GetMoveType() ~= MOVETYPE_NOCLIP then 
            return ply 
        end
    end
    return nil
end

function ENT:BodyUpdate()
    self:FrameAdvance()
    if self.IsKilled then return end
    
    local aiDisabled = GetConVar("ai_disabled") and GetConVar("ai_disabled"):GetBool()
    if not aiDisabled then
        self.SpinYaw = (self.SpinYaw + 15) % 360
        self:SetAngles(Angle(0, self.SpinYaw, 0))
        self:SetPoseParameter("head_yaw", 0)
        self:SetPoseParameter("body_yaw", 0)
        self:SetPoseParameter("aim_pitch", 89.0)
    end
end

function ENT:Think()
    if self.IsKilled then return end
    local aiDisabled = GetConVar("ai_disabled") and GetConVar("ai_disabled"):GetBool()
    if aiDisabled then return end

    local curT = CurTime()
    local enemy = self:FindEnemy()

    self.EnemyHistory = self.EnemyHistory or {}
    if IsValid(enemy) then
        table.insert(self.EnemyHistory, {
            pos = enemy:GetPos(),
            eyePos = enemy:EyePos(),
            vel = enemy:GetVelocity(),
            time = curT
        })

        while #self.EnemyHistory > 0 and (curT - self.EnemyHistory[1].time > 0.5) do
            table.remove(self.EnemyHistory, 1)
        end
    else
        self.EnemyHistory = {}
    end

    if IsValid(enemy) and self:GetPos():DistToSqr(enemy:GetPos()) < 2500000 then
        if curT > self.NextAttack then
            local startPos = self:GetShootPos()
            local enemySpeed = enemy:GetVelocity():Length2D()

            local targetPos = nil
            local lagDelay = (enemySpeed > 50) and 0.22 or 0.05
            local targetTime = curT - lagDelay

            for i = #self.EnemyHistory, 1, -1 do
                if self.EnemyHistory[i].time <= targetTime then
                    targetPos = self.EnemyHistory[i].eyePos
                    break
                end
            end

            if not targetPos then
                targetPos = enemy:EyePos() - (enemy:GetVelocity() * 0.20)
            end

            local dir = (targetPos - startPos):GetNormalized()

            self:FireBullets({
                Num = 1,
                Src = startPos,
                Dir = dir,
                Spread = Vector(0.015, 0.015, 0),
                Tracer = 1,
                TracerName = "Tracer",
                Force = 5,
                Damage = 12,
                Attacker = self
            })

            self:EmitSound("Weapon_SMG1.Single")
            self.NextAttack = curT + 0.09
        end
    end
end

function ENT:GetShootPos()
    return self:GetPos() + Vector(0, 0, 60)
end
